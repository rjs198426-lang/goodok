import functools,http.server,threading,json,datetime,copy
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];out=root/'artifacts/research-v3';out.mkdir(exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root/'app/src/main/assets')));threading.Thread(target=server.serve_forever,daemon=True).start()
feed=json.loads((root/'tests/fixtures/research-feed.json').read_text());feed['generatedAt']='2026-10-27T01:00:00Z'
for offer in feed['offers']:offer.update(verifiedAt=feed['generatedAt'],checked='2026-10-27',ends=None)
feed['research']={'pipelineVersion':3,'candidateCount':500,'factChecks':92,'catalogCount':54,'metrics':{'factCheckOutcomes':{'needs_verification':92},'newServiceCount':1,'candidatePlanCount':13},'providers':[{'name':'Naver','status':'deferred','attempts':4}]}
bundle={'key':'bundle-v3','name':'새 복합 AI','aliases':['새 복합 AI'],'category':'AI','purpose':'coding','purposes':['assistant','image','coding'],'status':'verified','verification':{'billingTerms':True},'officialUrl':'https://new.example/pricing'}
feed['catalog'].append(bundle)
feed['tasteSuggestions']=[{'id':str(i),'name':'가을 전시 '+str(i),'category':'공연·전시','starts':'2026-10-01','ends':'2026-11-30','verifiedAt':feed['generatedAt'],'status':'official_verified','price':20000,'currency':'KRW','source':'https://www.museum.go.kr/exhibition/'+str(i)} for i in range(8)]
items=[{'id':'own','name':'ChatGPT','price':29000,'category':'AI','date':'2026-10-01','cycle':'monthly','paused':False,'memo':''}]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':390,'height':844},timezone_id='Asia/Seoul');page.clock.install(time=datetime.datetime.fromisoformat('2026-10-27T10:00:00+09:00'));errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.add_init_script('window.GoodokResearch={loadBenefits:id=>window.reqId=id,appInfo:()=>JSON.stringify({version:"2.0.1",build:46})}');page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle');page.evaluate('(items)=>localStorage.setItem("goodok-note-v1",JSON.stringify({demo:false,costSchema:2,items}))',items);page.reload(wait_until='networkidle')
 def complete(value):
  page.evaluate('window.goodokResume()');page.evaluate('(feed)=>window.goodokOfferResearch({type:"feed",requestId:window.reqId,ok:true,feed})',value)
 complete(feed);page.locator('.nav[data-view=recommendations]').click()
 keys=page.evaluate('async()=>{const c=await import("./catalog.js");return c.discoverableServices([{name:"ChatGPT"}]).map(s=>s.key)}')
 assert 'bundle-v3' not in keys
 page.locator('.nav[data-view=settings]').click();page.locator('#research-report-open').click();assert '외부 후보 대조 확정' in page.locator('#research-report-content').inner_text();assert page.locator('#research-report-content dd').nth(4).inner_text()=='0';assert '재시도 대기' in page.locator('#research-providers').text_content()
 for width,height in [(320,568),(390,844),(568,320)]:
  page.set_viewport_size(dict(width=width,height=height));page.wait_for_timeout(100);box=page.locator('#research-report').bounding_box();assert box['x']>=0 and box['y']>=0 and box['x']+box['width']<=width+1 and box['y']+box['height']<=height+1
 page.set_viewport_size(dict(width=390,height=844));page.screenshot(path=str(out/'research-report.png'));page.locator('#research-report-close').click();page.locator('.nav[data-view=recommendations]').click()
 page.locator('[data-part=picks]').click();page.locator('[data-discovery-kind=taste]').click();assert page.locator('.taste-card').count()==8;assert all(t=='공식' for t in page.locator('.taste-card .discovery-name span').all_text_contents())
 for width,height in [(320,568),(390,844),(412,915),(568,320),(1024,768)]:
  page.set_viewport_size(dict(width=width,height=height));page.wait_for_timeout(130);assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
  if width<761 and height>500:assert page.locator('#recommendation-list').evaluate('(e)=>e.getBoundingClientRect().bottom')<=page.locator('.sidebar nav').evaluate('(e)=>e.getBoundingClientRect().top')+1
 page.set_viewport_size(dict(width=390,height=844));page.wait_for_timeout(150);page.screenshot(path=str(out/'official-taste.png'))
 page.locator('[data-taste]').first.click();assert page.locator('#actual-amount').input_value() in ('','0');assert page.locator('#service-name').input_value().startswith('가을 전시');page.locator('#cancel-editor').click()
 expired=copy.deepcopy(feed)
 for activity in expired['tasteSuggestions']:activity['ends']='2026-10-26'
 complete(expired);assert all(t=='아이디어' for t in page.locator('.taste-card .discovery-name span').all_text_contents())
 page.locator('.nav[data-view=settings]').click();assert page.locator('#app-version').inner_text()=='2.0.1';page.locator('#release-notes-open').click();assert '2.0.1 · 빌드 46' in page.locator('#release-notes-body').inner_text()
 assert len(page.evaluate('JSON.parse(localStorage.getItem("goodok-note-v1")).items'))==1;assert errors==[],errors
 browser.close()
server.shutdown();print('PASS: multi-purpose exclusion, honest audit outcomes, official taste links and expiry, no invented actual spending, five-size layout, version/build notes, saved records preserved')
