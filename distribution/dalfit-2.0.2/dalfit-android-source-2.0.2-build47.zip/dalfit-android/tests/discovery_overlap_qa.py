import functools,http.server,threading,json,datetime,copy
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];out=root/'artifacts/discovery-overlap';out.mkdir(exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root/'app/src/main/assets')));threading.Thread(target=server.serve_forever,daemon=True).start()
base=dict(cycle='monthly',date='2026-01-15',memo='',paused=False)
items=[dict(base,id='vpn',name='서프샤크 VPN',category='VPN',price=9000),dict(base,id='llm',name='챗지피티',category='AI',price=29000)]
feed=json.loads((root/'tests/fixtures/research-feed.json').read_text());feed['generatedAt']='2026-10-26T01:00:00Z'
seed=feed['plans'][0]
def plan(key,amount,devices,url):
 return dict(seed,id=key+'-proof',service=key,name='Standard',amount=amount,purpose='vpn',source=url,verifiedAt='2026-10-26T01:00:00Z',capabilities={'devices':devices},evidence=[{'field':'amount','quote':'test official price'},{'field':'capability.devices','quote':'test official devices'}])
feed['plans']=[plan('surfshark',9000,5,'https://surfshark.com/pricing'),plan('nordvpn',8000,10,'https://nordvpn.com/pricing/')]
feed['catalog'].append(dict(key='new-llm-tool',name='새 검증 LLM',aliases=['새 검증 LLM'],category='AI',purpose='assistant',status='verified',officialUrl='https://new-llm.example/pricing'))
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':390,'height':844},timezone_id='Asia/Seoul');page.clock.install(time=datetime.datetime.fromisoformat('2026-10-26T10:00:00+09:00'));errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.add_init_script('window.GoodokResearch={loadBenefits:id=>window.reqId=id}');page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle');page.evaluate('(items)=>localStorage.setItem("goodok-note-v1",JSON.stringify({costSchema:2,demo:false,items}))',items);page.reload(wait_until='networkidle')
 def complete(value):page.evaluate('(feed)=>window.goodokOfferResearch({type:"feed",requestId:window.reqId,ok:true,feed})',value)
 complete(feed);page.locator('.nav[data-view=recommendations]').click()
 blocked={'chatgpt','claude','gemini','grok','copilot','perplexity','surfshark','nordvpn','expressvpn','protonvpn','new-llm-tool'}
 def keys():return page.locator('#recommendation-list [data-recommend]').evaluate_all('(els)=>els.map(e=>e.dataset.recommend)')
 assert len(keys())==8;assert not set(keys())&blocked
 page.locator('[data-part=alternatives]').click();assert page.locator('[data-target=nordvpn]').count()==1;assert '상위 대안' in page.locator('[data-target=nordvpn]').inner_text()
 page.locator('[data-part=picks]').click();before=keys();page.evaluate('window.goodokResume()');assert keys()==before
 # A cheaper but unproven target is not displayed as a comparison.
 weak=copy.deepcopy(feed);weak['plans'][1]['evidence']=weak['plans'][1]['evidence'][:1];complete(weak);page.locator('[data-part=alternatives]').click();assert page.locator('[data-target=nordvpn]').count()==0;page.locator('[data-part=picks]').click()
 seen=set(keys())
 for day in range(27,32):
  page.clock.set_system_time(datetime.datetime(2026,10,day,10,tzinfo=datetime.timezone(datetime.timedelta(hours=9))));page.evaluate('window.goodokResume()');assert not set(keys())&blocked;seen.update(keys())
 assert seen&{'cursor','github-copilot','krea','midjourney','lovable','suno'}
 for width,height in [(320,568),(390,844),(568,320),(1024,768)]:
  page.set_viewport_size(dict(width=width,height=height));page.wait_for_timeout(120);assert len(keys())==8;assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
  if width<761 and height>500:assert page.locator('#recommendation-list').evaluate('(e)=>e.getBoundingClientRect().bottom')<=page.locator('.sidebar nav').evaluate('(e)=>e.getBoundingClientRect().top')+1
 page.set_viewport_size(dict(width=390,height=844));page.wait_for_timeout(150);page.screenshot(path=str(out/'discovery.png'))
 assert errors==[],errors
 browser.close()
server.shutdown();print('PASS: active VPN/LLM overlap excluded including new verified server service, eight distinct-purpose picks rotate stably, verified superior VPN comparison remains and unproven comparison is suppressed, four-size layout')
