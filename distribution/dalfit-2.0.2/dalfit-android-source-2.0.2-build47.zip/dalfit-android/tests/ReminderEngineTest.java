package kr.goodok.note;
import java.time.*;import java.util.*;
public final class ReminderEngineTest {
 static void check(boolean value){if(!value)throw new AssertionError();}
 static ReminderEngine.Record record(String cycle,String date,String trial,String contract,boolean paused){return new ReminderEngine.Record("id","넷플릭스",cycle,LocalDate.parse(date),trial==null?null:LocalDate.parse(trial),contract==null?null:LocalDate.parse(contract),paused);}
 static List<ReminderEngine.Event> due(ReminderEngine.Record record,String date){return ReminderEngine.due(List.of(record),LocalDate.parse(date));}
 public static void main(String[] args){
  var monthly=record("monthly","2024-01-31",null,null,false);
  check(due(monthly,"2026-02-25").get(0).lead==3);check(due(monthly,"2026-02-27").get(0).lead==1);check(due(monthly,"2026-02-26").isEmpty());check(due(monthly,"2026-02-28").isEmpty());
  check(due(monthly,"2026-12-28").get(0).date.equals(LocalDate.of(2026,12,31)));check(due(monthly,"2027-01-28").size()==1);
  var leap=record("yearly","2024-02-29",null,null,false);check(due(leap,"2027-02-25").size()==1);check(due(leap,"2028-02-26").get(0).date.equals(LocalDate.of(2028,2,29)));check(due(leap,"2026-03-26").isEmpty());
  var future=record("monthly","2027-01-01",null,null,false);check(due(future,"2026-12-29").size()==1);check(due(future,"2026-11-28").isEmpty());
  var ends=record("monthly","2024-01-29","2026-10-29","2026-10-29",false);var three=due(ends,"2026-10-26");check(three.size()==3);check(three.stream().map(ReminderEngine.Event::key).distinct().count()==3);check(due(ends,"2026-10-28").size()==3);check(due(ends,"2026-10-30").isEmpty());
  check(due(record("monthly","2024-01-29","2026-10-29","2026-10-29",true),"2026-10-26").isEmpty());
  check(due(record("monthly","2024-01-01",null,"2026-12-01",false),"2026-11-28").size()==2);
  var fixed=new ReminderEngine.Record("rent","월세","monthly",LocalDate.of(2024,1,1),null,null,false,true);check(due(fixed,"2026-10-29").get(0).title().contains("비용 납부 3일 전"));check(due(fixed,"2026-10-31").get(0).title().contains("1일 전"));
  System.out.println("PASS: monthly/yearly 3-day and 1-day reminders, month-end/leap/year rollover/future/paused, trial and contract dates, unique identities");
 }
}
