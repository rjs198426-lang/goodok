import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {services,findService,findServices,categoryColors,categoryIcons} from '../app/src/main/assets/catalog.js';
const assets=new URL('../app/src/main/assets/',import.meta.url);
const native=fs.readFileSync(new URL('../app/src/main/java/kr/goodok/note/MainActivity.java',import.meta.url),'utf8');
test('all 53 catalogue services have a packaged logo and resolve to their own service',()=>{
 assert.equal(services.length,53);
 assert.equal(new Set(services.map(s=>s.key)).size,services.length);
 for(const service of services){assert.ok(service.category in categoryColors);assert.equal(findService(service.name)?.key,service.key,service.name);const path='brands/'+service.brand+'.svg';assert.ok(fs.existsSync(new URL(path,assets)),path);assert.ok(native.includes('"/'+path+'"'),path);}
});
test('specific products win over their parent brand and Korean aliases work',()=>{
 for(const [name,key] of [['그록','grok'],['SuperGrok','grok'],['러버블','lovable'],['Lovable Pro','lovable'],['크레아 AI','krea'],['Krea AI Pro','krea'],['쿠팡 와우','coupang'],['쿠팡 플레이 스포츠','coupang-play'],['깃허브 코파일럿 비즈니스','github-copilot'],['마이크로소프트 코파일럿','copilot'],['유튜브 뮤직','youtube-music'],['네이버 플러스 멤버십','naver-plus'],['서퍼 샤크 VPN','surfshark'],['M365 Family','microsoft365'],['Office 365','microsoft365'],['유독 Pick','yodok'],['카카오 이모티콘 플러스','kakao-emoticon'],['카카오페이지','kakao-page']])assert.equal(findService(name)?.key,key,name);
});
test('catalogue search combines aliases and category filters',()=>{assert.ok(findServices('M365','생산성').some(s=>s.key==='microsoft365'));assert.equal(findServices('M365','OTT').length,0);assert.equal(findServices('','VPN').length,4);assert.equal(findService('내 개인 구독'),null);});
test('all categories have an offline icon and original storage categories remain supported',()=>{
 for(const category of Object.keys(categoryColors)){const path='brands/'+categoryIcons[category]+'.svg';assert.ok(fs.existsSync(new URL(path,assets)));assert.ok(native.includes('"/'+path+'"'));}
 for(const original of ['콘텐츠','음악','생산성','생활','기타'])assert.ok(original in categoryColors);
});
