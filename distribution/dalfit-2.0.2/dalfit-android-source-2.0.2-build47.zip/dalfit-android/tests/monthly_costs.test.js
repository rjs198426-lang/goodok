import test from 'node:test';import assert from 'node:assert/strict';
import {amountForMonth,inMonth,paymentsInMonth,validActuals} from '../app/src/main/assets/model.js';
import {expenseKind,recommendServices} from '../app/src/main/assets/catalog.js';
const item={id:'h',name:'취미 활동',kind:'variable',category:'취미',date:'2026-01-31',cycle:'monthly',price:100000,actuals:{'2026-10':75000,'2026-11':0}};
test('actuals including zero replace only their month and preserve the recurring budget',()=>{
 assert.equal(amountForMonth(item,new Date(2026,9,1)),75000);assert.equal(amountForMonth(item,new Date(2026,10,1)),0);assert.equal(amountForMonth(item,new Date(2026,11,1)),100000);
 assert.equal(amountForMonth(inMonth(item,new Date(2026,9,1)),new Date(2026,11,1)),100000);
 assert.equal(paymentsInMonth([item],2026,9)[0].estimated,false);assert.equal(paymentsInMonth([item],2026,11)[0].estimated,true);
 assert.equal(item.price,100000);assert.equal(expenseKind(item),'variable');assert.deepEqual(recommendServices([item],'2026-10-26'),recommendServices([],'2026-10-26'));
});
test('backup validation rejects malformed monthly amounts',()=>{for(const value of [null,[],{'2026-13':3},{'2026-10':-1},{'2026-10':'2'},{'2026-10':100000001}])assert.equal(validActuals(value),false);assert.equal(validActuals(item.actuals),true);});

test('an explicitly recorded past actual is visible even before the recurring budget start',()=>{const later={...item,date:'2026-11-26'};assert.equal(paymentsInMonth([later],2026,9)[0].price,75000);assert.equal(paymentsInMonth([later],2026,8).length,0);});
