import functools,http.server,threading,json,datetime,copy
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];out=root/'artifacts/benefits-four';out.mkdir(exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root/'app/src/main/assets')));threading.Thread(target=server.serve_forever,daemon=True).start()
feed=json.loads((root/'tests/fixtures/research-feed.json').read_text());benefits=['첫 27개월 $67.23','Premium 개인 1개월 ₩0','첫해 월 ₩58,200 · 연간 플랜 할인','Family 12개월 + 추가 3개월 혜택','월 구독 20% 할인','연 결제 30% 할인','가족 요금제 특별 혜택'];feed['offers']=[dict(feed['offers'][0],id='campaign'+str(i),service='microsoft365' if i==3 else 'chatgpt',title='독립 할인 캠페인 '+str(i),benefit=value,conditions='대상과 가입 조건을 확인하세요. '*12) for i,value in enumerate(benefits)]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':390,'height':844},timezone_id='Asia/Seoul');page.clock.install(time=datetime.datetime.fromisoformat('2026-10-26T10:00:00+09:00'));errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.add_init_script('window.GoodokResearch={loadBenefits:id=>window.reqId=id}');page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle')
 def complete(value):page.evaluate('(feed)=>window.goodokOfferResearch({type:"feed",requestId:window.reqId,ok:true,feed})',value)
 complete(feed);page.locator('.nav[data-view=recommendations]').click();page.locator('[data-part=offers]').click()
 for width,height in [(320,568),(360,640),(390,844),(412,915),(568,320),(1024,768)]:
  page.set_viewport_size(dict(width=width,height=height));page.wait_for_timeout(160);assert page.locator('.discount-card').count()==4
  for card in page.locator('.discount-card').all():
   bounds=card.evaluate('''e=>{const c=e.getBoundingClientRect();return [...e.querySelectorAll('.discount-top,h3,.offer-card-actions')].map(x=>{const r=x.getBoundingClientRect();return [r.left>=c.left-1,r.right<=c.right+1,r.top>=c.top-1,r.bottom<=c.bottom+1]})}''');assert all(all(row) for row in bounds),(width,height,bounds)
   assert card.locator('h3').evaluate('(e)=>e.scrollHeight<=e.clientHeight+1&&e.scrollWidth<=e.clientWidth+1'),(width,height,'title clipping')
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),(width,height,'page width')
  if width<761 and height>500:assert page.locator('#offer-pagination').evaluate('(e)=>e.getBoundingClientRect().bottom')<=page.locator('.sidebar nav').evaluate('(e)=>e.getBoundingClientRect().top')+1
  if width==390:page.screenshot(path=str(out/'four-offers.png'))
  page.locator('#offer-next').click();assert page.locator('.discount-card').count()==3;page.locator('#offer-prev').click()
 # Extremely long text stays complete and accessible in the scrollable offer area.
 page.set_viewport_size(dict(width=320,height=568));long=copy.deepcopy(feed)
 for i,offer in enumerate(long['offers']):offer['benefit']='아주 긴 할인 조건과 가족 요금제 첫 이용 기간 및 추가 제공 혜택을 모두 확인하세요 '+('PremiumFamilyExtraMonthsWithoutSpaces'*4)+str(i)
 page.locator('#research-retry').click();complete(long);assert page.locator('.discount-card').count()==4
 for card in page.locator('.discount-card').all():assert card.locator('h3').evaluate('(e)=>e.scrollHeight<=e.clientHeight+1&&e.scrollWidth<=e.clientWidth+1')
 assert page.locator('#discount-list').evaluate('(e)=>e.scrollHeight>e.clientHeight')
 page.locator('.offer-terms summary').first.click();assert page.locator('.offer-terms[open] p').is_visible();page.locator('.discount-meta a').first.scroll_into_view_if_needed();assert page.locator('.discount-meta a').first.is_visible();page.locator('.offer-terms summary').first.click()
 page.locator('#offer-next').click();page.locator('#research-retry').click();single=copy.deepcopy(feed);single['offers']=single['offers'][:1];complete(single);assert '1 / 1' in page.locator('#offer-page-label').inner_text();assert page.locator('.discount-card').count()==1;assert errors==[],errors
 browser.close()
server.shutdown();print('PASS: four offers/page, seven results reachable, six-size title/card bounds, extreme Korean/unbroken text remains full and scrollable, expanded terms/official link, refresh page clamp')
