import functools,http.server,threading,json
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];out=root/'artifacts/home-fit';out.mkdir(exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root/'app/src/main/assets')));threading.Thread(target=server.serve_forever,daemon=True).start()
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True);page.add_init_script('window.GoodokResearch={loadBenefits:()=>{},appInfo:()=>JSON.stringify({version:"2.0.2",build:47})}')
 page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle')
 cases={'demo':None,'empty':[],'categories':[dict(id=str(i),name='서비스 '+str(i),price=999999,category=category,date='2024-01-01',cycle='monthly',memo='',paused=False) for i,category in enumerate(['AI','OTT','쇼핑','통신·결합','VPN','생산성','카카오','음악','학습','콘텐츠','생활','기타','주거','공과금','통신','보험','금융','교통','교육·돌봄','기타 고정비'])]}
 for name,items in cases.items():
  if items is None:page.evaluate('localStorage.removeItem("goodok-note-v1")')
  else:page.evaluate('(items)=>localStorage.setItem("goodok-note-v1",JSON.stringify({demo:false,items}))',items)
  page.reload(wait_until='networkidle')
  # Build the stress case from the app's supported categories.
  if name=='categories':
   page.evaluate('''()=>{const state=JSON.parse(localStorage.getItem('goodok-note-v1'));const cats=[...document.querySelectorAll('[data-filter]')].map(el=>el.dataset.filter).filter(c=>c!=='전체');state.items=state.items.filter(item=>cats.includes(item.category));localStorage.setItem('goodok-note-v1',JSON.stringify(state))}''');page.reload(wait_until='networkidle')
  for width,height in [(320,568),(360,640),(390,844),(412,915),(568,320),(1024,768)]:
   page.set_viewport_size(dict(width=width,height=height));page.evaluate('window.scrollTo(0,0)');page.wait_for_timeout(100)
   dims=page.evaluate('''()=>({height:document.documentElement.scrollHeight,width:document.documentElement.scrollWidth,actions:document.querySelector('.home-actions').getBoundingClientRect().bottom,nav:document.querySelector('.sidebar nav').getBoundingClientRect().top})''')
   
   if dims['height']>height+1:print(page.evaluate('''()=>[...document.querySelector('.content').children,...document.querySelector('#overview').children,...document.querySelector('#spending-details').children].map(el=>[el.id||el.className,el.getBoundingClientRect().top,el.getBoundingClientRect().height])'''),flush=True)
   assert dims['height']<=height+1,(name,width,height,dims)
   assert dims['width']<=width+1,(name,width,height,dims)
   if width<=760 and height>500:
    if dims['actions']>dims['nav']:print(page.evaluate('''()=>[document.querySelector('.content'),...document.querySelector('.content').children,...document.querySelector('#overview').children,...document.querySelector('#spending-details').children].map(el=>[el.id||el.className,el.getBoundingClientRect().top,el.getBoundingClientRect().height,getComputedStyle(el).minHeight])'''),flush=True)
    assert dims['actions']<=dims['nav'],(name,width,height,dims)
   
   for amount in ['#monthly','#fixed-monthly']:
    bounds=page.locator(amount).evaluate('(el)=>({right:el.getBoundingClientRect().right,parent:el.parentElement.getBoundingClientRect().right,scroll:el.scrollWidth,width:el.clientWidth})');assert bounds['right']<=bounds['parent']+1 and bounds['scroll']<=bounds['width']+1,(name,width,height,amount,bounds)
   page.screenshot(path=str(out/f'{name}-{width}x{height}.png'))
  page.locator('[data-view=settings]').click();assert page.locator('#app-version').inner_text()=='2.0.2';assert page.locator('#release-notes-open').inner_text().startswith('47');page.locator('[data-view=overview]').click()
 browser.close()
server.shutdown();print(json.dumps({'result':'passed','checks':['home without scroll or clipping at 6 sizes','demo empty many-category states','settings version 2.0.2 and build 47 from native metadata']}))
