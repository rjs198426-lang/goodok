import functools,http.server,threading,json,datetime
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];out=root/'artifacts/monthly-costs';out.mkdir(exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root/'app/src/main/assets')));threading.Thread(target=server.serve_forever,daemon=True).start()
items=[dict(id='s',name='Netflix',category='OTT',price=17000,cycle='monthly',date='2026-01-05',memo='',paused=False),dict(id='f',name='월세',category='주거',kind='fixed',price=700000,cycle='monthly',date='2026-01-01',memo='',paused=False),dict(id='v',name='취미 활동',category='취미',kind='variable',price=100000,cycle='monthly',date='2026-01-15',memo='',paused=False,actuals={'2026-10':75000,'2026-09':60000})]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,timezone_id='Asia/Seoul');page.clock.install(time=datetime.datetime.fromisoformat('2026-10-26T10:00:00+09:00'))
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.add_init_script('localStorage.setItem("goodok-note-v1",JSON.stringify('+json.dumps(dict(demo=False,items=items))+'));window.GoodokResearch={syncReminders:s=>window.synced=JSON.parse(s)};')
 page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle')
 assert page.locator('.nav').count()==4
 assert page.locator('#variable-monthly').inner_text()=='₩100,000'
 assert [i['id'] for i in page.evaluate('window.synced')]==['s','f']
 page.locator('.nav[data-view=subscriptions]').click();assert page.locator('#page-title').inner_text()=='월간 비용';assert page.locator('[data-subscription]').count()==3;assert page.locator('#filtered-monthly').inner_text()=='₩792,000'
 page.locator('[data-cost-kind=variable]').click();assert page.locator('[data-subscription]').count()==1;assert page.locator('#filtered-monthly').inner_text()=='₩75,000';page.locator('[data-subscription=v]').scroll_into_view_if_needed();assert '실제' in page.locator('[data-subscription=v]').text_content()
 page.locator('[data-edit=v]').click();assert page.locator('#price').input_value()=='100000';assert page.locator('#actual-amount').input_value()=='75000';page.locator('#actual-amount').fill('85000');page.locator('#actual-month').fill('2026-11');assert page.locator('#actual-amount').input_value()=='';page.locator('#actual-amount').fill('0');page.locator('#subscription-form button[type=submit]').click();assert not page.locator('#editor').evaluate('(e)=>e.open')
 stored=page.evaluate('JSON.parse(localStorage.getItem("goodok-note-v1"))');v=next(i for i in stored['items'] if i['id']=='v');assert v['price']==100000;assert v['actuals']=={'2026-09':60000,'2026-10':85000,'2026-11':0};assert page.locator('#filtered-monthly').inner_text()=='₩85,000';assert page.locator('#variable-monthly').inner_text()=='₩0'
 page.locator('#cost-next').click();assert page.locator('#filtered-monthly').inner_text()=='₩0';page.locator('#cost-next').click();assert page.locator('#filtered-monthly').inner_text()=='₩100,000'
 page.locator('#tab-calendar').click();assert page.locator('.calendar-entry').count()==0
 page.locator('[data-cost-kind=fixed]').click();assert page.locator('[data-subscription]').count()==1;page.locator('#tab-list').click();page.locator('[data-edit=f]').click();page.locator('#expense-type').select_option('variable');page.locator('#subscription-form button[type=submit]').click();assert page.locator('[data-subscription]').count()==0
 page.locator('[data-cost-kind=variable]').click();page.locator('#add').click();page.locator('[data-preset="variable:hobby-gear"]').click();page.locator('#price').fill('50000');page.locator('#actual-amount').fill('40000');page.locator('#subscription-form button[type=submit]').click();assert page.locator('[data-subscription]').count()==3
 page.locator('.nav[data-view=settings]').click();page.locator('#backup-open').click();backup=json.loads(page.locator('#backup-text').input_value());assert any(i.get('actuals',{}).get('2026-10')==85000 for i in backup['items']);page.locator('#backup-close').click();page.locator('#restore-open').click();page.locator('#backup-text').fill(json.dumps(backup));page.locator('#backup-action').click();page.locator('#confirm-ok').click();assert page.evaluate('JSON.parse(localStorage.getItem("goodok-note-v1")).items')==backup['items']
 page.locator('.nav[data-view=subscriptions]').click();page.locator('[data-cost-kind=all]').click();page.locator('#tab-list').click();page.screenshot(path=str(out/'monthly-costs.png'),full_page=True)
 # All four destinations fit horizontally; home remains a single viewport.
 for width,height in [(320,568),(360,640),(390,844),(412,915),(568,320),(1024,768)]:
  page.set_viewport_size(dict(width=width,height=height))
  for view in ['overview','subscriptions','recommendations','settings']:
   page.locator('.nav[data-view='+view+']').click();page.wait_for_timeout(80)
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),(width,height,view,'horizontal')
   if view=='overview':
    assert page.evaluate('document.documentElement.scrollHeight<=innerHeight+1'),(width,height,'home height',page.evaluate('document.documentElement.scrollHeight'))
    for el in page.locator('.home-total-columns .big').all():assert el.evaluate('(e)=>{const r=document.createRange();r.selectNodeContents(e);return r.getBoundingClientRect().right<=e.parentElement.getBoundingClientRect().right-2}'),(width,height,'amount')
  if width==390:page.locator('.nav[data-view=overview]').click();page.screenshot(path=str(out/'home.png'))
 assert errors==[],errors
 browser.close()
server.shutdown();print('PASS: four navigation tabs, monthly type filters, actual/budget month isolation including zero, convert fixed to variable, hobby registration, native reminder exclusion, full backup restore, 6-size overflow/home fit')
