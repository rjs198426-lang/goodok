import functools,http.server,threading,json,datetime
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];out=root/'artifacts/home-toggle';out.mkdir(exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root/'app/src/main/assets')));threading.Thread(target=server.serve_forever,daemon=True).start()
base=dict(cycle='monthly',date='2025-01-15',memo='',paused=False)
items=[dict(base,id='s'+str(i),name=n,category=c,price=v) for i,(n,c,v) in enumerate([('ChatGPT','AI',29000),('쿠팡 와우','쇼핑',3945),('YouTube Premium','OTT',5000),('Surfshark VPN','VPN',6000),('카카오 톡서랍','카카오',1900)])]+[dict(base,id='fixed',name='인터넷 요금',category='통신',kind='fixed',price=100000000)]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':390,'height':844},timezone_id='Asia/Seoul');page.clock.install(time=datetime.datetime.fromisoformat('2026-10-26T10:00:00+09:00'));errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.add_init_script('window.GoodokResearch={loadBenefits:()=>{}};localStorage.setItem("goodok-note-v1",JSON.stringify('+json.dumps(dict(demo=False,items=items))+'))');page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle')
 selectors=['.featured','.home-focus','.home-total-columns','#spending-details','#spending-title','.chart-area','#donut','#legend','.yearly-detail','.home-next','.home-next .section-head','#upcoming','.home-actions','#home-all-subscriptions','#see-calendar','.sidebar nav']
 for width,height in [(320,568),(360,640),(390,844),(412,915),(568,320),(1024,768)]:
  page.set_viewport_size(dict(width=width,height=height));reference=None
  for kind in ['subscription','fixed','variable','subscription','variable','fixed']:
   page.locator('[data-home-kind='+kind+']').click();page.wait_for_timeout(90)
   dims=page.evaluate('(selectors)=>selectors.map(s=>{const r=document.querySelector(s).getBoundingClientRect();return [s,r.x,r.y,r.width,r.height]})',selectors)
   if reference is None:reference=dims
   else:
    for before,after in zip(reference,dims):assert all(abs(a-b)<.6 for a,b in zip(before[1:],after[1:])),(width,height,kind,before,after)
   assert page.evaluate('document.documentElement.scrollHeight<=innerHeight+1'),(width,height,kind,'vertical')
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),(width,height,kind,'horizontal')
   assert page.locator('.featured .hero-bottom').count()==0
   assert page.locator('#home-all-subscriptions').is_visible()
   for selector in ['#home-focus-total','#monthly','#fixed-monthly','#variable-monthly']:
    assert page.locator(selector).evaluate('(el)=>{const r=document.createRange();r.selectNodeContents(el);return r.getBoundingClientRect().right<=el.parentElement.getBoundingClientRect().right+1}'),(width,height,kind,selector)
   if width==390:page.screenshot(path=str(out/(kind+'.png')))
 assert errors==[],errors
 browser.close()
server.shutdown();print('PASS: repeat toggles with five categories/two payments, one large fixed payment, zero variable records; all 16 region/link rectangles unchanged at six sizes; no hints, overflow or clipped amounts')
