import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {createBenefitLoader,validateFeed,validFeedUrl,activeFeedOffers,deduplicateOffers,offerIdentity} from '../app/src/main/assets/offers.js';
const feed=JSON.parse(fs.readFileSync(new URL('./fixtures/server-feed.json',import.meta.url)));
function harness(saved=new Map()){
 let date=new Date('2026-10-25T10:00:00Z'),calls=[],events=[],timers=new Map(),serial=0;
 const params={storage:{getItem:key=>saved.get(key)||null,setItem:(key,value)=>saved.set(key,value)},now:()=>date,bridge:{loadBenefits:(id,url)=>calls.push({id,url})},changed:s=>events.push(s),schedule:fn=>{timers.set(++serial,fn);return serial},cancel:id=>timers.delete(id)};
 const loader=createBenefitLoader(params);return {loader,params,saved,calls,events,setDate:value=>date=value,complete:(value=feed,id=calls.at(-1).id)=>loader.receive({type:'feed',requestId:id,ok:true,feed:value}),fail:()=>loader.receive({type:'feed',requestId:calls.at(-1).id,ok:false}),timeout:()=>[...timers.values()].forEach(fn=>fn())};
}
test('app fetches on every open including same day; concurrent resumes share only the active request',()=>{
 const h=harness();h.loader.start();assert.equal(h.events.at(-1).status,'loading');assert.equal(h.loader.start(),false);assert.equal(h.calls.length,1);h.complete();assert.equal(h.events.at(-1).status,'ready');
 assert.equal(h.loader.start(),true);assert.equal(h.calls.length,2);h.complete();
 const reopened=createBenefitLoader(h.params);assert.equal(reopened.start(),true);assert.equal(h.calls.length,3);
});
test('failed download and malformed JSON retain original verification dates; timeout ignores late replies',()=>{
 const h=harness();h.loader.start();h.complete();const verified=h.events.at(-1).feed.offers[0].verifiedAt;
 h.loader.start();h.fail();assert.equal(h.events.at(-1).status,'error');assert.equal(h.events.at(-1).feed.offers[0].verifiedAt,verified);
 h.loader.start();h.complete({schemaVersion:55});assert.equal(h.events.at(-1).status,'error');
 h.loader.start();const late=h.calls.at(-1).id;h.timeout();h.complete(feed,late);assert.equal(h.events.at(-1).status,'error');
});
test('public feed URL validation and remote payload validation reject executable/malformed values',()=>{
 assert.ok(validFeedUrl('https://raw.githubusercontent.com/owner/repo/main/feed.json'));assert.ok(validFeedUrl('https://owner.github.io/data/feed.json'));
 for(const bad of ['http://example.com/feed.json','https://user@raw.githubusercontent.com/a/b/main/feed.json','https://raw.githubusercontent.com.evil/a/b/main/feed.json'])assert.equal(validFeedUrl(bad),false);
 assert.equal(validateFeed(feed).offers.length,3);assert.throws(()=>validateFeed({...feed,offers:[{...feed.offers[0],source:'javascript:alert(1)'}]}));
 const corrupt={...feed,comparisons:{claude:{source:'javascript:evil',features:[],pros:[],cons:[]}}};assert.equal(Object.keys(validateFeed(corrupt).comparisons).length,0);
});
test('verification age and actual end dates govern display; a recent previous-month check is allowed',()=>{
 assert.equal(activeFeedOffers(feed,new Date('2026-10-25T10:00:00Z')).length,3);assert.equal(activeFeedOffers(feed,new Date('2026-10-29T10:00:00Z')).length,0);
 const sample={offers:[{...feed.offers[0],verifiedAt:'2026-10-31T23:00:00Z',ends:null}]};assert.equal(activeFeedOffers(sample,new Date('2026-11-01T00:00:00Z')).length,1);
 sample.offers[0].ends='2026-10-31';assert.equal(activeFeedOffers(sample,new Date('2026-11-01T00:00:00Z')).length,0);
});

test('duplicate Korean source URLs collapse to the latest complete verified offer',()=>{
 const base={...feed.offers.find(offer=>offer.service==='spotify'),verifiedAt:'2026-10-25T08:00:00Z',source:'https://www.spotify.com/kr/premium/'},updated={...base,id:'discovered',source:'https://spotify.com/kr-ko/premium/?utm_source=naver#top',verifiedAt:'2026-10-25T09:00:00Z',benefit:'Premium 개인 2개월 ₩0',conditions:'새로운 가입 조건'};
 assert.equal(offerIdentity(base),offerIdentity(updated));assert.deepEqual(deduplicateOffers([updated,base]),[updated]);assert.deepEqual(deduplicateOffers([base,updated]),[updated]);assert.deepEqual(activeFeedOffers({offers:[base,updated]},new Date('2026-10-25T10:00:00Z')),[updated]);
 const ended={...updated,ends:'2026-10-24'};assert.deepEqual(activeFeedOffers({offers:[base,ended]},new Date('2026-10-25T10:00:00Z')),[]);
});
test('different plans, regions and meaningful coupons stay separate; newest verification sorts first',()=>{
 const base={...feed.offers.find(offer=>offer.service==='spotify'),verifiedAt:'2026-10-25T08:00:00Z'},family={...base,id:'family',title:'Spotify 한국 가족 요금제 체험'},coupon={...base,id:'coupon',source:base.source+'?coupon=ABC'},plan={...base,id:'student',planId:'student'},region={...base,id:'region',region:'US'},newer={...base,id:'newer',verifiedAt:'2026-10-25T09:00:00Z'};
 const list=deduplicateOffers([base,family,coupon,plan,region,newer]);assert.equal(list.length,5);assert.equal(list[0],newer);assert.equal(list.find(item=>item.id===base.id),undefined);
});
test('cached duplicate cleanup and failed refresh preserve original verification and fetched timestamps',()=>{
 const base={...feed.offers[1],verifiedAt:'2026-10-25T08:00:00Z'},duplicate={...base,id:'dupe',source:base.source.replace('/kr/','/kr-ko/'),verifiedAt:'2026-10-25T09:00:00Z'},cached={feed:{...feed,offers:[base,duplicate]},fetchedAt:'2026-10-25T09:01:00Z'},h=harness(new Map([['goodok-benefit-feed-v2',JSON.stringify(cached)]]));
 assert.equal(h.loader.snapshot().feed.offers.length,1);assert.equal(h.loader.snapshot().feed.offers[0].verifiedAt,duplicate.verifiedAt);h.loader.start();h.fail();assert.equal(h.loader.snapshot().feed.offers[0].verifiedAt,duplicate.verifiedAt);assert.equal(h.loader.snapshot().fetchedAt,cached.fetchedAt);
});
