import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {expenseKind,fixedCategories,fixedPresets,categoryColors,categoryIcons,services,recommendServices} from '../app/src/main/assets/catalog.js';
import {automaticAlternatives,comparisonCoverage} from '../app/src/main/assets/comparisons.js';
test('legacy subscriptions remain subscriptions; fixed costs have explicit domain and offline assets',()=>{
 assert.equal(expenseKind({name:'월세',category:'생활'}),'subscription');assert.equal(expenseKind({category:'주거'}),'fixed');assert.equal(expenseKind({name:'Netflix',category:'금융',kind:'fixed'}),'fixed');assert.equal(fixedCategories.length,8);assert.equal(fixedPresets.length,14);
 const native=fs.readFileSync(new URL('../app/src/main/java/kr/goodok/note/MainActivity.java',import.meta.url),'utf8');
 for(const item of fixedPresets){assert.equal(item.kind,'fixed');assert.ok(fixedCategories.includes(item.category)||item.category==='취미');assert.ok(item.category in categoryColors);const path='brands/'+categoryIcons[item.category]+'.svg';assert.ok(fs.existsSync(new URL('../app/src/main/assets/'+path,import.meta.url)));assert.ok(native.includes('"/'+path+'"'));assert.equal(item.price,undefined);}
});
test('a fixed item sharing a brand name never becomes a subscription or cheaper substitute',()=>{
 const fixed={id:'rent',name:'Netflix',kind:'fixed',category:'주거',price:700000,cycle:'monthly',serviceKey:'netflix',paused:false};
 assert.deepEqual(recommendServices([fixed],'2026-10-26'),recommendServices([],'2026-10-26'));
 assert.deepEqual(automaticAlternatives([fixed],[],[]),[]);assert.equal(comparisonCoverage([fixed],[],[]).active,0);
 assert.equal(comparisonCoverage([{...fixed,kind:'subscription',estimated:true}],[],[]).active,0);
 assert.equal(services.length,53);
});
