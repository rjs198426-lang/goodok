import functools,http.server,threading,json,datetime
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];out=root/'artifacts/daily-discovery';out.mkdir(exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root/'app/src/main/assets')));threading.Thread(target=server.serve_forever,daemon=True).start()
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,timezone_id='Asia/Seoul');page.clock.install(time=datetime.datetime.fromisoformat('2026-10-25T23:59:50+09:00'));page.add_init_script('window.GoodokResearch={loadBenefits:id=>window.reqId=id}')
 page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle');page.locator('.nav[data-view=recommendations]').click()
 def keys():return page.locator('#recommendation-list [data-recommend]').evaluate_all('(els)=>els.map(el=>el.dataset.recommend)')
 before=keys();assert len(before)==5;assert '10.25' in page.locator('#recommendation-count').inner_text();page.evaluate('window.goodokResume()');assert keys()==before
 page.clock.fast_forward(11000);after=keys();assert len(after)==5;assert not set(before)&set(after);assert '10.26' in page.locator('#recommendation-count').inner_text();page.screenshot(path=str(out/'new-day.png'))
 page.reload(wait_until='networkidle');page.locator('.nav[data-view=recommendations]').click();assert keys()==after
 page.clock.set_system_time(datetime.datetime.fromisoformat('2026-10-27T09:00:00+09:00'));page.evaluate('window.goodokResume()');next_day=keys();assert not set(after)&set(next_day)
 # A verified server catalogue entry joins registration and the discovery candidate pool.
 feed=json.loads((root/'tests/fixtures/research-feed.json').read_text());feed['generatedAt']='2026-10-27T00:00:00Z';feed['catalog'].append(dict(key='daily-new-tool',name='새 검증 도구',category='AI',aliases=['새 검증 도구'],officialUrl='https://newtool.example/',status='verified',origin='discovered',description='공식 출처로 검증된 신규 서비스'))
 page.evaluate('(feed)=>window.goodokOfferResearch({type:"feed",requestId:window.reqId,ok:true,feed})',feed);page.locator('.nav[data-view=subscriptions]').click();page.locator('#add').click();page.locator('#service-search').fill('새 검증 도구');assert page.locator('[data-preset=daily-new-tool]').count()==1;page.locator('#close-editor').click();browser.close()
server.shutdown();print('PASS: midnight automatically replaces daily five, no previous-day overlap, same-day resume/reload stable, next-day foreground refresh, verified new server catalogue item appears in registration')
