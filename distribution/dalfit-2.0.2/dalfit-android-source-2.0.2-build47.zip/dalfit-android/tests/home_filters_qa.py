import functools,http.server,threading,json
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root/'app/src/main/assets')));threading.Thread(target=server.serve_forever,daemon=True).start();out=root/'artifacts/home-details';out.mkdir(exist_ok=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=2,is_mobile=True,has_touch=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle');page.evaluate('document.fonts.ready');page.wait_for_timeout(180)
 assert not page.locator('#subscription-panel').is_visible();assert page.locator('#upcoming .upcoming-row').count()>=1;assert not page.locator('#spending-details').is_visible()
 page.screenshot(path=str(out/'home.png'));page.locator('#see-subscriptions').click();assert page.locator('#subscription-panel').is_visible();assert not page.locator('#overview').is_visible();page.wait_for_timeout(180);page.screenshot(path=str(out/'subscriptions.png'))
 billing=page.evaluate('(()=>{let d=new Date();return [d.getFullYear(),String(d.getMonth()+1).padStart(2,"0"),String(d.getDate()).padStart(2,"0")].join("-")})()')
 items=[dict(id='a',name='넷플릭스',category='OTT',cycle='monthly',price=17000,paused=False),dict(id='b',name='티빙',category='OTT',cycle='yearly',price=120000,paused=False),dict(id='c',name='Grok',category='AI',cycle='monthly',price=30000,paused=True),dict(id='d',name='Microsoft 365',category='생산성',cycle='yearly',price=120000,paused=False),dict(id='e',name='Lovable',category='AI',cycle='monthly',price=25000,paused=False)]
 items=[dict(item,date=billing,memo='') for item in items];page.evaluate('(items)=>localStorage.setItem("goodok-note-v1",JSON.stringify({demo:false,items}))',items);page.reload(wait_until='networkidle');assert page.locator('#monthly').inner_text()=='₩42,000';page.locator('#see-subscriptions').click()
 page.locator('[data-filter="OTT"]').click();assert page.locator('[data-subscription]').count()==2;assert page.locator('#filtered-monthly').inner_text()=='₩27,000';page.locator('#cycle-filter').select_option('yearly');assert page.locator('[data-subscription]').count()==1;assert page.locator('#filtered-monthly').inner_text()=='₩10,000'
 page.locator('#spending-details>summary').click();assert page.locator('#yearly').inner_text()=='₩120,000';assert page.locator('#donut-total').inner_text()=='₩10,000';page.locator('#status-filter').select_option('paused');assert page.locator('#empty-reset').is_visible();page.locator('#empty-reset').click();assert page.locator('[data-subscription]').count()==5
 page.locator('[data-filter="AI"]').click();page.locator('#status-filter').select_option('paused');assert page.locator('[data-subscription]').count()==1;assert page.locator('#filtered-monthly').inner_text()=='₩0';page.locator('#clear-filters').click();page.locator('#search').fill('M365');assert page.locator('[data-subscription]').count()==1;page.locator('#clear-filters').click()
 page.locator('#group-by').select_option('category');assert page.locator('.group-heading').count()==3;assert page.locator('[data-subscription]').count()==5;page.evaluate('scrollTo(0,0)');page.wait_for_timeout(180);page.screenshot(path=str(out/'grouped.png'))
 page.locator('.nav[data-view="overview"]').click();assert page.locator('#monthly').inner_text()=='₩42,000';page.locator('#see-subscriptions').click();assert page.locator('#group-by').input_value()=='category';page.locator('#clear-filters').click()
 for width,height in [(320,568),(390,844),(568,320),(844,390),(1024,768)]:
  page.set_viewport_size(dict(width=width,height=height))
  for view in ['overview','subscriptions','calendar']:
   page.locator('.nav[data-view="'+view+'"]').click();assert page.evaluate('document.documentElement.scrollWidth')<=width+1,(width,height,view)
 page.set_viewport_size(dict(width=390,height=844));page.locator('.nav[data-view="overview"]').click();before=page.evaluate('document.documentElement.scrollHeight');many=[dict(item,id='many-'+str(i)) for i,item in enumerate(items*24)];page.evaluate('(items)=>localStorage.setItem("goodok-note-v1",JSON.stringify({demo:false,items}))',many);page.reload(wait_until='networkidle');after=page.evaluate('document.documentElement.scrollHeight');assert page.locator('#upcoming .upcoming-row').count()>=1;assert page.locator('#upcoming .upcoming-row').count()==len(many);assert not page.locator('#subscription-panel').is_visible()
 assert not errors,errors;print(json.dumps(dict(result='passed',checks=['all next-month events displayed without truncation','home/detail separation','compound category/status/cycle filters','filtered totals and chart','empty-state reset','alias search','category grouping','retained selections across tabs','five viewport sizes'],homeHeightBefore=before,homeHeightWith120Records=after),ensure_ascii=False));browser.close()
server.shutdown()
