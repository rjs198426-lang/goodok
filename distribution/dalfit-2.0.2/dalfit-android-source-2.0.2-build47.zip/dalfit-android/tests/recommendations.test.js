import test from 'node:test';
import assert from 'node:assert/strict';
import {services,recommendServices,alternativeServices,currentDiscounts,discountOffers} from '../app/src/main/assets/catalog.js';
test('five cross-category recommendations exclude registered aliases without weighting categories',()=>{
 const items=[{name:'챗지피티',category:'AI',paused:false},{name:'넷플릭스',category:'OTT',paused:true}],before=JSON.stringify(items),list=recommendServices(items);
 assert.equal(list.length,5);assert.ok(!list.some(s=>['chatgpt','netflix'].includes(s.key)));
 assert.ok(new Set(list.map(s=>s.key)).size===5);
 assert.deepEqual(list.map(s=>s.key),recommendServices(items.map(s=>({...s,category:'VPN'}))).map(s=>s.key));
 assert.equal(JSON.stringify(items),before);
 assert.equal(recommendServices([]).length,5);assert.equal(recommendServices(services).length,0);
 assert.equal(recommendServices(services.slice(0,-2)).length,2);
});
test('substitutes match purpose, exclude paused sources and all registered targets, and never mutate source',()=>{
 const items=[{name:'챗지피티',category:'AI',price:29000,paused:false},{name:'Claude',category:'AI',paused:true},{name:'Spotify',price:10900,paused:false},{name:'Lovable',paused:false}];
 const before=JSON.stringify(items),list=alternativeServices(items);
 assert.equal(list.length,2);assert.equal(list[0].source.name,'챗지피티');assert.equal(list[0].service.key,'gemini');assert.equal(list[1].service.key,'youtube-music');
 assert.equal(JSON.stringify(items),before);assert.equal(alternativeServices([]).length,0);assert.equal(alternativeServices(services).length,0);
 assert.equal(alternativeServices([{name:'Lovable'},{name:'Krea AI',paused:true},{name:'알수없는 서비스'}]).length,0);
});
test('offers show only verified month within six days, and respect actual ending dates',()=>{
 assert.equal(currentDiscounts(discountOffers,'2026-10-25').length,2);
 assert.equal(currentDiscounts(discountOffers,'2026-10-24').length,0);
 assert.equal(currentDiscounts(discountOffers,'2026-10-31').length,2);
 assert.equal(currentDiscounts(discountOffers,'2026-11-01').length,0);
 assert.equal(currentDiscounts(discountOffers,'invalid').length,0);
 const fixture=[{checked:'2026-10-25',ends:'2026-10-26'}];
 assert.equal(currentDiscounts(fixture,'2026-10-26').length,1);assert.equal(currentDiscounts(fixture,'2026-10-27').length,0);
 assert.equal(currentDiscounts([{checked:'2026-10-01',ends:null}],'2026-10-08').length,0);
 for(const offer of discountOffers){assert.match(offer.source,/^https:\/\//);assert.equal(offer.ends,null);assert.ok(offer.conditions.length>30);}
});

test('discovery rotates by local day without changing within a day',()=>{
 const first=recommendServices([],'2026-10-25').map(s=>s.key);assert.deepEqual(first,recommendServices([],'2026-10-25').map(s=>s.key));assert.notDeepEqual(first,recommendServices([],'2026-10-26').map(s=>s.key));
});

test('daily discovery avoids yesterday when enough choices exist, including month/year/leap boundaries',()=>{
 const dates=['2026-12-31','2027-01-01','2028-02-28','2028-02-29','2028-03-01'];
 for(const date of dates){const parsed=new Date(date+'T12:00:00Z');parsed.setUTCDate(parsed.getUTCDate()+1);const tomorrow=parsed.toISOString().slice(0,10),before=recommendServices([],date).map(item=>item.key),after=recommendServices([],tomorrow).map(item=>item.key);assert.equal(after.length,5);assert.equal(before.filter(key=>after.includes(key)).length,0);}
 const allSeen=new Set();for(let day=1;day<=11;day++)for(const item of recommendServices([],`2026-10-${day}`))allSeen.add(item.key);assert.equal(allSeen.size,services.length);
});
test('scarce unowned choices show actual candidates; discovered entries cannot monopolize every day',()=>{
 const owned=services.slice(8).map(item=>({name:item.name})),first=recommendServices(owned,'2026-10-25'),second=recommendServices(owned,'2026-10-26');assert.equal(first.length,5);assert.equal(second.length,5);assert.equal(first.filter(item=>second.some(other=>other.key===item.key)).length,2);
 const almostAll=services.slice(3).map(item=>({name:item.name}));assert.equal(recommendServices(almostAll,'2026-10-25').length,3);
 const flags=services.slice(0,5).map(item=>item.discovered);try{services.slice(0,5).forEach(item=>item.discovered=true);const before=recommendServices([],'2026-10-25').map(item=>item.key),after=recommendServices([],'2026-10-26').map(item=>item.key);assert.equal(before.filter(key=>after.includes(key)).length,0);}finally{services.slice(0,5).forEach((item,index)=>{if(flags[index]===undefined)delete item.discovered;else item.discovered=flags[index];});}
});
