import functools,http.server,threading,json,datetime
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];out=root/'artifacts/ux-review';out.mkdir(exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root/'app/src/main/assets')));threading.Thread(target=server.serve_forever,daemon=True).start()
feed=json.loads((root/'tests/fixtures/research-feed.json').read_text())
items=[dict(id='n',name='넷플릭스',price=17000,date='2024-01-01',category='OTT'),dict(id='s',name='Spotify',price=10900,date='2024-01-03',category='음악'),dict(id='y',name='YouTube Premium',price=14900,date='2024-01-09',category='OTT'),dict(id='a',name='Notion',price=120000,date='2024-11-05',category='생산성',cycle='yearly'),dict(id='i',name='iCloud+',price=1100,date='2024-01-20',category='생산성'),dict(id='p',name='쿠팡 와우',price=7890,date='2024-01-26',category='쇼핑',paused=True)]
items=[dict(dict(cycle='monthly',memo='',paused=False),**item) for item in items]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,timezone_id='Asia/Seoul',device_scale_factor=2);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.clock.install(time=datetime.datetime(2026,10,25,12));page.add_init_script('window.GoodokResearch={loadBenefits:id=>window.reqId=id}')
 page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle')
 page.evaluate('(items)=>localStorage.setItem("goodok-note-v1",JSON.stringify({demo:false,items}))',items);page.reload(wait_until='networkidle')
 def complete(value=feed):page.evaluate('(feed)=>window.goodokOfferResearch({type:"feed",requestId:window.reqId,ok:true,feed})',value)
 def nav(view):page.locator('.nav[data-view="'+view+'"]').click()
 def part(key):
  nav('recommendations');page.locator('#tab-'+key).click()
 def capture(name):
  page.evaluate('window.scrollTo(0,0)');page.wait_for_timeout(250);page.screenshot(path=str(out/(name+'.png')))
 complete();assert page.locator('#upcoming [data-edit]').count()==2;assert page.locator('#demo-bar').is_hidden();assert page.locator('#home-all-subscriptions').inner_text().startswith('내 구독 전체 6개');total=page.locator('#monthly').inner_text();assert page.locator('#overview #spending-details').count()==1;assert page.locator('#overview').evaluate('(el)=>el.children[1].id')=='spending-details';assert page.locator('#subscriptions-view #spending-details').count()==0;assert page.locator('#spending-details > summary').count()==0;assert page.locator('#spending-details').evaluate('(el)=>el.tagName')=='SECTION';assert page.locator('#donut').is_visible();capture('home')
 page.locator('#home-all-subscriptions').click();assert page.locator('[data-subscription]').count()==6;assert not page.locator('#advanced-filters').evaluate('(el)=>el.open');assert page.locator('#status-filter').is_hidden();capture('subscriptions')
 page.locator('#advanced-filters > summary').click();page.locator('#status-filter').select_option('paused');assert page.locator('[data-subscription]').count()==1;page.locator('#clear-filters').click();assert page.locator('[data-subscription]').count()==6
 page.locator('#search').fill('MISSING');assert page.locator('#empty').is_visible();page.locator('#empty-reset').click();assert page.locator('[data-subscription]').count()==6
 nav('overview');page.locator('#see-calendar').click();assert page.locator('#calendar-total').inner_text()==total;assert page.locator('.nav[aria-current]').get_attribute('data-view')=='subscriptions';assert page.locator('#subscriptions-view').is_visible();assert page.locator('#subscription-panel').is_hidden();assert page.locator('.nav').count()==5;page.locator('[data-day="3"]').click();assert page.locator('.calendar-entry').count()==1;capture('calendar')
 part('picks');assert page.locator('#recommendation-list [data-recommend]').count()==5;assert page.locator('#add').is_hidden();assert page.locator('#recommendation-context').is_hidden();capture('discover')
 part('offers');assert page.locator('.discount-card').count()==3;assert not page.locator('.research-audit').evaluate('(el)=>el.open');assert page.locator('#research-coverage').is_hidden();assert page.locator('#discount-list').evaluate('(el)=>el.getBoundingClientRect().top')<360
 assert page.locator('.offer-terms').first.locator('p').is_hidden();page.locator('.offer-terms > summary').first.click();assert page.locator('.offer-terms').first.locator('p').is_visible();page.locator('.offer-terms > summary').first.click();capture('offers')
 page.locator('.research-audit > summary').click();assert page.locator('#research-coverage').is_visible();assert 'Naver' in page.locator('#research-providers').inner_text();page.locator('.research-audit > summary').click()
 part('alternatives');assert page.locator('[data-current=y]').count()==0;targets=page.locator('.comparison-card').evaluate_all('(cards)=>cards.map(card=>card.dataset.target)');assert len(set(targets))==len(targets);assert page.locator('.comparison-card').count()==2;assert page.locator('.comparison-grid').first.is_hidden();capture('comparison')
 page.locator('.comparison-details > summary').first.click();assert page.locator('.comparison-grid').first.is_visible();assert '장점' in page.locator('.comparison-grid').first.inner_text()
 # Background refresh must not reset reading state, including changed content.
 page.evaluate('window.goodokResume()');assert page.locator('.comparison-details').first.evaluate('(el)=>el.open');complete();assert page.locator('.comparison-details').first.evaluate('(el)=>el.open')
 refreshed=json.loads(json.dumps(feed));next(plan for plan in refreshed['plans'] if plan['service']=='disney-plus')['amount']=9500
 page.evaluate('window.goodokResume()');complete(refreshed);assert page.locator('.comparison-details').first.evaluate('(el)=>el.open');assert '₩9,500' in page.locator('.comparison-card').first.inner_text();page.locator('.comparison-details > summary').first.click()
 page.locator('.comparison-actions [data-recommend]').first.click();assert page.locator('#details-panel').is_visible();page.locator('#close-editor').click();assert page.evaluate('JSON.parse(localStorage.getItem("goodok-note-v1")).items.length')==6
 # Distinguish unavailable pricing from an actual lack of benefit.
 no_prices=dict(feed,plans=[]);page.evaluate('window.goodokResume()');complete(no_prices);assert '정상 요금이 아직 부족' in page.locator('#alternative-list').inner_text();assert '비교 가능한 대안' in page.locator('#alternative-list').inner_text();capture('comparison-no-price')
 page.locator('[data-go=subscriptions]').click();assert page.locator('#subscription-panel').is_visible()
 # Settings: backup round-trip, rejection, cancel protection, reset, feed address and Back.
 nav('settings');assert page.locator('#page-title').inner_text()=='설정';assert page.locator('#add').is_hidden();assert page.locator('#settings-panel .feed-config').count()==1;capture('settings')
 page.locator('#backup-open').click();backup=page.locator('#backup-text').input_value();assert json.loads(backup)['items']==items;assert page.locator('#backup-text').evaluate('(el)=>el.readOnly');page.locator('#backup-close').click()
 page.locator('#restore-open').click();page.locator('#backup-text').fill('{broken');page.locator('#backup-action').click();assert not page.locator('#confirm').evaluate('(el)=>el.open');assert page.evaluate('JSON.parse(localStorage.getItem("goodok-note-v1")).items.length')==6
 invalid=json.loads(backup);invalid['items'][1]['id']=invalid['items'][0]['id'];page.locator('#backup-text').fill(json.dumps(invalid));page.locator('#backup-action').click();assert not page.locator('#confirm').evaluate('(el)=>el.open')
 page.locator('#backup-text').fill(backup);page.locator('#backup-action').click();page.locator('#confirm-cancel').click();assert page.locator('#backup-dialog').is_visible();page.locator('#backup-action').click();page.locator('#confirm-ok').click();assert page.locator('#backup-dialog').is_hidden();assert page.evaluate('JSON.parse(localStorage.getItem("goodok-note-v1")).items')==items
 page.locator('#erase-records').click();page.locator('#confirm-cancel').click();assert page.evaluate('JSON.parse(localStorage.getItem("goodok-note-v1")).items.length')==6
 page.locator('#erase-records').click();page.locator('#confirm-ok').click();assert '구독 0개 · 고정비 0개' in page.locator('#settings-records').inner_text();nav('overview');assert page.locator('#donut-total').inner_text()=='₩0'
 nav('settings');page.locator('#restore-open').click();page.locator('#backup-text').fill(backup);page.locator('#backup-action').click();page.locator('#confirm-ok').click();assert page.evaluate('JSON.parse(localStorage.getItem("goodok-note-v1")).items')==items
 page.locator('#settings-refresh').click();assert page.locator('#settings-refresh').is_disabled();complete();assert page.locator('#settings-refresh').is_enabled();assert page.evaluate('window.goodokBack()');assert page.locator('#overview').is_visible()
 # Empty account: exactly one contextual action opens registration.
 page.evaluate('localStorage.setItem("goodok-note-v1",JSON.stringify({demo:false,items:[]}))');page.reload(wait_until='networkidle');complete();part('alternatives');assert '먼저 등록' in page.locator('#alternative-list').inner_text();page.locator('[data-add-own]').click();assert page.locator('#presets').is_visible();page.locator('#close-editor').click()
 # Large data still fully available in management while home stays bounded.
 many=[dict(items[0],id='many-'+str(i)) for i in range(75)];page.evaluate('(items)=>localStorage.setItem("goodok-note-v1",JSON.stringify({demo:false,items}))',many);page.reload(wait_until='networkidle');complete();assert page.locator('#upcoming [data-edit]').count()==2;nav('subscriptions');assert page.locator('[data-subscription]').count()==75;page.locator('#subscriptions [data-edit]').last.click();assert page.locator('#service-name').input_value()=='넷플릭스';page.locator('#close-editor').click()
 for width,height in [(320,568),(390,844),(568,320),(1024,768)]:
  page.set_viewport_size({'width':width,'height':height})
  for view in ['overview','subscriptions','fixedcosts','recommendations','settings']:
   nav(view)
   if view=='overview':
    assert page.evaluate('document.documentElement.scrollHeight')<=height+1,(width,height,page.evaluate('document.documentElement.scrollHeight'))
    assert page.locator('.home-actions').evaluate('(el)=>el.getBoundingClientRect().bottom')<=page.locator('.sidebar nav').evaluate('(el)=>el.getBoundingClientRect().top') if width<=760 and height>500 else True
   if view=='subscriptions':
    for mode in ['calendar','list']:
     page.locator('#tab-'+mode).click();assert page.evaluate('document.documentElement.scrollWidth')<=width+1
   assert page.evaluate('document.documentElement.scrollWidth')<=width+1
  for key in ['picks','offers','alternatives']:
   part(key);assert page.locator('#recommendation-panel [role=tabpanel]:visible').count()==1;assert page.evaluate('document.documentElement.scrollWidth')<=width+1
 page.evaluate('localStorage.removeItem("goodok-benefit-feed-v2")');page.reload(wait_until='networkidle');part('offers');assert page.locator('.offer-skeleton').count()==1
 page.evaluate('window.goodokOfferResearch({type:"feed",requestId:window.reqId,ok:false})');assert '불러오지 못했어요' in page.locator('#discount-list').inner_text();assert page.locator('#research-retry').is_enabled();page.locator('#research-retry').click();complete();assert page.locator('.discount-card').count()==3
 page.evaluate('(items)=>localStorage.setItem("goodok-note-v1",JSON.stringify({demo:false,items}))',items);page.reload(wait_until='networkidle');complete();assert page.locator('#monthly').inner_text()=='₩163,900'
 page.clock.set_system_time(datetime.datetime(2026,11,1,12));page.evaluate('window.goodokResume()');assert page.locator('#month-pill').inner_text()=='2026년 12월';assert page.locator('#monthly').inner_text()=='₩43,900'
 assert not errors,errors
 print(json.dumps({'result':'passed','checks':['home limited to 2 and complete management list','month total/calendar preserved','working advanced filters and empty reset','offer content above fold with audit below','terms and full comparison disclosure work','YouTube not substituted with OTT','no repeated target services','explicit empty-pricing state and registration action','75 records retained and last editable','background refresh retains expanded reading state','loading and network failure recovery','month rollover while app retained','settings backup restore validation cancel erase refresh and Back','all destinations at 4 sizes']},ensure_ascii=False));browser.close()
server.shutdown()
