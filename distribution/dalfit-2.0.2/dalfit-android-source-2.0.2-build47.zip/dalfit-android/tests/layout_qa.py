import functools,http.server,threading,json
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root/'app/src/main/assets')))
threading.Thread(target=server.serve_forever,daemon=True).start()
out=root/'artifacts/optimized';out.mkdir(exist_ok=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=2,is_mobile=True,has_touch=True);errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
 page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle');page.evaluate('document.fonts.ready')
 page.screenshot(path=str(out/'home.png'))
 metrics=page.evaluate('''()=>({width:innerWidth,height:innerHeight,homeHeight:document.documentElement.scrollHeight,upcomingTop:Math.round(document.querySelector('#upcoming').getBoundingClientRect().top),upcomingBottom:Math.round(document.querySelector('#upcoming').getBoundingClientRect().bottom),navTop:Math.round(document.querySelector('nav').getBoundingClientRect().top)})''')
 for width,height in [(320,568),(360,640),(390,844),(430,932),(568,320),(844,390),(1024,600)]:
  page.set_viewport_size({'width':width,'height':height})
  for view in ['overview','subscriptions','calendar']:
   page.locator('.nav[data-view="'+view+'"]').click()
   assert page.evaluate('document.documentElement.scrollWidth')<=width+1,(width,height,view,'horizontal overflow')
   assert page.evaluate('innerWidth')<=width+1,(width,height,view,'auto zoom')
  page.locator('#add').click();page.locator('#service-search').fill('Grok');page.locator('[data-preset="grok"]').click();page.locator('#memo').fill('화면 크기가 바뀌어도 작성 중인 내용 유지')
  if width==390:
   page.set_viewport_size({'width':390,'height':350});page.locator('#memo').fill('키보드처럼 낮아진 화면에서도 입력')
   assert page.locator('#memo').evaluate('(element)=>{let r=element.getBoundingClientRect();return document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)===element}')
   page.screenshot(path=str(out/'short-input.png'))
   assert page.locator('button[type="submit"]').is_visible()
   page.set_viewport_size({'width':844,'height':390});assert page.locator('#memo').input_value()=='키보드처럼 낮아진 화면에서도 입력'
   page.set_viewport_size({'width':390,'height':844})
  page.locator('#close-editor').click()
 page.set_viewport_size({'width':320,'height':568})
 # Many high-value records stress amount widths and deferred offscreen list rendering.
 billing=page.evaluate('(()=>{const d=new Date();return [d.getFullYear(),String(d.getMonth()+1).padStart(2,"0"),String(d.getDate()).padStart(2,"0")].join("-")})()')
 records=[dict(id='stress-'+str(i),name='긴 서비스 이름을 표시하는 구독 요금제 테스트 '+str(i),price=100000000,cycle='monthly',date=billing,category='AI',memo='가족과 함께 사용하는 장기 구독 요금제',paused=False) for i in range(120)]
 page.evaluate('(state)=>localStorage.setItem("goodok-note-v1",JSON.stringify(state))',dict(demo=False,items=records));page.reload(wait_until='networkidle')
 assert page.locator('#subscriptions tr').count()==120;assert page.locator('#monthly').inner_text()=='₩12,000,000,000'
 assert page.evaluate('document.documentElement.scrollWidth')<=321
 for selector in ['#monthly','#soon-amount','#donut-total']:
  assert page.locator(selector).evaluate('(element)=>element.scrollWidth<=element.clientWidth+1'),selector
 page.locator('.nav[data-view="subscriptions"]').click();page.locator('#search').fill('테스트 119');assert page.locator('#subscriptions tr').count()==1
 assert page.evaluate('document.documentElement.scrollWidth')<=321
 page.locator('.nav[data-view="calendar"]').click();assert page.locator('.calendar-entry').count()==120
 assert not errors,errors
 print(json.dumps(dict(result='passed',viewports=7,metrics=metrics,checks=['small screen bounds','short input window','rotation state','120 long/high-value subscriptions','calendar after deferred render']),ensure_ascii=False))
 browser.close()
server.shutdown()
