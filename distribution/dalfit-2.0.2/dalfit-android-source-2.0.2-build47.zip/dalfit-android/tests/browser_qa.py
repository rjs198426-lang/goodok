import functools,http.server,threading,json
from pathlib import Path
from playwright.sync_api import sync_playwright
root=str(Path(__file__).resolve().parents[1]/'app/src/main/assets')
class QuietHandler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=root))
threading.Thread(target=server.serve_forever,daemon=True).start()
out=Path(__file__).resolve().parents[1]/'artifacts/design';out.mkdir(parents=True,exist_ok=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':900},device_scale_factor=2,is_mobile=True,has_touch=True)
 errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
 page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle');page.evaluate('document.fonts.ready')
 assert page.locator('#subscriptions tr').count()==6
 assert page.locator('#filtered-monthly').inner_text()=='₩61,790'
 assert page.evaluate('Array.from(document.images).every(i=>i.complete&&i.naturalWidth>0)')
 page.wait_for_timeout(230);page.screenshot(path=str(out/'home.png'));page.wait_for_timeout(230);page.screenshot(path=str(out/'home-full.png'),full_page=True)
 page.locator('.nav[data-view="subscriptions"]').click();page.wait_for_timeout(230);page.screenshot(path=str(out/'subscriptions.png'))
 page.locator('#add').click();assert page.locator('#presets').is_visible();assert not page.locator('#details-panel').is_visible()
 page.wait_for_timeout(230);page.screenshot(path=str(out/'choose-service.png'))
 page.locator('#service-search').fill('M365');page.locator('[data-preset="microsoft365"]').click()
 assert page.locator('#details-panel').is_visible();assert not page.locator('#presets').is_visible()
 page.wait_for_timeout(230);page.screenshot(path=str(out/'subscription-details.png'))
 page.locator('#close-editor').click();page.locator('.nav[data-view="calendar"]').click();page.wait_for_timeout(230);page.screenshot(path=str(out/'calendar.png'))
 event_day=page.locator('.calendar-cell:has(.calendar-dot) button').first
 if event_day.count():
  event_day.click();assert page.locator('.agenda-item').count()>0
  assert page.locator('#show-month').is_visible();page.locator('#show-month').click()
 for width in [320,360,390,760,1024,1440]:
  page.set_viewport_size({'width':width,'height':900})
  for view in ['overview','subscriptions','calendar']:
   page.locator('.nav[data-view="'+view+'"]').click()
   assert page.evaluate('window.scrollY')==0,(width,view,'scroll position');assert page.evaluate('document.documentElement.scrollWidth')<=width+1,(width,view,'layout wider than screen');assert page.evaluate('innerWidth')<=width+1,(width,view,'viewport auto-zoomed');assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth'),(width,view,page.evaluate('document.documentElement.scrollWidth'))
 page.set_viewport_size({'width':390,'height':900});page.locator('#add').click();page.locator('#service-search').fill('M365');page.locator('[data-preset="microsoft365"]').click();page.locator('#price').fill('9900');page.locator('button[type="submit"]').click();assert not page.locator('#editor').is_visible();assert page.locator('#monthly').inner_text()=='₩9,900'
 page.reload(wait_until='networkidle');assert page.locator('#subscriptions tr').count()==1;assert page.locator('#monthly').inner_text()=='₩9,900'
 page.locator('.nav[data-view="subscriptions"]').click();page.locator('#subscriptions [data-edit]').first.click();page.locator('#paused').check();page.locator('button[type="submit"]').click();assert page.locator('#monthly').inner_text()=='₩0'
 page.locator('#subscriptions [data-edit]').first.click();page.locator('#delete-sub').click();page.locator('#confirm-ok').click();assert page.locator('#subscriptions tr').count()==0
 assert not errors,errors
 print(json.dumps({'result':'passed','views':['home','subscriptions','service library','details','calendar'],'widths':[320,360,390,760,1024,1440],'flows':['catalogue selection','save','reload persistence','edit','pause','delete','calendar day selection'],'screenshots':str(out)},ensure_ascii=False))
 browser.close()
server.shutdown()
