import functools,http.server,threading,json,datetime,copy
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];out=root/'artifacts/release38';out.mkdir(exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root/'app/src/main/assets')));threading.Thread(target=server.serve_forever,daemon=True).start()
base=dict(cycle='monthly',date='2026-01-15',memo='',paused=False)
items=[dict(base,id='m',name='관리비',kind='variable',category='주거',price=120000,estimated=True),dict(base,id='g',name='도시가스',kind='fixed',category='공과금',price=45000,estimated=True),dict(base,id='h',name='사진',kind='variable',category='취미',price=100000,actuals={'2026-10':40000})]
feed=json.loads((root/'tests/fixtures/research-feed.json').read_text());feed['offers']=[dict(feed['offers'][0],id='unique'+str(i),service='chatgpt',title='독립 행사 '+str(i),benefit='특별 혜택 '+str(i)) for i in range(7)];feed['generatedAt']='2026-10-26T01:00:00Z'
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':390,'height':844},timezone_id='Asia/Seoul');page.clock.install(time=datetime.datetime.fromisoformat('2026-10-26T10:00:00+09:00'));errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.add_init_script('window.GoodokResearch={loadBenefits:id=>window.reqId=id}');page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle');page.evaluate('(items)=>localStorage.setItem("goodok-note-v1",JSON.stringify({demo:false,items}))',items);page.reload(wait_until='networkidle')
 stored=page.evaluate('JSON.parse(localStorage.getItem("goodok-note-v1"))');assert [i['kind'] for i in stored['items']]==['fixed','fixed','variable'];assert stored['items'][2]['budget']==100000;assert stored['items'][1]['actualPending'];assert stored['items'][1]['price']==0
 page.locator('[data-home-kind=variable]').click();assert page.locator('#home-focus-total').inner_text()=='₩40,000';assert '100,000' in page.locator('#taste-home-budget').inner_text();assert '40%' in page.locator('#taste-home-budget').inner_text();page.screenshot(path=str(out/'taste-home.png'))
 page.locator('.nav[data-view=subscriptions]').click();page.locator('[data-cost-kind=fixed]').click();page.locator('#add').click();page.locator('[data-preset="fixed:social-fund"]').click();assert page.locator('#category').input_value()=='친목';page.locator('#price').fill('50000');page.locator('#subscription-form button[type=submit]').click();assert any(i['name']=='곗돈' and i['price']==50000 for i in page.evaluate('JSON.parse(localStorage.getItem("goodok-note-v1")).items'))
 page.locator('[data-cost-kind=variable]').click();page.locator('#subscriptions [data-edit=h]').click();assert page.locator('#taste-budget').input_value()=='100000';page.locator('#actual-month').fill('2026-11');assert page.locator('#actual-amount').input_value()=='';page.locator('#subscription-form button[type=submit]').click();page.locator('#cost-next').click();assert page.locator('#filtered-monthly').inner_text()=='₩0'
 page.locator('.nav[data-view=settings]').click();page.locator('#category-name').fill('문화생활');page.locator('#category-kind').select_option('variable');page.locator('#category-save').click();assert page.locator('#category-message').inner_text()=='저장했어요.';page.locator('#category-existing').select_option('취미·레저');page.locator('#category-name').fill('사진취미');page.locator('#category-save').click();assert next(i for i in page.evaluate('JSON.parse(localStorage.getItem("goodok-note-v1")).items') if i['id']=='h')['category']=='사진취미'
 page.reload(wait_until='networkidle');page.locator('.nav[data-view=settings]').click();page.locator('#category-existing').select_option('문화생활');page.locator('#release-notes-open').click();assert '1.1.0' in page.locator('#release-notes-body').inner_text();page.locator('#release-notes-close').click();page.locator('#backup-open').click();backup=page.locator('#backup-text').input_value();assert json.loads(backup)['categories'];page.locator('#backup-close').click();page.locator('#restore-open').click();page.locator('#backup-text').fill(backup);page.locator('#backup-action').click();page.locator('#confirm-ok').click()
 page.evaluate('(feed)=>window.goodokOfferResearch({type:"feed",requestId:window.reqId,ok:true,feed})',feed)
 for width,height in [(320,568),(360,640),(390,844),(412,915),(568,320),(1024,768)]:
  page.set_viewport_size(dict(width=width,height=height));page.locator('.nav[data-view=recommendations]').click();page.locator('[data-part=picks]').click()
  for kind in ['subscription','taste']:
   page.locator('[data-discovery-kind='+kind+']').click();assert page.locator('.discovery-card').count()==8;page.wait_for_timeout(120)
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),(width,height,kind,'width')
   if height>500 and width<761:assert page.locator('#recommendation-list').evaluate('(e)=>e.getBoundingClientRect().bottom')<=page.locator('.sidebar nav').evaluate('(e)=>e.getBoundingClientRect().top')+1,(width,height,kind,'nav overlap')
  page.locator('[data-part=offers]').click();assert page.locator('.discount-card').count()==4;page.wait_for_timeout(120)
  if height>500 and width<761:assert page.locator('#offer-pagination').evaluate('(e)=>e.getBoundingClientRect().bottom')<=page.locator('.sidebar nav').evaluate('(e)=>e.getBoundingClientRect().top')+1,(width,height,'offers overlap')
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),(width,height,'offers width')
  if width==390:page.wait_for_timeout(250);page.screenshot(path=str(out/'offers.png'));page.locator('[data-part=picks]').click();page.wait_for_timeout(250);page.screenshot(path=str(out/'taste-recommendations.png'));page.locator('[data-part=offers]').click()
  page.locator('#offer-next').click();assert page.locator('.discount-card').count()==3;page.locator('#offer-prev').click()
 page.locator('[data-part=picks]').click();page.locator('[data-discovery-kind=taste]').click();page.locator('[data-taste]').first.click();assert page.locator('#category').input_value() in ['사진취미','도서 구입','공연·전시'];page.locator('#actual-amount').fill('20000');page.locator('#subscription-form button[type=submit]').click();assert not page.locator('#editor').evaluate('(e)=>e.open');assert errors==[],errors
 browser.close()
server.shutdown();print('PASS: migration, actual-only totals, taste budget ratios, social fund, custom category persistence/rename/backup restore, build changelog, recommendation8 and benefits4 at six sizes')
