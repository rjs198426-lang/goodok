import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {services,discoverableServices,discoveryPurposes} from '../app/src/main/assets/catalog.js';
import {validateFeed,activeTasteSuggestions,createBenefitLoader} from '../app/src/main/assets/offers.js';
import {automaticAlternatives} from '../app/src/main/assets/comparisons.js';
const fixture=()=>JSON.parse(fs.readFileSync(new URL('./fixtures/research-feed.json',import.meta.url)));
test('any shared paid purpose hides a bundle and owning a bundle covers its multiple purposes',()=>{
 const bundle={key:'bundle-v3',name:'AI Bundle V3',category:'AI',purpose:'coding',purposes:['assistant','image','coding','nonsense',{},'llm'],aliases:['AI Bundle V3']};
 try{services.push(bundle);assert.deepEqual(discoveryPurposes(bundle),['coding','assistant','image']);assert.ok(!discoverableServices([{name:'ChatGPT'}]).some(s=>s.key===bundle.key));
  const pool=discoverableServices([{name:bundle.name}]);for(const key of ['chatgpt','claude','krea','midjourney','cursor'])assert.ok(!pool.some(s=>s.key===key));
  assert.ok(discoverableServices([{name:bundle.name,paused:true}]).some(s=>s.key==='chatgpt'));
 }finally{services.pop();}
});
test('old feed remains compatible and invalid official activity claims are discarded',()=>{
 const feed=fixture();assert.deepEqual(validateFeed(feed).tasteSuggestions,[]);
 const activity={id:'activity',name:'가을 전시',category:'공연·전시',status:'official_verified',source:'https://www.museum.go.kr/exhibition/1',starts:'2026-10-01',ends:'2026-11-30',verifiedAt:'2026-10-25T10:00:00Z'};
 feed.tasteSuggestions=[activity,{...activity,id:'fake',source:'https://museum.go.kr.evil.example/exhibit'},{...activity,id:'bad-period',ends:'2026-01-01'},{...activity,id:'unverified',status:'candidate'}];
 assert.deepEqual(validateFeed(feed).tasteSuggestions.map(s=>s.id),['activity']);
});
test('dated official activities expire, future checks and duplicate results are hidden',()=>{
 const item={id:'a',name:'전시',category:'공연·전시',status:'official_verified',source:'https://www.mmca.go.kr/exhibition/1',starts:'2026-10-01',ends:'2026-10-27',verifiedAt:'2026-10-27T00:00:00Z'};
 const feed={tasteSuggestions:[item,item,{...item,id:'stale',verifiedAt:'2026-10-01T00:00:00Z'},{...item,id:'future',verifiedAt:'2026-11-01T00:00:00Z'}]};
 assert.deepEqual(activeTasteSuggestions(feed,new Date('2026-10-27T10:00:00Z')).map(s=>s.id),['a']);assert.equal(activeTasteSuggestions(feed,new Date('2026-10-28T10:00:00Z')).length,0);
});
test('a same-capability alternative needs an actual cost advantage; paid feature gains may cost extra',()=>{
 const f=fixture(),source=f.plans.find(p=>p.service==='spotify'),target=f.plans.find(p=>p.service==='apple-music'),proof=caps=>({capabilities:caps,evidence:[{field:'amount',quote:'official price'},...Object.keys(caps).map(k=>({field:'capability.'+k,quote:'official feature'}))]});
 const base={...source,...proof({music:true,offline:true,devices:1})},equal={...target,...proof({music:true,offline:true,devices:1}),amount:base.amount},item={name:'Spotify',serviceKey:'spotify',price:base.amount,cycle:'monthly'},now=new Date('2026-10-25T12:00:00Z');
 assert.equal(automaticAlternatives([item],[base,equal],f.catalog,now).length,0);assert.equal(automaticAlternatives([item],[base,{...equal,amount:base.amount+100}],f.catalog,now).length,0);
 assert.equal(automaticAlternatives([item],[base,{...equal,amount:base.amount-100}],f.catalog,now)[0].level,'동등');
 assert.equal(automaticAlternatives([item],[base,{...equal,...proof({music:true,offline:true,devices:2}),amount:base.amount+100}],f.catalog,now)[0].level,'상위');
});
test('loader reports verified benefits rather than presenting candidate volume as a discovery success',()=>{
 let event;const f=fixture();f.research={candidateCount:500,factChecks:87};const storage={getItem:()=>null,setItem:()=>{}},loader=createBenefitLoader({storage,bridge:{loadBenefits:id=>event=id},changed:()=>{},now:()=>new Date('2026-10-25T12:00:00Z'),schedule:()=>1,cancel:()=>{}});
 loader.start();loader.receive({type:'feed',requestId:event,ok:true,feed:f});assert.ok(!loader.snapshot().message.includes('500'));assert.ok(loader.snapshot().message.includes('공식 출처 확인 혜택'));
});
