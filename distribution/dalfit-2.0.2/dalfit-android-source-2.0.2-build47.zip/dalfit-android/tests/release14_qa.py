import functools,http.server,threading,json,datetime
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root/'app/src/main/assets')));threading.Thread(target=server.serve_forever,daemon=True).start()
feed=json.loads((root/'tests/fixtures/research-feed.json').read_text());feed['generatedAt']='2026-10-27T01:00:00Z';service=dict(key='fresh-app',name='새 개발 도구',category='개발 도구',aliases=['새 개발 도구'],status='verified',officialUrl='https://fresh.example/pricing')
feed['catalogUpdate']=dict(version='2026-10-27',publishedAt=feed['generatedAt'],categories=[dict(name='개발 도구',kind='subscription'),dict(name='AI',kind='subscription')],services=[service,dict(service,key='chatgpt',name='ChatGPT',category='AI',aliases=['ChatGPT'])])
base=dict(cycle='monthly',date='2026-10-01',memo='',paused=False)
state=dict(demo=False,costSchema=2,categories=[dict(source='AI',name='나의 AI',kind='subscription')],items=[dict(base,id='a',name='ChatGPT',category='나의 AI',price=29000),dict(base,id='b',name='도서',category='도서 구입',kind='variable',price=0,actuals={'2026-10':10000})])
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page(viewport=dict(width=390,height=844),timezone_id='Asia/Seoul');errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.clock.install(time=datetime.datetime.fromisoformat('2026-10-27T10:00:00+09:00'))
 page.add_init_script('window.GoodokResearch={loadBenefits:id=>window.req=id,syncReminders:()=>{},notificationStatus:()=>JSON.stringify({enabled:true,allowed:true,asked:true,scheduledAt:1793145600000,timezone:"Asia/Seoul",batteryExempt:false}),exportBackup:s=>window.exported=s,importBackup:()=>window.importCalled=true,testNotification:()=>window.goodokNotificationTest(true)}')
 page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle');page.evaluate('(s)=>localStorage.setItem("goodok-note-v1",JSON.stringify(s))',state);page.reload(wait_until='networkidle')
 page.evaluate('(f)=>window.goodokOfferResearch({type:"feed",requestId:window.req,ok:true,feed:f})',feed)
 page.locator('[data-view=settings]').click();assert '2026-10-27' in page.locator('#category-update-status').inner_text();assert '개발 도구' in page.locator('#category-existing').inner_text();assert '나의 AI' in page.locator('#category-existing').inner_text()
 page.locator('#category-update').click();page.evaluate('(f)=>window.goodokOfferResearch({type:"feed",requestId:window.req,ok:true,feed:f})',feed);assert len(page.evaluate('JSON.parse(localStorage.getItem("goodok-note-v1")).categories'))==2
 page.locator('#payments-open').click();assert '없어요' in page.locator('#payment-history').inner_text();page.locator('#payment-item').select_option('a');page.locator('#payment-amount').fill('27000');page.locator('#payment-form button').click();assert page.locator('#payment-total').inner_text()=='₩37,000'
 page.locator('#payment-item').select_option('b');page.locator('#payment-amount').fill('15000');page.locator('#payment-form button').click();assert page.locator('#payment-total').inner_text()=='₩52,000';saved=page.evaluate('JSON.parse(localStorage.getItem("goodok-note-v1"))');assert saved['items'][1]['actuals']['2026-10']==25000
 page.locator('#payments-close').click();page.locator('#notification-diagnose').click();assert '예약' in page.locator('#notification-diagnosis').inner_text();page.locator('#notification-test').click();page.locator('#backup-file-save').click();exported=page.evaluate('window.exported');assert len(json.loads(exported)['payments'])==2;page.locator('#backup-close').click()
 page.locator('#backup-file-load').click();assert page.evaluate('window.importCalled');page.evaluate('(text)=>window.goodokBackupFile({action:"import",ok:true,data:text})',exported);assert page.locator('#confirm-ok').is_visible();page.locator('#confirm-ok').click()
 page.reload(wait_until='networkidle');page.locator('[data-view=settings]').click();page.locator('#payments-open').click();assert page.locator('#payment-total').inner_text()=='₩52,000'
 page.locator('[data-remove-payment]').last.click();page.locator('#confirm-ok').click();assert len(page.evaluate('JSON.parse(localStorage.getItem("goodok-note-v1")).payments'))==1
 for width,height in [(320,568),(390,844),(568,320)]:
  page.set_viewport_size(dict(width=width,height=height));box=page.locator('#payments-dialog').bounding_box();assert box['x']>=0 and box['x']+box['width']<=width+1;assert box['y']>=0 and box['y']+box['height']<=height+1
 assert errors==[],errors;b.close()
server.shutdown();print('PASS daily category merge and preservation, manual refresh, immutable payment log, taste actuals, file export/import validation and confirmation, notification diagnostics, reload and three dialog sizes')
