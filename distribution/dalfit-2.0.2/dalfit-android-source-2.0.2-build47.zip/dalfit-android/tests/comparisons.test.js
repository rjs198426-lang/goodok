import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {automaticAlternatives} from '../app/src/main/assets/comparisons.js';
const feed=JSON.parse(fs.readFileSync(new URL('./fixtures/research-feed.json',import.meta.url))),now=new Date('2026-10-25T12:00:00Z');
const current={id:'music',name:'Spotify',serviceKey:'spotify',price:10900,cycle:'monthly',paused:false};
test('verified lower normal price is automatic, with actual monthly and yearly differences',()=>{
 const list=automaticAlternatives([current],feed.plans,feed.catalog,now);assert.equal(list.length,1);assert.equal(list[0].service.key,'apple-music');assert.equal(list[0].delta,2000);assert.equal(list[0].annualDelta,24000);
 assert.equal(automaticAlternatives([{...current,price:8000}],feed.plans,feed.catalog,now).length,0);
 assert.equal(automaticAlternatives([{...current,paused:true}],feed.plans,feed.catalog,now).length,0);
});
test('unknown, stale, foreign, trial or committed prices do not become better alternatives',()=>{
 const target=feed.plans.find(p=>p.service==='apple-music');
 for(const patch of [{status:'candidate'},{currency:'USD'},{verifiedAt:'2026-09-01T00:00:00Z'},{introductory:true},{interval:'yearly'},{eligibility:'new_only'},{commitmentMonths:12},{taxBasis:'unknown'},{evidence:[]}]){
  assert.equal(automaticAlternatives([current],[{...target,...patch}],feed.catalog,now).length,0,JSON.stringify(patch));
 }
 assert.equal(automaticAlternatives([current],[],feed.catalog,now).length,0);
 const owned=[current,{...current,id:'owned',serviceKey:'apple-music'}];assert.equal(automaticAlternatives(owned,feed.plans,feed.catalog,now).length,0);
});
test('feature advantage requires an identified baseline and no loss of verified capabilities',()=>{
 const base={...feed.plans.find(p=>p.service==='spotify'),capabilities:{music:true,adfree:true,offline:true,spatial:false}},target={...feed.plans.find(p=>p.service==='apple-music'),amount:11990,capabilities:{music:true,adfree:true,offline:true,spatial:true}};
 base.evidence=[...base.evidence,...Object.keys(base.capabilities).map(key=>({field:'capability.'+key,quote:'verified feature'}))];target.evidence=[...target.evidence,...Object.keys(target.capabilities).map(key=>({field:'capability.'+key,quote:'verified feature'}))];
 const item={...current,price:11990,name:'Spotify '+base.name};assert.equal(automaticAlternatives([item],[base,target],feed.catalog,now)[0].featureGains[0],'공간 음향');
 assert.equal(automaticAlternatives([{...item,name:'Spotify'}],[base,target],feed.catalog,now).length,0);
 assert.equal(automaticAlternatives([item],[base,{...target,capabilities:{music:true,spatial:true}}],feed.catalog,now).length,0);
});

test('video-platform subscriptions are not treated as OTT and repeated targets are deduplicated',()=>{
 const youtube={id:'youtube',name:'YouTube Premium',serviceKey:'youtube',price:14900,cycle:'monthly'};
 assert.equal(automaticAlternatives([youtube],feed.plans,feed.catalog,now).length,0);
 const multiple=[{id:'netflix',name:'넷플릭스',serviceKey:'netflix',price:17000,cycle:'monthly'},{id:'tving',name:'티빙',serviceKey:'tving',price:13000,cycle:'monthly'}];
 const choices=automaticAlternatives(multiple,feed.plans,feed.catalog,now);assert.equal(choices.length,1);assert.equal(choices[0].source.serviceKey,'netflix');
});
