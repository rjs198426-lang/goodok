package kr.goodok.note;
import java.io.*;import java.net.*;import java.security.cert.Certificate;import javax.net.ssl.HttpsURLConnection;
public class NativeBenefitFeedTest {
 static class Response extends HttpsURLConnection {
  int code=200;byte[] body="{\"혜택\":true}".getBytes(java.nio.charset.StandardCharsets.UTF_8);boolean disconnected;
  Response(URL url){super(url);}public void connect(){}public void disconnect(){disconnected=true;}public boolean usingProxy(){return false;}
  public String getCipherSuite(){return "TLS";}public Certificate[] getLocalCertificates(){return null;}public Certificate[] getServerCertificates(){return null;}
  public int getResponseCode(){return code;}public InputStream getInputStream(){return new ByteArrayInputStream(body);}
 }
 interface Work {void run()throws Exception;}
 static void check(boolean value){if(!value)throw new AssertionError();}static void rejects(Work work)throws Exception{try{work.run();throw new AssertionError();}catch(IOException expected){}}
 public static void main(String[] args)throws Exception {
  String address="https://raw.githubusercontent.com/owner/repo/main/feed.json";
  check(BenefitFeedFetcher.allowed(new URL(address)));check(BenefitFeedFetcher.allowed(new URL("https://owner.github.io/feed.json")));
  for(String bad:new String[]{"http://raw.githubusercontent.com/owner/repo/main/feed.json","https://raw.githubusercontent.com.evil/owner/repo/main/feed.json","https://user@raw.githubusercontent.com/owner/repo/main/feed.json","https://127.0.0.1/feed.json"})check(!BenefitFeedFetcher.allowed(new URL(bad)));
  Response ok=new Response(new URL(address));check(new BenefitFeedFetcher(url->ok).fetch(address).contains("혜택"));check(ok.disconnected);check(!ok.getInstanceFollowRedirects());check(!ok.getUseCaches());check(ok.getReadTimeout()==12000);
  Response redirect=new Response(ok.getURL());redirect.code=302;rejects(()->new BenefitFeedFetcher(url->redirect).fetch(address));
  Response large=new Response(ok.getURL());large.body=new byte[2*1024*1024+1];rejects(()->new BenefitFeedFetcher(url->large).fetch(address));check(large.disconnected);
  System.out.println("PASS native feed transport: public JSON endpoints only, TLS, no redirects/cache, body limit, timeouts and UTF-8");
 }
}
