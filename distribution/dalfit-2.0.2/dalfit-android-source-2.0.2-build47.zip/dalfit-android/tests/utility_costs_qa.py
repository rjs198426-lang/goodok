import functools,http.server,threading,json,datetime
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root/'app/src/main/assets')));threading.Thread(target=server.serve_forever,daemon=True).start()
items=[dict(id=str(i),name=name,kind='fixed',category=category,price=price,cycle='monthly',date='2026-01-15',memo='기존 기록',paused=False) for i,(name,category,price) in enumerate([('관리비','주거',120000),('도시가스','공과금',45000),('월세','주거',700000)])]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':390,'height':844},timezone_id='Asia/Seoul');page.clock.install(time=datetime.datetime.fromisoformat('2026-10-26T10:00:00+09:00'));errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.add_init_script('window.GoodokResearch={syncReminders:s=>window.synced=JSON.parse(s)}');page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle');page.evaluate('(items)=>localStorage.setItem("goodok-note-v1",JSON.stringify({demo:false,items}))',items);page.reload(wait_until='networkidle')
 stored=page.evaluate('JSON.parse(localStorage.getItem("goodok-note-v1")).items');assert [i['kind'] for i in stored]==['variable','variable','fixed'];assert [i['price'] for i in stored]==[120000,45000,700000];assert [i['id'] for i in page.evaluate('synced')]==['0','1','2']
 page.locator('.nav[data-view=subscriptions]').click();page.locator('[data-cost-kind=fixed]').click();assert page.locator('[data-subscription]').count()==1;page.locator('[data-cost-kind=variable]').click();assert page.locator('[data-subscription]').count()==2;assert page.locator('#filtered-monthly').inner_text()=='₩165,000'
 page.locator('#subscriptions [data-edit="0"]').click();assert page.locator('#category').input_value()=='주거';assert page.locator('#variable-reminder').is_checked();page.locator('#close-editor').click();page.locator('#add').click();assert page.locator('[data-preset="variable:maintenance"]').count()==1;assert page.locator('[data-preset="variable:gas"]').count()==1;page.locator('[data-entry-kind=fixed]').click();assert page.locator('[data-preset="fixed:maintenance"]').count()==0;assert page.locator('[data-preset="fixed:gas"]').count()==0;page.locator('#close-editor').click()
 page.locator('.nav[data-view=settings]').click();page.locator('#restore-open').click();page.locator('#backup-text').fill(json.dumps(dict(app='goodok-note',version=1,demo=False,items=items)));page.locator('#backup-action').click();page.locator('#confirm-ok').click();assert [i['kind'] for i in page.evaluate('JSON.parse(localStorage.getItem("goodok-note-v1")).items')]==['variable','variable','fixed'];assert errors==[],errors
 browser.close()
server.shutdown();print('PASS: legacy utilities migrate and persist, amounts/categories/reminders retained, isolated filters, correct presets, old backup restoration migrates')
