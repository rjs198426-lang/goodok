import test from 'node:test';import assert from 'node:assert/strict';
import {migrateUtilityCosts,fixedPresets,variablePresets} from '../app/src/main/assets/catalog.js';
test('maintenance and gas presets belong only to variable costs',()=>{for(const key of ['maintenance','gas']){assert.equal(fixedPresets.some(x=>x.key===key),false);assert.equal(variablePresets.find(x=>x.key===key).kind,'variable');}});
test('legacy utility migration preserves amounts, history, schedule, pause and reminder preferences; is idempotent',()=>{
 const base={id:'1',name:'관리비',kind:'fixed',category:'주거',price:120000,date:'2026-01-31',cycle:'monthly',memo:'원본',paused:true,actuals:{'2026-10':110000}};
 const state={demo:false,items:[base,{...base,id:'2',name:'도시가스 요금',remind:false},{...base,id:'3',name:'도시가스',kind:undefined},{...base,id:'4',name:'전기요금'},{...base,id:'5',name:'보험 관리비'},{...base,id:'6',kind:'subscription'}]};
 const next=migrateUtilityCosts(state);for(const i of [0,1,2]){assert.equal(next.items[i].kind,'variable');assert.equal(next.items[i].price,state.items[i].price);assert.equal(next.items[i].date,state.items[i].date);assert.deepEqual(next.items[i].actuals,state.items[i].actuals);assert.equal(next.items[i].paused,true);}
 assert.equal(next.items[0].remind,true);assert.equal(next.items[1].remind,false);for(const i of [3,4,5])assert.strictEqual(next.items[i],state.items[i]);assert.equal(state.items[0].kind,'fixed');assert.strictEqual(migrateUtilityCosts(next),next);
});
