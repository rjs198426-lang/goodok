import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
test('direct distribution does not request other-app notification or broad sensitive access',()=>{
 const manifest=readFileSync(new URL('../app/src/main/AndroidManifest.xml',import.meta.url),'utf8');
 const permissions=[...manifest.matchAll(/<uses-permission android:name="([^"]+)"/g)].map(m=>m[1]);
 const allowed=new Set(['android.permission.INTERNET','android.permission.POST_NOTIFICATIONS','android.permission.RECEIVE_BOOT_COMPLETED']);
 assert.ok(permissions.every(p=>allowed.has(p)));
 assert.ok(!manifest.includes('BIND_NOTIFICATION_LISTENER_SERVICE'));
 const dir=new URL('../app/src/main/java/kr/goodok/note/',import.meta.url);
 for(const file of readdirSync(dir).filter(n=>n.endsWith('.java'))){
  const source=readFileSync(new URL(file,dir),'utf8');
  assert.ok(!source.includes('extends NotificationListenerService'),file);
  assert.ok(!source.includes('ACTION_NOTIFICATION_LISTENER_SETTINGS'),file);
 }
});
