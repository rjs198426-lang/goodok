import functools,http.server,threading,json,datetime
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];out=root/'artifacts/recommendation-fit';out.mkdir(exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root/'app/src/main/assets')));threading.Thread(target=server.serve_forever,daemon=True).start();feed=json.loads((root/'tests/fixtures/research-feed.json').read_text())
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.clock.install(time=datetime.datetime(2026,10,25,12));page.add_init_script('window.GoodokResearch={loadBenefits:id=>window.reqId=id}')
 page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle')
 def complete(value):page.evaluate('(feed)=>window.goodokOfferResearch({type:"feed",requestId:window.reqId,ok:true,feed})',value)
 complete(feed);page.locator('.nav[data-view=recommendations]').click()
 for width,height in [(320,568),(360,640),(390,844),(412,915),(568,320),(1024,768)]:
  page.set_viewport_size(dict(width=width,height=height))
  for key,count,selector in [('picks',5,'.discovery-card'),('offers',3,'.discount-card')]:
   page.locator('#tab-'+key).click();page.evaluate('window.scrollTo(0,0)');assert page.locator(selector).count()==count
   dims=page.evaluate('''(selector)=>({height:document.documentElement.scrollHeight,width:document.documentElement.scrollWidth,nav:document.querySelector('.sidebar nav').getBoundingClientRect().top,cards:[...document.querySelectorAll(selector)].map(el=>({bottom:el.getBoundingClientRect().bottom,top:el.getBoundingClientRect().top,height:el.getBoundingClientRect().height,scroll:el.scrollHeight}))})''',selector)
   assert dims['height']<=height+1,(key,width,height,dims)
   assert dims['width']<=width+1,(key,width,height,dims)
   assert max(card['bottom'] for card in dims['cards'])<=height,(key,width,height,dims)
   if width<=760 and height>500:assert max(card['bottom'] for card in dims['cards'])<=dims['nav'],(key,width,height,dims)
   for card in dims['cards']:assert card['scroll']<=card['height']+2,(key,width,height,card)
   page.wait_for_timeout(150);page.screenshot(path=str(out/f'{key}-{width}x{height}.png'))
 # Every result remains reachable in groups of three; refresh clamps a removed last page.
 page.set_viewport_size(dict(width=390,height=844));many=dict(feed,offers=[dict(feed['offers'][i%3],id='page-test-'+str(i),title='검증용 개별 행사 '+str(i),benefit='검증용 혜택 '+str(i)) for i in range(7)])
 page.evaluate('window.goodokResume()');complete(many);assert '1 / 3' in page.locator('#offer-page-label').inner_text();assert page.locator('#offer-prev').is_disabled()
 seen=[]
 for index in range(3):
  seen+=page.locator('.discount-card h3').all_text_contents()
  if index<2:page.locator('#offer-next').click()
 assert len(seen)==7 and len(set(seen))==7;assert page.locator('#offer-next').is_disabled();page.evaluate('window.goodokResume()');complete(feed);assert '1 / 1' in page.locator('#offer-page-label').inner_text();assert page.locator('.discount-card').count()==3
 # Long terms remain readable and official links remain accessible.
 page.locator('.offer-terms > summary').first.click();assert page.locator('.offer-terms p').first.is_visible();assert 'Surfshark One' in page.locator('.offer-terms p').first.inner_text();assert page.locator('.discount-meta a').first.get_attribute('href').startswith('https://');page.locator('.offer-terms > summary').first.click()
 page.locator('.research-audit > summary').click();assert page.locator('#research-coverage').is_visible();page.locator('.research-audit > summary').click()
 page.locator('#tab-picks').click();page.locator('[data-recommend]').first.click();assert page.locator('#editor').is_visible();page.locator('#close-editor').click()
 assert not errors,errors;browser.close()
server.shutdown();print('PASS: discovery 5 and offers 3 fit six sizes without clipping; all 7 paginated results reachable; stale page clamps on refresh; terms/audit/official links/registration work')
