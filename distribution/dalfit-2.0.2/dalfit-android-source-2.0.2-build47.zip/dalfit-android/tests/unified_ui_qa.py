import functools,http.server,threading,json,datetime
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];out=root/'artifacts/unified-ui';out.mkdir(exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root/'app/src/main/assets')));threading.Thread(target=server.serve_forever,daemon=True).start();feed=json.loads((root/'tests/fixtures/research-feed.json').read_text())
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True);page.clock.install(time=datetime.datetime(2026,10,25,12));page.add_init_script('window.GoodokResearch={loadBenefits:id=>window.reqId=id}');page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle');page.evaluate('(feed)=>window.goodokOfferResearch({type:"feed",requestId:window.reqId,ok:true,feed})',feed)
 audits=[]
 for width,height in [(320,568),(360,640),(390,844),(412,915),(568,320),(1024,768)]:
  page.set_viewport_size(dict(width=width,height=height));metrics=[]
  for view,part in [('overview',None),('subscriptions',None),('subscriptions','calendar'),('fixedcosts',None),('fixedcosts','calendar'),('recommendations','picks'),('recommendations','offers'),('recommendations','alternatives'),('settings',None)]:
   page.locator('.nav[data-view='+view+']').click()
   if part=='calendar':page.locator('#tab-calendar').click()
   elif part:page.locator('#tab-'+part).click()
   page.evaluate('window.scrollTo(0,0)');page.wait_for_timeout(180)
   value=page.evaluate('''()=>{const el=document.querySelector('h1'),style=getComputedStyle(el),box=el.getBoundingClientRect(),head=document.querySelector('.page-top'),content=document.querySelector('.content');return {title:el.textContent,x:box.x,y:box.y,font:style.fontSize,weight:style.fontWeight,line:style.lineHeight,header:head.getBoundingClientRect().height,margin:getComputedStyle(head).marginBottom,padding:getComputedStyle(content).paddingLeft}}''')
   metrics.append(value)
   if page.evaluate('document.documentElement.scrollWidth')>width+1:print(page.evaluate('''()=>[...document.querySelectorAll('body *')].filter(el=>el.getBoundingClientRect().right>innerWidth+1).map(el=>[el.id,el.className,el.getBoundingClientRect().right]).slice(0,18)'''),page.evaluate('''()=>[...document.querySelectorAll('body *')].filter(el=>el.clientWidth&&el.scrollWidth>el.clientWidth+1&&getComputedStyle(el).overflowX==='visible').map(el=>[el.id,typeof el.className==='string'?el.className:'svg',el.clientWidth,el.scrollWidth,el.getBoundingClientRect().x]).slice(0,20)'''),page.evaluate('({w:innerWidth,s:document.documentElement.scrollWidth,x:scrollX})'),flush=True)
   assert page.evaluate('document.documentElement.scrollWidth')<=width+1,(view,part,width)
   if view=='recommendations':assert value['title']=='추천'
   if width<=760 and height>500:assert page.locator('.sidebar>.brand').is_hidden()
   page.screenshot(path=str(out/f'{view}-{part or "main"}-{width}x{height}.png'))
  baseline=metrics[0]
  for metric in metrics:
   for key in ['x','y','font','weight','line','header','margin','padding']:
    assert metric[key]==baseline[key],(width,height,key,baseline,metric)
  audits.append(dict(width=width,height=height,headers=metrics))
  page.locator('.nav[data-view=subscriptions]').click();page.locator('#tab-list').click();list_style=page.locator('.subscription-toggle').evaluate('(el)=>({radius:getComputedStyle(el).borderRadius,bg:getComputedStyle(el).backgroundColor,height:el.querySelector("button").getBoundingClientRect().height})')
  page.locator('.nav[data-view=recommendations]').click();rec_style=page.locator('.recommendation-toggle').evaluate('(el)=>({radius:getComputedStyle(el).borderRadius,bg:getComputedStyle(el).backgroundColor,height:el.querySelector("button").getBoundingClientRect().height})');assert list_style==rec_style,(width,height,list_style,rec_style)
 browser.close()
server.shutdown();(out/'audit.json').write_text(json.dumps(audits,ensure_ascii=False,indent=2));print('PASS: identical title position/type/height/gutter across all 9 destinations, shared segmented controls at 6 sizes, mobile logo consistency, no horizontal overflow')
