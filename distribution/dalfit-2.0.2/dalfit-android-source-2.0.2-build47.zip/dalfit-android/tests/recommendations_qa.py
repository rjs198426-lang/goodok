import functools,http.server,threading,json,datetime
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root/'app/src/main/assets')));threading.Thread(target=server.serve_forever,daemon=True).start()
out=root/'artifacts/automatic-research';out.mkdir(exist_ok=True)
feed=json.loads((root/'tests/fixtures/research-feed.json').read_text())
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=2,is_mobile=True,has_touch=True,timezone_id='Asia/Seoul');errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.clock.install(time=datetime.datetime(2026,10,25,12));page.add_init_script('window.__calls=[];window.GoodokResearch={loadBenefits:(id,url)=>window.__calls.push({id,url})}')
 page.goto('http://127.0.0.1:'+str(server.server_port),wait_until='networkidle')
 items=[dict(id='chat',name='챗지피티',price=29000,cycle='monthly',category='AI',date='2024-01-01',memo='',paused=False),dict(id='music',name='Spotify',price=10900,cycle='monthly',category='음악',date='2024-01-01',memo='',paused=False)]
 page.evaluate('(items)=>localStorage.setItem("goodok-note-v1",JSON.stringify({demo:false,items}))',items);page.reload(wait_until='networkidle');assert page.evaluate('window.__calls.length')==1
 def complete(value=feed):page.evaluate('(feed)=>window.goodokOfferResearch({requestId:window.__calls.at(-1).id,type:"feed",ok:true,feed})',value)
 complete();page.locator('.nav[data-view="recommendations"]').click();page.locator('#tab-offers').click();assert '후보 57개' in page.locator('#research-coverage').text_content();assert 'Naver: 연결 실패' in page.locator('#research-providers').text_content();assert page.locator('.discount-card').count()==3
 page.evaluate('window.scrollTo(0,0)');page.wait_for_timeout(250);page.screenshot(path=str(out/'offers.png'))
 page.locator('#tab-alternatives').click();assert page.locator('.comparison-card').count()==1;assert page.locator('[data-current=chat]').count()==0
 card=page.locator('[data-current=music]');assert card.get_attribute('data-target')=='apple-music';assert '₩8,900' in card.inner_text();assert '월 ₩2,000 낮음' in card.inner_text();assert card.locator('input').count()==0;assert page.locator('.comparison-estimate').count()==0
 page.set_viewport_size({'width':390,'height':page.evaluate('document.documentElement.scrollHeight')});page.wait_for_timeout(250);page.screenshot(path=str(out/'comparison.png'),full_page=True);page.set_viewport_size({'width':390,'height':844})
 # No advantage: app should not offer an expensive or unknown alternative.
 page.evaluate('(items)=>{items[1].price=8000;localStorage.setItem("goodok-note-v1",JSON.stringify({demo:false,items}));}',items);page.reload(wait_until='networkidle');complete();page.locator('.nav[data-view="recommendations"]').click();page.locator('#tab-alternatives').click();assert page.locator('.comparison-card').count()==0;assert '바꿀 이점을 찾지 못했어요' in page.locator('#alternative-list').inner_text()
 # Synthetic server record verifies the dynamic catalogue path only; it is never published.
 extra=json.loads(json.dumps(feed));extra['catalog'].append(dict(key='discovered-test',name='새음악 테스트',aliases=['새음악 테스트'],category='음악',officialUrl='https://newmusic.example/pricing',status='verified',description='검증된 신규 카탈로그 연동 테스트'))
 page.evaluate('window.goodokResume()');complete(extra);page.locator('.nav[data-view="subscriptions"]').click();page.locator('#add').click();page.locator('#service-search').fill('새음악 테스트');assert page.locator('[data-preset=discovered-test]').count()==1;page.locator('[data-preset=discovered-test]').click();assert page.locator('#service-name').input_value()=='새음악 테스트';page.locator('#close-editor').click()
 for width,height in [(320,568),(390,844),(568,320),(1024,768)]:
  page.set_viewport_size({'width':width,'height':height});page.locator('.nav[data-view="recommendations"]').click()
  for part in ['picks','offers','alternatives']:
   page.locator('#tab-'+part).click();assert page.locator('#recommendation-panel [role=tabpanel]:visible').count()==1;assert page.evaluate('document.documentElement.scrollWidth')<=width+1
 assert not errors,errors
 print(json.dumps({'result':'passed','checks':['automatic verified price advantage only','unknown/foreign price omitted','no manual price field','no advantage gives empty state','Google/Naver actual statuses','dynamic catalog service and alias selection','three toggles','four viewport sizes','existing records retained']},ensure_ascii=False));browser.close()
server.shutdown()
