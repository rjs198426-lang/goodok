# 1.8.0 서버 수집으로 변경

할인 조사와 SQLite 저장은 GitHub Actions에서 실행합니다. 앱은 공개 JSON을 실행 때마다 읽습니다. 현재 서버 소스 목록은 https://github.com/rjs198426-lang/goodok/blob/main/backend/sources.json 이며, 아래 기록은 이전 버전 개발 당시 자료입니다.

# 할인 조사 출처와 확인 기록

1.7.0부터 APK의 네이티브 조회기가 아래 두 공식 URL을 매일 첫 실행에 직접 조회합니다. 이하 금액은 개발 당시 확인 기록이며, 앱은 고정 금액 대신 응답에서 추출한 값을 사용합니다. 페이지 형식을 인식할 수 없으면 오류/부분 확인으로 표시합니다.

확인일: 2026-10-25. 이 자료는 공식 페이지 확인 스냅샷이며 실시간 피드가 아닙니다.

## Surfshark One

- 공식 페이지: https://surfshark.com/pricing
- Black Friday deal로 표시된 One: 첫 27개월 US$67.23, 월 환산 US$2.49, 24개월 + 추가 3개월. VAT가 적용될 수 있음.
- 공식 종료일 미공개. 지역·통화와 갱신 조건은 결제 화면에서 다시 확인.

## Adobe Creative Cloud 모든 앱

- 공식 요금 페이지: https://www.adobe.com/kr/creativecloud/plans.html
- 공식 약관: https://www.adobe.com/kr/offer-terms/cc-full-special-offer-intro.html
- 요금 페이지의 25% 할인 표기. 한국 개인 신규 구독자 첫 1년 월 58,200원(부가세 포함), 12개월 약정·매월 청구. 현재 정가 월 78,100원, 이후 당시 요금 자동 갱신.
- 공식 종료일 미공개. 대상 자격·중도 해지 조건은 약관에서 확인.

## 노출 정책

확인한 달 및 확인일 포함 7일 동안만 스냅샷 노출. 알려진 실제 종료일이 지나도 숨김. 확인일을 이벤트 시작일이나 종료일로 사용하지 않음. 새 달로 자동 복제하지 않음. 유효 정보가 없으면 빈 상태와 공식 확인 링크를 제공.
