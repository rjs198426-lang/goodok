# Brand logo sources

Original SVG paths and brand colors are retained. Logos identify their respective subscription services.

- Netflix, YouTube, Spotify, Notion: Iconify Logos 1.2.10 / SVG Logos (CC0-1.0 collection), https://github.com/gilbarbara/logos and https://cdn.jsdelivr.net/npm/@iconify-json/logos@1.2.10/icons.json
- iCloud: https://github.com/homarr-labs/dashboard-icons/blob/main/svg/icloud.svg
- Coupang: https://github.com/kuleyu/site-logotypus/blob/e429d91b144d42abfca5ea66eca2c2582f37aa01/files/coupang.svg — only outer whitespace in the SVG viewBox was trimmed.

Assets are bundled locally. The service's own logo colors are separate from the application's red theme. Names without a known logo use a neutral initial avatar.

## Expanded catalogue in version 1.2.0

- Additional AI and productivity logos: SVG Logos / Iconify Logos 1.2.10, original path geometry and brand colors retained.
- Naver, Kakao/KakaoTalk, Surfshark, NordVPN, ExpressVPN, ProtonVPN, Canva, Suno, Amazon Prime, Tidal, Deezer, Evernote, Duolingo, YouTube Music: Iconify Simple Icons 1.2.50 (Simple Icons collection), https://cdn.jsdelivr.net/npm/@iconify-json/simple-icons@1.2.50/icons.json. Brand colors applied to monochrome paths.
- TVING, Wavve, Watcha, Coupang Play, Disney+, Apple TV, Apple Music, Prime Video: original brand artwork collected in https://github.com/ecklf/lg-luma/tree/c7600b02c74b465d17ccc89898fa311b785b16f4/assets/logos ; original source attributions are in that repository's assets.md. These SVGs were copied without executing repository code.
- Microsoft 365 and Microsoft Copilot: https://github.com/homarr-labs/dashboard-icons/tree/main/svg (`microsoft-365.svg`, `microsoft-copilot.svg`).
- Cursor and Gemini: https://github.com/lobehub/lobe-icons/tree/c385b2b8d1f9e19aa86e628d4e23c91ee1111a47/packages/static-svg/icons (`cursor.svg`, `gemini-color.svg`).
- Kakao subproducts use the Kakao or KakaoTalk parent brand artwork; Google Workspace uses the Google Drive mark. These are brand identifiers rather than product-specific app-store icons.
- `yodok.svg` is an original, labelled service badge in pink. It is not asserted to be the official Yodok logo.
- `category-*.svg` are original generic category drawings for subscriptions without a recognized brand.

The 50-entry catalogue is a bounded set of supported services, not a claim to include every subscription service globally. Existing records retain their stored category and amount; recognized names receive updated artwork automatically.

## Version 1.3.1 additions

Grok, Lovable and Krea use the original SVG artwork from Lobe Icons: https://github.com/lobehub/lobe-icons/tree/master/packages/static-svg/icons (`grok.svg`, `lovable-color.svg`, `krea.svg`), downloaded October 24, 2026. Assets are bundled offline.
