const KEY='goodok-benefit-feed-v2';
export const DEFAULT_FEED_URL='https://raw.githubusercontent.com/rjs198426-lang/goodok/main/backend/data/feed.json';
export function validFeedUrl(value){try{const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password&&!url.port&&!url.search&&!url.hash&&((url.hostname==='raw.githubusercontent.com'&&/^\/[\w.-]+\/[\w.-]+\/[\w./-]+\.json$/.test(url.pathname))||(/^[\w-]+\.github\.io$/.test(url.hostname)&&url.pathname.endsWith('.json')));}catch{return false;}}
export function safeSourceUrl(value){try{const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password&&!url.port;}catch{return false;}}
const isoDate=value=>typeof value==='string'&&Number.isFinite(Date.parse(value));
export function validateFeed(feed){
 if(!feed||feed.schemaVersion!==1||!isoDate(feed.generatedAt)||!Array.isArray(feed.offers)||feed.offers.length>1000||!Array.isArray(feed.sources)||feed.sources.length>1000)throw new Error('데이터 형식을 확인할 수 없어요.');
 for(const offer of feed.offers){if(!offer||!safeSourceUrl(offer.source)||!isoDate(offer.verifiedAt)||!/^\d{4}-\d{2}-\d{2}$/.test(offer.checked)||!['id','service','title','benefit','detail','conditions','publisher'].every(key=>typeof offer[key]==='string'&&offer[key].length<=1500)||offer.ends&&!/^\d{4}-\d{2}-\d{2}$/.test(offer.ends))throw new Error('혜택 데이터가 올바르지 않아요.');}
 if(feed.comparisons&&typeof feed.comparisons!=='object')throw new Error('비교 데이터가 올바르지 않아요.');
 const comparisons={};
 for(const [key,profile] of Object.entries(feed.comparisons||{})){
  if(!/^[a-z0-9-]+$/.test(key)||!profile||!safeSourceUrl(profile.source)||!['features','pros','cons'].every(field=>Array.isArray(profile[field])&&profile[field].length<=8&&profile[field].every(text=>typeof text==='string'&&text.length<=500)))continue;
  const price=profile.price;
  if(price&&(!Number.isFinite(price.monthly)||price.monthly<0||!['KRW','USD','EUR','GBP','AUD','CAD'].includes(price.currency)||typeof price.plan!=='string'||!isoDate(price.checked)))continue;
  comparisons[key]=profile;
 }
 const catalog=(Array.isArray(feed.catalog)?feed.catalog:[]).slice(0,2000).filter(item=>item&&/^[a-z0-9-]+$/.test(item.key)&&typeof item.name==='string'&&item.name.length<=100&&safeSourceUrl(item.officialUrl)&&typeof item.category==='string'&&(!item.aliases||Array.isArray(item.aliases)&&item.aliases.length<=20&&item.aliases.every(alias=>typeof alias==='string'&&alias.length<=100)));
 const plans=(Array.isArray(feed.plans)?feed.plans:[]).slice(0,5000).filter(plan=>plan&&typeof plan.id==='string'&&typeof plan.service==='string'&&typeof plan.name==='string'&&plan.name.length<=160&&Number.isFinite(plan.amount)&&plan.amount>=0&&safeSourceUrl(plan.source)&&isoDate(plan.verifiedAt)&&Array.isArray(plan.evidence));
 const tasteSuggestions=(Array.isArray(feed.tasteSuggestions)?feed.tasteSuggestions:[]).slice(0,500).filter(item=>item&&typeof item.id==='string'&&item.id.length<=100&&typeof item.name==='string'&&item.name.length<=100&&['도서 구입','영화','쇼핑','공연·전시','외식·카페','취미·레저','기타 취향비'].includes(item.category)&&item.status==='official_verified'&&officialTasteUrl(item.source)&&isoDate(item.verifiedAt)&&/^\d{4}-\d{2}-\d{2}$/.test(item.starts)&&/^\d{4}-\d{2}-\d{2}$/.test(item.ends)&&item.starts<=item.ends);
 return {...feed,offers:deduplicateOffers(feed.offers),comparisons,catalog,plans,tasteSuggestions};
}
export function officialTasteUrl(value){try{const url=new URL(value);return safeSourceUrl(value)&&['museum.go.kr','mmca.go.kr','koreafilm.or.kr','culture.seoul.go.kr','nl.go.kr','culture.go.kr'].some(host=>url.hostname===host||url.hostname.endsWith('.'+host));}catch{return false;}}
export function activeTasteSuggestions(feed,now=new Date()){
 const day=[now.getFullYear(),String(now.getMonth()+1).padStart(2,'0'),String(now.getDate()).padStart(2,'0')].join('-'),seen=new Set();
 return (feed?.tasteSuggestions||[]).filter(item=>{const age=now-Date.parse(item.verifiedAt);if(seen.has(item.id)||item.status!=='official_verified'||!officialTasteUrl(item.source)||age< -300000||age>72*3600000||!Number.isFinite(age)||item.ends<day)return false;seen.add(item.id);return true;}).sort((a,b)=>a.id.localeCompare(b.id));
}
export function canonicalOfferUrl(value){
 try{const url=new URL(value),host=url.hostname.replace(/^www\./,'')+(url.port?':'+url.port:''),path=(url.pathname.replace(/^\/(?:ko-kr|kr-ko|kr)(?=\/|$)/i,'/kr').replace(/\/+$/,'')||'/');
 const pairs=[...url.searchParams].filter(([key])=>!key.toLowerCase().startsWith('utm_')&&!['gclid','fbclid','msclkid','_ga'].includes(key.toLowerCase())).sort(([a,av],[b,bv])=>a<b?-1:a>b?1:av<bv?-1:av>bv?1:0),query=new URLSearchParams(pairs).toString();return host+path+(query?'?'+query:'');}catch{return String(value||'');}
}
export function offerIdentity(offer){
 const norm=value=>String(value||'').normalize('NFKC').trim().replace(/\s+/g,' ').toLowerCase(),service=norm(offer.service),title=norm(offer.title||offer.detail||offer.benefit),benefit=norm(offer.benefit);let slot=title;
 if(offer.campaignId)slot='campaign:'+norm(offer.campaignId);
 else if(service==='spotify'&&title.includes('개인')&&(title.includes('체험')||title.includes('trial')))slot='premium-individual-trial';
 else if(service==='apple-music'&&title.includes('개인')&&(title.includes('신규')||title.includes('체험')))slot='individual-trial';
 else if(service==='surfshark'&&/\bsurfshark\s+one\b(?!\s*\+)/.test(title))slot='surfshark-one-intro';
 else if(service==='nordvpn'&&/^basic\b/.test(benefit))slot='basic-intro';
 else if(service==='adobe'&&title.includes('creative cloud')&&(title.includes('모든 앱')||title.includes('all apps')))slot='all-apps-intro';
 return JSON.stringify([service,canonicalOfferUrl(offer.source),slot,norm(offer.planId),norm(offer.eligibility),norm(offer.region)]);
}
export function deduplicateOffers(offers){
 const newest=new Map(),time=offer=>Date.parse(offer.verifiedAt||offer.checked)||0;
 for(const offer of offers||[]){const key=offerIdentity(offer),old=newest.get(key);if(!old||time(offer)>time(old)||time(offer)===time(old)&&offer.source.length<old.source.length)newest.set(key,offer);}
 return [...newest.values()].sort((a,b)=>time(b)-time(a));
}

export function activeFeedOffers(feed,now=new Date()){
 const day=[now.getFullYear(),String(now.getMonth()+1).padStart(2,'0'),String(now.getDate()).padStart(2,'0')].join('-');
 return deduplicateOffers(feed?.offers||[]).filter(offer=>{const age=now-Date.parse(offer.verifiedAt);return age>=-300000&&age<=72*3600000&&(!offer.ends||offer.ends>=day);});
}
export function matchingOffers(feed,profile={},now=new Date()){
 return activeFeedOffers(feed,now).filter(offer=>{const a=offer.audience||{};if(profile.customer==='existing'&&a.newCustomer===true)return false;if(profile.student===false&&a.student===true)return false;if(profile.device===false&&a.device===true)return false;if(profile.payment==='card'&&a.payment==='wallet'||profile.payment==='wallet'&&a.payment==='card')return false;if(profile.telecom&&Array.isArray(a.telecoms)&&!a.telecoms.includes(profile.telecom))return false;if(profile.cardsConfirmed&&Array.isArray(a.cards)&&!a.cards.some(c=>(profile.cards||[]).includes(c)))return false;return true;});
}
export function createBenefitLoader({storage,bridge,changed,now=()=>new Date(),schedule=setTimeout,cancel=clearTimeout,timeout=30000}){
 let cache={feed:null,fetchedAt:null},active=null,timer=null;
 try{const saved=JSON.parse(storage.getItem(KEY));if(saved?.feed)cache={feed:validateFeed(saved.feed),fetchedAt:saved.fetchedAt};}catch{}
 let status='idle',message='';
 function snapshot(){return {...cache,status,message};}function emit(){changed(snapshot());}
 function fail(messageText){cancel(timer);active=null;status='error';message=messageText;emit();}
 function start(){
  if(active)return false;
  let url=DEFAULT_FEED_URL;try{url=storage.getItem('goodok-feed-url')||url;}catch{}
  if(!validFeedUrl(url)){status='unavailable';message='공개 GitHub 데이터 주소를 연결해 주세요.';emit();return false;}
  if(!bridge?.loadBenefits){status='unavailable';message='데이터 불러오기는 안드로이드 앱에서 사용할 수 있어요.';emit();return false;}
  active='f'+now().getTime()+Math.random().toString(36).slice(2,8);status='loading';message='저장된 최신 할인·비교 데이터를 불러오고 있어요.';emit();timer=schedule(()=>fail('데이터 연결 시간이 초과됐어요. 이전 확인 결과를 표시합니다.'),timeout);
  try{bridge.loadBenefits(active,url);}catch{fail('데이터를 불러오지 못했어요. 네트워크와 공개 데이터 주소를 확인해 주세요.');}return true;
 }
 function receive(event){if(!active||event?.requestId!==active||event.type!=='feed')return;if(!event.ok){fail('서버 데이터를 불러오지 못했어요. 기존 확인일을 유지한 저장 결과를 표시합니다.');return;}
  let feed;try{feed=validateFeed(event.feed);}catch(error){fail(error.message);return;}
  cancel(timer);active=null;cache={feed,fetchedAt:now().toISOString()};status=now()-Date.parse(feed.generatedAt)>6*3600000?'stale':'ready';
  message=feed.lastSuccessAt?`공식 출처 확인 혜택 ${activeFeedOffers(feed,now()).length}건 · ${feed.sources.filter(source=>source.status==='ok').length}/${feed.sources.length}개 출처 조회`:'GitHub의 첫 수집 결과를 기다리고 있어요.';
  try{storage.setItem(KEY,JSON.stringify(cache));}catch{message+=' · 이 기기에 결과를 저장하지 못했어요.';}emit();
 }
 return {start,receive,snapshot};
}
