const nameValid=name=>typeof name==='string'&&/^[가-힣a-zA-Z0-9 ·_-]{1,16}$/.test(name);
const sourceValid=value=>{try{const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password&&!url.port;}catch{return false;}};
export function categoryRelease(feed){
 const value=feed?.catalogUpdate;
 if(!value||!/^\d{4}-\d{2}-\d{2}$/.test(value.version)||!Number.isFinite(Date.parse(value.publishedAt))||!Array.isArray(value.categories)||value.categories.length>100||!Array.isArray(value.services)||value.services.length>2000)return null;
 const services=value.services.filter(s=>s&&typeof s.key==='string'&&/^[a-z0-9-]{1,100}$/.test(s.key)&&nameValid(s.category)&&typeof s.name==='string'&&s.name.length<=100&&Array.isArray(s.aliases)&&s.aliases.length<=20&&s.aliases.every(a=>typeof a==='string'&&a.length<=100)&&['verified','verified_identity'].includes(s.status)&&sourceValid(s.officialUrl));
 const categories=value.categories.filter(c=>c&&c.kind==='subscription'&&nameValid(c.name)&&services.some(s=>s.category===c.name));
 return {...value,categories,services};
}
export function mergeCategoryRules(rules,release,knownNames,protectedNames=[]){
 const next=[...rules],known=new Set([...knownNames,...rules.map(r=>r.name),...rules.map(r=>r.source).filter(Boolean),...protectedNames]);
 for(const item of release?.categories||[]){if(known.has(item.name)||next.length>=100)continue;next.push({name:item.name,kind:'subscription'});known.add(item.name);}
 return next;
}
