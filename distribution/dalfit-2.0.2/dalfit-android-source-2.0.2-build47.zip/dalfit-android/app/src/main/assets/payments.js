function validDay(value){try{return typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value)&&value>='2000-01-01'&&value<='2100-12-31'&&new Date(value+'T00:00:00Z').toISOString().slice(0,10)===value;}catch{return false;}}
export function validPayments(rows){return Array.isArray(rows)&&rows.length<=10000&&new Set(rows.map(r=>r?.id)).size===rows.length&&rows.every(r=>r&&typeof r.id==='string'&&r.id.length<=100&&typeof r.itemId==='string'&&r.itemId.length<=200&&typeof r.name==='string'&&r.name.length<=60&&typeof r.category==='string'&&r.category.length<=16&&['subscription','fixed','variable'].includes(r.kind)&&Number.isSafeInteger(r.amount)&&r.amount>=0&&r.amount<=1e8&&(!r.type||['payment','refund'].includes(r.type))&&(r.type!=='refund'||typeof r.refundOf==='string')&&(r.memo===undefined||typeof r.memo==='string'&&r.memo.length<=200)&&(r.parts===undefined||Number.isInteger(r.parts)&&r.parts>=1&&r.parts<=60&&Number.isInteger(r.part)&&r.part>=1&&r.part<=r.parts)&&validDay(r.paidOn));}
export const signedAmount=row=>row.type==='refund'?-row.amount:row.amount;
export function paymentTotal(rows,month){return rows.filter(r=>r.paidOn.slice(0,7)===month).reduce((sum,r)=>sum+signedAmount(r),0);}
export function paidTaste(rows,itemId,month){return rows.filter(r=>r.itemId===itemId&&r.kind==='variable'&&r.paidOn.slice(0,7)===month).reduce((sum,r)=>sum+signedAmount(r),0);}
export function recordPayment(state,payment){
 const rows=[...(state.payments||[])];if(!validPayments([...rows,payment]))throw Error('결제 정보를 확인해 주세요.');
 if(payment.type==='refund'){
  const original=rows.find(r=>r.id===payment.refundOf&&r.type!=='refund');
  if(!original||original.itemId!==payment.itemId||original.kind!==payment.kind||payment.paidOn<original.paidOn||payment.amount>original.amount-rows.filter(r=>r.refundOf===original.id).reduce((sum,r)=>sum+r.amount,0))throw Error('환불 원거래·날짜·남은 금액을 확인해 주세요.');
 }
 if(payment.type!=='refund'&&!payment.duplicateConfirmed&&rows.some(r=>r.itemId===payment.itemId&&r.paidOn===payment.paidOn&&r.amount===payment.amount&&(r.type||'payment')===(payment.type||'payment')))throw Error('같은 항목·날짜·금액의 결제가 이미 있어요.');
 let items=state.items;
 if(payment.kind==='variable')items=items.map(item=>{if(item.id!==payment.itemId)return item;const month=payment.paidOn.slice(0,7),amount=(item.actuals?.[month]||0)+signedAmount(payment);if(Math.abs(amount)>1e8)throw Error('월 금액 한도를 확인해 주세요.');return {...item,actuals:{...item.actuals,[month]:amount}};});
 return {...state,items,payments:[...rows,{...payment}]};
}
export function removePayment(state,id){
 const row=state.payments?.find(r=>r.id===id);if(!row)return state;
 if(state.payments.some(r=>r.refundOf===id))throw Error('연결된 환불 내역을 먼저 삭제해 주세요.');
 let items=state.items;
 if(row.kind==='variable')items=items.map(item=>{if(item.id!==row.itemId)return item;const month=row.paidOn.slice(0,7),amount=item.actuals?.[month]||0;if(Math.abs(amount-signedAmount(row))>1e8)throw Error('월 금액 한도를 확인해 주세요.');return {...item,actuals:{...item.actuals,[month]:amount-signedAmount(row)}};});
 return {...state,items,payments:state.payments.filter(r=>r.id!==id)};
}
