import {signedAmount} from './payments.js';
const moneyValue=x=>Number.isSafeInteger(x)&&x>=0&&x<=100000000;
export function validFinance(x){
 if(x===undefined)return true;
 const object=v=>v&&typeof v==='object'&&!Array.isArray(v),list=(v,n,fn)=>Array.isArray(v)&&v.length<=n&&v.every(fn),text=(v,n)=>typeof v==='string'&&v.length<=n,day=v=>typeof v==='string'&&/^20\d\d-\d\d-\d\d$/.test(v),dict=(v,n,fn)=>object(v)&&Object.keys(v).length<=n&&Object.entries(v).every(fn);
 return !!object(x)&&JSON.stringify(x).length<=1000000
 &&dict(x.months||{},1212,([m,p])=>/^20\d\d-(0[1-9]|1[0-2])$/.test(m)&&object(p)&&typeof p.rollover==='boolean'&&dict(p.categories||{},100,([k,v])=>/^[가-힣a-zA-Z0-9 ·_-]{1,16}$/.test(k)&&moneyValue(v)))
 &&list(x.goals||[],100,g=>object(g)&&text(g.id,100)&&text(g.name,60)&&moneyValue(g.target)&&moneyValue(g.allocated)&&g.allocated<=g.target)
 &&list(x.savings||[],10000,g=>object(g)&&text(g.id,100)&&text(g.name,60)&&moneyValue(g.amount)&&day(g.date))
 &&list(x.inbox||[],500,g=>object(g)&&text(g.id,200)&&text(g.raw,12000)&&text(g.source,200)&&Number.isFinite(g.receivedAt)&&g.receivedAt>=0&&(!g.originId||text(g.originId,1000)))
 &&list(x.favorites||[],10000,g=>text(g,200))&&list(x.sources||[],5,g=>text(g,100))
 &&(x.eligibility===undefined||object(x.eligibility)&&['customer','payment','telecom'].every(k=>x.eligibility[k]===undefined||text(x.eligibility[k],60))&&['student','device','cardsConfirmed'].every(k=>x.eligibility[k]===undefined||typeof x.eligibility[k]==='boolean')&&list(x.eligibility.cards||[],100,c=>text(c,100)))
 &&(!x.metrics||object(x.metrics)&&typeof x.metrics.enabled==='boolean'&&dict(x.metrics.counts||{},30,([k,v])=>text(k,50)&&Number.isFinite(v)&&v>=0)&&list(x.metrics.days||[],365,day)&&['startedAt','firstPayment','firstBudget'].every(k=>x.metrics[k]===undefined||Number.isFinite(x.metrics[k])&&x.metrics[k]>=0))
 &&dict(x.needs||{},3,([k,v])=>['assistant','vpn','office'].includes(k)&&dict(v,30,([field,value])=>text(field,50)&&(typeof value==='boolean'||text(value,60)||Number.isSafeInteger(value)&&value>=0&&value<=1e9)))
 &&dict(x.usageChecks||{},10000,([k,v])=>text(k,200)&&object(v)&&['yes','no','unknown'].includes(v.used)&&day(v.date))
 &&dict(x.cancellations||{},10000,([k,v])=>text(k,200)&&object(v)&&['review','done'].includes(v.status)&&day(v.date))
 &&(x.alerts===undefined||typeof x.alerts==='boolean');
}

export function tasteSpent(state,month,category=null){
 const map=n=>state.categories?.find(r=>r.source===n)?.name||n;const ids=new Set(state.items.filter(i=>i.kind==='variable').map(i=>i.id));return state.items.filter(i=>i.kind==='variable'&&(!category||map(i.category)===map(category))).reduce((sum,i)=>sum+(i.actuals?.[month]||0),0)+(state.payments||[]).filter(r=>r.kind==='variable'&&!ids.has(r.itemId)&&r.paidOn.slice(0,7)===month&&(!category||map(r.category)===map(category))).reduce((sum,r)=>sum+signedAmount(r),0);
}
export function legacyTaste(state,month,category=null){return state.items.filter(i=>i.kind==='variable'&&(!category||i.category===category)).reduce((sum,i)=>sum+Math.max(0,(i.actuals?.[month]||0)-(state.payments||[]).filter(r=>r.itemId===i.id&&r.kind==='variable'&&r.paidOn.slice(0,7)===month).reduce((n,r)=>n+signedAmount(r),0)),0);}
export function parseReceipt(text){
 text=String(text||'').slice(0,12000);const amounts=[...text.matchAll(/(?:₩\s*|KRW\s*)([\d,]+)|([\d,]+)\s*원/g)].map(m=>Number((m[1]||m[2]).replaceAll(',',''))).filter(moneyValue),date=text.match(/(20\d\d)[.\-/년]\s*(\d{1,2})[.\-/월]\s*(\d{1,2})/),total=text.match(/(?:합계|총\s*결제|결제\s*금액|승인\s*금액|total)[^\d₩$€£]{0,20}(?:₩\s*([\d,]+)|([\d,]+)\s*원)/i);let paidOn=date?`${date[1]}-${date[2].padStart(2,'0')}-${date[3].padStart(2,'0')}`:'';
 if(paidOn&&(!Number.isFinite(Date.parse(paidOn))||new Date(paidOn).toISOString().slice(0,10)!==paidOn))paidOn='';
 const chosen=total?Number((total[1]||total[2]).replaceAll(',','')):amounts.length===1?amounts[0]:null;
 return {raw:text,paidOn,amount:moneyValue(chosen)?chosen:null,amounts:[...new Set(amounts)],ambiguous:!total&&new Set(amounts).size>1};
}
export function duplicateCandidates(rows,draft){return rows.filter(r=>r.itemId===draft.itemId&&r.paidOn===draft.paidOn&&r.amount===draft.amount&&r.type!=='refund');}
export function monthlyReview(state,month){const rows=(state.payments||[]).filter(r=>r.paidOn.slice(0,7)===month);return {paid:rows.filter(r=>r.type!=='refund').reduce((s,r)=>s+r.amount,0),refunded:rows.filter(r=>r.type==='refund').reduce((s,r)=>s+r.amount,0),net:rows.reduce((s,r)=>s+signedAmount(r),0),taste:tasteSpent(state,month),legacy:legacyTaste(state,month)};}
export function samePlanPriceSignal(record,plans,catalog,payments,now=new Date()){
 if(!record.planId||!record.serviceKey||record.billingChannel!=='web')return null;const plan=plans.find(p=>p.id===record.planId&&p.service===record.serviceKey&&p.status==='verified'&&p.currency==='KRW'&&p.region==='KR'&&p.interval===(record.cycle==='yearly'?'yearly':'monthly')&&p.introductory===false&&p.eligibility==='general'&&p.commitmentMonths===(record.cycle==='yearly'?12:1)&&['included','official_display'].includes(p.taxBasis)&&now-Date.parse(p.verifiedAt)>=0&&now-Date.parse(p.verifiedAt)<7*864e5);
 const before=payments.filter(p=>p.itemId===record.id&&p.type!=='refund'&&p.eligibility==='general'&&p.planId===record.planId&&p.channel===record.billingChannel&&p.currency==='KRW'&&p.region==='KR'&&p.taxBasis===plan?.taxBasis).sort((a,b)=>b.paidOn.localeCompare(a.paidOn))[0];
 return plan&&before&&plan.evidence?.some(e=>e.field==='amount'&&e.quote)&&Date.parse(plan.verifiedAt)>=Date.parse(before.paidOn)&&plan.amount>before.amount?{plan,before,increase:plan.amount-before.amount}:null;
}
