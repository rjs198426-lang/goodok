export const fixedCategories = ["주거", "공과금", "통신", "보험", "금융", "교통", "교육·돌봄", "기타 고정비"];
export const variableCategories=['주거','공과금','식비','교통','취미','쇼핑·생활','기타 취향비'];
export const expenseKind = item => item.kind==='variable'?'variable': item.kind==='fixed'||(!item.kind&&fixedCategories.includes(item.category))?'fixed':'subscription';
export const categoryColors = {"AI": "#a93754", "OTT": "#d52d3a", "쇼핑": "#e16957", "통신·결합": "#c44781", "VPN": "#9d657d", "생산성": "#bd7a87", "카카오": "#d2a364", "음악": "#f07882", "학습": "#b592a6", "콘텐츠": "#cd939d", "생활": "#efb2a7", "기타": "#d3c0c8", "주거": "#b7475d", "공과금": "#ce745e", "통신": "#a4607e", "보험": "#bd6e87", "금융": "#955b73", "교통": "#d28c79", "교육·돌봄": "#c99a7a", "기타 고정비": "#bdadb4", "취미":"#bc6f9c", "식비":"#e39669", "쇼핑·생활":"#b98784", "기타 취향비":"#9f8ba4"};
export const services = [
  {
    "key": "chatgpt",
    "name": "ChatGPT",
    "category": "AI",
    "brand": "chatgpt",
    "aliases": [
      "ChatGPT",
      "챗지피티",
      "챗gpt",
      "챗GPT",
      "chatgpt",
      "openai"
    ]
  },
  {
    "key": "grok",
    "name": "Grok",
    "category": "AI",
    "brand": "grok",
    "aliases": [
      "Grok",
      "그록",
      "SuperGrok",
      "슈퍼그록",
      "xAI"
    ]
  },
  {
    "key": "lovable",
    "name": "Lovable",
    "category": "AI",
    "brand": "lovable",
    "aliases": [
      "Lovable",
      "러버블",
      "로버블",
      "러버블 AI",
      "lovableai"
    ]
  },
  {
    "key": "krea",
    "name": "Krea AI",
    "category": "AI",
    "brand": "krea",
    "aliases": [
      "Krea AI",
      "Krea",
      "크레아",
      "크리아",
      "크레아 AI"
    ]
  },
  {
    "key": "claude",
    "name": "Claude",
    "category": "AI",
    "brand": "claude",
    "aliases": [
      "Claude",
      "클로드",
      "claude"
    ]
  },
  {
    "key": "gemini",
    "name": "Google Gemini",
    "category": "AI",
    "brand": "gemini",
    "aliases": [
      "Google Gemini",
      "제미나이",
      "제미니",
      "gemini",
      "구글ai프로",
      "googleaipro",
      "구글ai울트라",
      "googleaiultra"
    ]
  },
  {
    "key": "perplexity",
    "name": "Perplexity",
    "category": "AI",
    "brand": "perplexity",
    "aliases": [
      "Perplexity",
      "퍼플렉시티",
      "퍼플렉시티프로",
      "perplexity"
    ]
  },
  {
    "key": "copilot",
    "name": "Microsoft Copilot",
    "category": "AI",
    "brand": "copilot",
    "aliases": [
      "Microsoft Copilot",
      "마이크로소프트코파일럿",
      "microsoftcopilot",
      "코파일럿",
      "copilot"
    ]
  },
  {
    "key": "github-copilot",
    "name": "GitHub Copilot",
    "category": "AI",
    "brand": "github-copilot",
    "aliases": [
      "GitHub Copilot",
      "githubcopilot",
      "깃허브코파일럿",
      "깃헙코파일럿"
    ]
  },
  {
    "key": "midjourney",
    "name": "Midjourney",
    "category": "AI",
    "brand": "midjourney",
    "aliases": [
      "Midjourney",
      "미드저니",
      "midjourney"
    ]
  },
  {
    "key": "cursor",
    "name": "Cursor",
    "category": "AI",
    "brand": "cursor",
    "aliases": [
      "Cursor",
      "커서",
      "cursor"
    ]
  },
  {
    "key": "suno",
    "name": "Suno",
    "category": "AI",
    "brand": "suno",
    "aliases": [
      "Suno",
      "수노",
      "suno"
    ]
  },
  {
    "key": "netflix",
    "name": "넷플릭스",
    "category": "OTT",
    "brand": "netflix",
    "aliases": [
      "넷플릭스",
      "netflix"
    ]
  },
  {
    "key": "youtube",
    "name": "YouTube Premium",
    "category": "OTT",
    "brand": "youtube",
    "aliases": [
      "YouTube Premium",
      "유튜브프리미엄",
      "유튜브",
      "youtubepremium",
      "youtube"
    ]
  },
  {
    "key": "disney-plus",
    "name": "디즈니+",
    "category": "OTT",
    "brand": "disney-plus",
    "aliases": [
      "디즈니+",
      "디즈니플러스",
      "disneyplus",
      "disney+",
      "디즈니"
    ]
  },
  {
    "key": "tving",
    "name": "티빙",
    "category": "OTT",
    "brand": "tving",
    "aliases": [
      "티빙",
      "tving"
    ]
  },
  {
    "key": "wavve",
    "name": "웨이브",
    "category": "OTT",
    "brand": "wavve",
    "aliases": [
      "웨이브",
      "wavve"
    ]
  },
  {
    "key": "watcha",
    "name": "왓챠",
    "category": "OTT",
    "brand": "watcha",
    "aliases": [
      "왓챠",
      "watcha"
    ]
  },
  {
    "key": "coupang-play",
    "name": "쿠팡플레이",
    "category": "OTT",
    "brand": "coupang-play",
    "aliases": [
      "쿠팡플레이",
      "coupangplay"
    ]
  },
  {
    "key": "apple-tv",
    "name": "Apple TV+",
    "category": "OTT",
    "brand": "apple-tv",
    "aliases": [
      "Apple TV+",
      "애플tv",
      "애플티비",
      "appletv"
    ]
  },
  {
    "key": "prime-video",
    "name": "Prime Video",
    "category": "OTT",
    "brand": "prime-video",
    "aliases": [
      "Prime Video",
      "프라임비디오",
      "아마존프라임비디오",
      "primevideo",
      "amazonprimevideo"
    ]
  },
  {
    "key": "naver-plus",
    "name": "네이버플러스 멤버십",
    "category": "쇼핑",
    "brand": "naver",
    "aliases": [
      "네이버플러스 멤버십",
      "네이버플러스",
      "네이버멤버십",
      "naverplus",
      "naver",
      "네이버"
    ]
  },
  {
    "key": "coupang",
    "name": "쿠팡 와우",
    "category": "쇼핑",
    "brand": "coupang",
    "aliases": [
      "쿠팡 와우",
      "쿠팡와우",
      "쿠팡",
      "coupangwow",
      "coupang"
    ]
  },
  {
    "key": "amazon-prime",
    "name": "Amazon Prime",
    "category": "쇼핑",
    "brand": "amazon-prime",
    "aliases": [
      "Amazon Prime",
      "아마존프라임",
      "amazonprime"
    ]
  },
  {
    "key": "yodok",
    "name": "유독",
    "category": "통신·결합",
    "brand": "yodok",
    "aliases": [
      "유독",
      "유독픽",
      "yodok",
      "udok",
      "u+독"
    ]
  },
  {
    "key": "surfshark",
    "name": "Surfshark VPN",
    "category": "VPN",
    "brand": "surfshark",
    "aliases": [
      "Surfshark VPN",
      "서퍼샤크",
      "서프샤크",
      "surfshark"
    ]
  },
  {
    "key": "nordvpn",
    "name": "NordVPN",
    "category": "VPN",
    "brand": "nordvpn",
    "aliases": [
      "NordVPN",
      "노드vpn",
      "노드브이피엔",
      "nordvpn"
    ]
  },
  {
    "key": "expressvpn",
    "name": "ExpressVPN",
    "category": "VPN",
    "brand": "expressvpn",
    "aliases": [
      "ExpressVPN",
      "익스프레스vpn",
      "익스프레스브이피엔",
      "expressvpn"
    ]
  },
  {
    "key": "protonvpn",
    "name": "Proton VPN",
    "category": "VPN",
    "brand": "protonvpn",
    "aliases": [
      "Proton VPN",
      "프로톤vpn",
      "프로톤브이피엔",
      "protonvpn"
    ]
  },
  {
    "key": "microsoft365",
    "name": "Microsoft 365",
    "category": "생산성",
    "brand": "microsoft365",
    "aliases": [
      "Microsoft 365",
      "m365",
      "ms365",
      "microsoft365",
      "마이크로소프트365",
      "오피스365",
      "office365",
      "마소365"
    ]
  },
  {
    "key": "notion",
    "name": "Notion",
    "category": "생산성",
    "brand": "notion",
    "aliases": [
      "Notion",
      "노션",
      "notion"
    ]
  },
  {
    "key": "icloud",
    "name": "iCloud+",
    "category": "생산성",
    "brand": "icloud",
    "aliases": [
      "iCloud+",
      "아이클라우드",
      "icloud"
    ]
  },
  {
    "key": "google-one",
    "name": "Google One",
    "category": "생산성",
    "brand": "google-one",
    "aliases": [
      "Google One",
      "구글원",
      "googleone"
    ]
  },
  {
    "key": "google-workspace",
    "name": "Google Workspace",
    "category": "생산성",
    "brand": "google-drive",
    "aliases": [
      "Google Workspace",
      "구글워크스페이스",
      "googleworkspace",
      "gsuite",
      "지스위트"
    ]
  },
  {
    "key": "dropbox",
    "name": "Dropbox",
    "category": "생산성",
    "brand": "dropbox",
    "aliases": [
      "Dropbox",
      "드롭박스",
      "드랍박스",
      "dropbox"
    ]
  },
  {
    "key": "adobe",
    "name": "Adobe Creative Cloud",
    "category": "생산성",
    "brand": "adobe",
    "aliases": [
      "Adobe Creative Cloud",
      "어도비",
      "adobe",
      "크리에이티브클라우드",
      "creativecloud"
    ]
  },
  {
    "key": "canva",
    "name": "Canva",
    "category": "생산성",
    "brand": "canva",
    "aliases": [
      "Canva",
      "캔바",
      "canva"
    ]
  },
  {
    "key": "figma",
    "name": "Figma",
    "category": "생산성",
    "brand": "figma",
    "aliases": [
      "Figma",
      "피그마",
      "figma"
    ]
  },
  {
    "key": "zoom",
    "name": "Zoom",
    "category": "생산성",
    "brand": "zoom",
    "aliases": [
      "Zoom",
      "줌",
      "zoom"
    ]
  },
  {
    "key": "slack",
    "name": "Slack",
    "category": "생산성",
    "brand": "slack",
    "aliases": [
      "Slack",
      "슬랙",
      "slack"
    ]
  },
  {
    "key": "onedrive",
    "name": "OneDrive",
    "category": "생산성",
    "brand": "onedrive",
    "aliases": [
      "OneDrive",
      "원드라이브",
      "onedrive"
    ]
  },
  {
    "key": "evernote",
    "name": "Evernote",
    "category": "생산성",
    "brand": "evernote",
    "aliases": [
      "Evernote",
      "에버노트",
      "evernote"
    ]
  },
  {
    "key": "kakao-emoticon",
    "name": "카카오 이모티콘 플러스",
    "category": "카카오",
    "brand": "kakao-talk",
    "aliases": [
      "카카오 이모티콘 플러스",
      "이모티콘플러스",
      "emoticonplus",
      "카카오이모티콘"
    ]
  },
  {
    "key": "kakao-drawer",
    "name": "카카오 톡서랍 플러스",
    "category": "카카오",
    "brand": "kakao-talk",
    "aliases": [
      "카카오 톡서랍 플러스",
      "톡서랍",
      "talkdrawer",
      "카카오톡",
      "kakaotalk"
    ]
  },
  {
    "key": "kakao-page",
    "name": "카카오페이지",
    "category": "카카오",
    "brand": "kakao",
    "aliases": [
      "카카오페이지",
      "kakaopage"
    ]
  },
  {
    "key": "kakao-webtoon",
    "name": "카카오웹툰",
    "category": "카카오",
    "brand": "kakao",
    "aliases": [
      "카카오웹툰",
      "kakaowebtoon"
    ]
  },
  {
    "key": "kakao",
    "name": "카카오 구독",
    "category": "카카오",
    "brand": "kakao",
    "aliases": [
      "카카오 구독",
      "카카오",
      "kakao"
    ]
  },
  {
    "key": "spotify",
    "name": "Spotify",
    "category": "음악",
    "brand": "spotify",
    "aliases": [
      "Spotify",
      "스포티파이",
      "spotify"
    ]
  },
  {
    "key": "youtube-music",
    "name": "YouTube Music",
    "category": "음악",
    "brand": "youtube-music",
    "aliases": [
      "YouTube Music",
      "유튜브뮤직",
      "youtubemusic"
    ]
  },
  {
    "key": "apple-music",
    "name": "Apple Music",
    "category": "음악",
    "brand": "apple-music",
    "aliases": [
      "Apple Music",
      "애플뮤직",
      "applemusic"
    ]
  },
  {
    "key": "tidal",
    "name": "Tidal",
    "category": "음악",
    "brand": "tidal",
    "aliases": [
      "Tidal",
      "타이달",
      "tidal"
    ]
  },
  {
    "key": "deezer",
    "name": "Deezer",
    "category": "음악",
    "brand": "deezer",
    "aliases": [
      "Deezer",
      "디저",
      "deezer"
    ]
  },
  {
    "key": "duolingo",
    "name": "Duolingo",
    "category": "학습",
    "brand": "duolingo",
    "aliases": [
      "Duolingo",
      "듀오링고",
      "duolingo"
    ]
  }
];
export function normalizeName(name){return String(name).normalize('NFKC').toLowerCase().replace(/[\s._+·()-]/g,'');}
let indexedCount=services.length;let aliasIndex=services.flatMap(service=>service.aliases.map(alias=>({alias:normalizeName(alias),service}))).sort((a,b)=>b.alias.length-a.alias.length);
export function findService(name){if(indexedCount!==services.length){aliasIndex=services.flatMap(service=>service.aliases.map(alias=>({alias:normalizeName(alias),service}))).sort((a,b)=>b.alias.length-a.alias.length);indexedCount=services.length;}const value=normalizeName(name);if(!value)return null;return aliasIndex.find(entry=>value.includes(entry.alias))?.service||null;}
export function findServices(query,category='전체'){const value=normalizeName(query);return services.filter(service=>(category==='전체'||service.category===category)&&(!value||[service.name,...service.aliases].some(alias=>normalizeName(alias).includes(value))));}
export const categoryIcons = {"AI": "category-0", "OTT": "category-1", "쇼핑": "category-2", "통신·결합": "category-3", "VPN": "category-4", "생산성": "category-5", "카카오": "category-6", "음악": "category-7", "학습": "category-8", "콘텐츠": "category-9", "생활": "category-10", "기타": "category-11", "주거": "fixed-0", "공과금": "fixed-1", "통신": "fixed-2", "보험": "fixed-3", "금융": "fixed-4", "교통": "fixed-5", "교육·돌봄": "fixed-6", "기타 고정비": "fixed-7", "취미":"hobby", "식비":"category-10", "쇼핑·생활":"category-2", "기타 취향비":"category-11"};

// Discovery offers new uses; equivalent-function services belong in Comparison.
export function recommendServices(items,day){
 const now=new Date(),fallback=[now.getFullYear(),now.getMonth()+1,now.getDate()].join('-'),match=String(day||fallback).match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
 let dateIndex=Math.floor(Date.UTC(now.getFullYear(),now.getMonth(),now.getDate())/864e5);
 if(match){const [year,month,date]=match.slice(1).map(Number),stamp=Date.UTC(year,month-1,date),check=new Date(stamp);if(check.getUTCFullYear()===year&&check.getUTCMonth()===month-1&&check.getUTCDate()===date)dateIndex=Math.floor(stamp/864e5);}

 const rank=key=>{let hash=2166136261;for(const letter of 'dalfit-daily-v2|'+key)hash=Math.imul(hash^letter.charCodeAt(0),16777619);return hash>>>0;};
 const pool=discoverableServices(items).sort((a,b)=>rank(a.key)-rank(b.key)||a.key.localeCompare(b.key));
 if(!pool.length)return [];const count=Math.min(8,pool.length),start=((dateIndex*count)%pool.length+pool.length)%pool.length;
 return Array.from({length:count},(_,index)=>pool[(start+index)%pool.length]);
}
const substituteGroups=[
 {keys:['chatgpt','claude','gemini','grok','copilot','perplexity'],reason:'질문·문서 작성에 쓸 대화형 AI를 비교해 보세요.'},
 {keys:['cursor','github-copilot'],reason:'코드 작성 지원이 목적이라면 개발 환경과 기능을 비교해 보세요.'},
 {keys:['midjourney','krea'],reason:'이미지 제작이 목적이라면 생성 방식과 사용량을 비교해 보세요.'},
 {keys:['netflix','disney-plus','tving','wavve','watcha','coupang-play','apple-tv','prime-video'],reason:'영상 시청을 위한 대안이에요. 독점 콘텐츠와 광고 여부는 달라요.'},
 {keys:['spotify','youtube-music','apple-music','tidal','deezer'],reason:'음악 감상용 대안이에요. 음원·음질·기기 지원을 비교해 보세요.'},
 {keys:['surfshark','nordvpn','expressvpn','protonvpn'],reason:'VPN 이용이 목적이라면 지원 기기와 연결 지역을 비교해 보세요.'},
 {keys:['microsoft365','google-workspace'],reason:'문서와 협업 도구가 필요하다면 앱 구성과 호환성을 비교해 보세요.'},
 {keys:['icloud','google-one','onedrive','dropbox'],reason:'파일 저장용 대안이에요. 저장 용량과 기기 동기화 방식을 확인하세요.'},
 {keys:['notion','evernote'],reason:'노트 정리가 목적이라면 편집 방식과 자료 이전 가능 여부를 확인하세요.'},
 {keys:['adobe','canva'],reason:'간단한 디자인 작업 중심일 때 비교해 보세요. 전문 편집 기능은 달라요.'},
 {keys:['naver-plus','coupang','amazon-prime'],reason:'쇼핑 멤버십 대안이에요. 주로 쓰는 쇼핑몰의 배송·적립 혜택을 비교하세요.'},
 {keys:['kakao-page','kakao-webtoon'],reason:'웹툰 감상용 대안이에요. 제공 작품과 결제 방식은 달라요.'}
];
export function alternativeServices(items,profiles={}){
 const owned=new Set(items.filter(item=>expenseKind(item)==='subscription').map(item=>findService(item.name)?.key).filter(Boolean)),seen=new Set(),result=[];
 for(const item of items){if(item.paused||expenseKind(item)!=='subscription')continue;const source=findService(item.name),group=substituteGroups.find(group=>group.keys.includes(source?.key));if(!group||seen.has(source.key))continue;
 const choices=group.keys.filter(key=>!owned.has(key));const key=choices.find(key=>profiles[key]?.price?.currency==='KRW')||choices[0];if(!key)continue;seen.add(source.key);result.push({source:item,service:services.find(service=>service.key===key),reason:group.reason});if(result.length===3)break;}
 return result;
}
// Editorial snapshot verified at official sources. Unknown end dates are never invented.
export const discountOffers=[
 {id:'surfshark-bf-2026',service:'surfshark',title:'Surfshark One 블랙프라이데이',benefit:'첫 27개월 US$67.23',detail:'월 환산 US$2.49 · 24개월 + 추가 3개월',conditions:'첫 27개월 선결제 기준. 세금이 추가될 수 있으며 갱신 요금은 별도예요. 국가·통화에 따라 달라질 수 있어요.',checked:'2026-10-25',ends:null,source:'https://surfshark.com/pricing',publisher:'Surfshark 공식'},
 {id:'adobe-intro-2026',service:'adobe',title:'Creative Cloud 모든 앱 첫해 할인',benefit:'첫해 월 ₩58,200',detail:'공식 페이지 25% 할인 표기 · 부가세 포함',conditions:'한국의 신규 개인 구독자 대상. 12개월 약정·매월 청구. 이후 당시 요금으로 자동 갱신되며 현재 정가는 월 ₩78,100이에요. 중도 해지 조건을 확인하세요.',checked:'2026-10-25',ends:null,source:'https://www.adobe.com/kr/offer-terms/cc-full-special-offer-intro.html',publisher:'Adobe 공식'}
];
export function currentDiscounts(offers,day){
 if(!/^\d{4}-\d{2}-\d{2}$/.test(day))return [];
 const now=Date.parse(day+'T00:00:00Z');
 return offers.filter(offer=>{const checked=Date.parse(offer.checked+'T00:00:00Z'),age=(now-checked)/864e5;return offer.checked.slice(0,7)===day.slice(0,7)&&age>=0&&age<=6&&(!offer.ends||day<=offer.ends);});
}

export const fixedPresets = [{"key": "rent", "name": "월세", "category": "주거", "estimated": false, "kind": "fixed"}, {"key": "power", "name": "전기요금", "category": "공과금", "estimated": true, "kind": "fixed"}, {"key": "water", "name": "수도요금", "category": "공과금", "estimated": true, "kind": "fixed"}, {"key": "mobile", "name": "휴대폰 요금", "category": "통신", "estimated": false, "kind": "fixed"}, {"key": "internet", "name": "인터넷 요금", "category": "통신", "estimated": false, "kind": "fixed"}, {"key": "insurance", "name": "보험료", "category": "보험", "estimated": false, "kind": "fixed"}, {"key": "loan", "name": "대출 상환금", "category": "금융", "estimated": false, "kind": "fixed"}, {"key": "installment", "name": "할부금", "category": "금융", "estimated": false, "kind": "fixed"}, {"key": "transport", "name": "교통 정기권", "category": "교통", "estimated": false, "kind": "fixed"}, {"key": "academy", "name": "학원비", "category": "교육·돌봄", "estimated": false, "kind": "fixed"}, {"key": "care", "name": "돌봄 비용", "category": "교육·돌봄", "estimated": false, "kind": "fixed"}, {"key": "donation", "name": "정기 후원", "category": "기타 고정비", "estimated": false, "kind": "fixed"}];

export const variablePresets=[{key:"maintenance",name:"관리비",category:"주거"},{key:"gas",name:"도시가스요금",category:"공과금"},{key:"hobby",name:"취미 활동",category:"취미"},{key:"hobby-gear",name:"취미 용품",category:"취미"},{key:"food",name:"식비",category:"식비"},{key:"travel",name:"교통비",category:"교통"},{key:"utility",name:"공과금",category:"공과금"},{key:"living",name:"생활용품",category:"쇼핑·생활"}].map(item=>({...item,kind:"variable",estimated:true}));

fixedPresets.push({key:"hobby-lesson",name:"취미 레슨",category:"취미",kind:"fixed",estimated:false},{key:"gym",name:"헬스장",category:"취미",kind:"fixed",estimated:false});

export function migrateUtilityCosts(state){
 let changed=false;const categories=state.categories?.map(rule=>{if(rule.source==='취미'&&rule.kind==='fixed'){changed=true;return {...rule,kind:'variable'};}return rule;});const items=state.items.map(source=>{let item=source;if(item.category==='기타 변동비'){item={...item,category:'기타 취향비'};changed=true;}
 if(['관리비','아파트관리비','도시가스','도시가스요금','가스비'].includes(normalizeName(item.name))&&expenseKind(item)!=='subscription'&&item.kind!=='fixed'){item={...item,kind:'fixed',price:state.costSchema===2?(item.actuals?.[new Date().getFullYear()+'-'+String(new Date().getMonth()+1).padStart(2,'0')]??item.price??0):(item.price||0),remind:item.remind??true};changed=true;}
 if(!state.costSchema){if(expenseKind(item)==='variable'){item={...item,budget:item.budget??item.price,price:0};changed=true;}else if(item.estimated){item={...item,previousAmount:item.price,price:0,actualPending:true};changed=true;}}
 if(item.estimated){item={...item,estimated:false};changed=true;}item=moveLeisureToTaste(item,state);if(item!==source)changed=true;const category=tasteCategory(item);if(category!==item.category){item={...item,category};changed=true;}return item;});
 return changed||!state.costSchema?{...state,...(categories?{categories}:{}),costSchema:2,items}:state;
}
fixedPresets.push({key:'maintenance',name:'관리비',category:'주거',kind:'fixed'},{key:'gas',name:'도시가스요금',category:'공과금',kind:'fixed'},{key:'social-fund',name:'곗돈',category:'친목',kind:'fixed'});
fixedCategories.push('친목');categoryColors['친목']='#ad6b83';categoryIcons['친목']='fixed-7';
for(let i=variablePresets.length-1;i>=0;i--)if(['maintenance','gas'].includes(variablePresets[i].key))variablePresets.splice(i,1);
for(const item of [...fixedPresets,...variablePresets])item.estimated=false;
export const tasteIdeas=[['사진 산책','취미'],['도자기 체험','취미'],['전시 관람','콘텐츠'],['독립서점 방문','콘텐츠'],['원데이 베이킹','취미'],['러닝 모임','취미'],['드로잉 클래스','취미'],['보드게임 모임','취미'],['공연 관람','콘텐츠'],['악기 연습','취미'],['클라이밍 체험','취미'],['꽃꽂이 체험','취미']];

variableCategories.splice(0,variableCategories.length,'도서 구입','영화','쇼핑','공연·전시','외식·카페','취미·레저','기타 취향비');
Object.assign(categoryColors,{'도서 구입':'#5d8c85','영화':'#8a74a5','공연·전시':'#af748d','외식·카페':'#b28b62','취미·레저':'#7a9270'});
Object.assign(categoryIcons,{'주거':'expense-home','공과금':'expense-utility','통신':'expense-phone','보험':'expense-shield','금융':'expense-wallet','교통':'expense-car','교육·돌봄':'expense-learn','친목':'expense-people','기타 고정비':'expense-wallet','도서 구입':'expense-book','영화':'expense-film','쇼핑':'expense-bag','공연·전시':'expense-ticket','외식·카페':'expense-cafe','취미·레저':'expense-leisure','취미':'expense-leisure','기타 취향비':'expense-leisure'});
variablePresets.splice(0,variablePresets.length,...[['books','도서 구입','도서 구입'],['movie','영화 관람','영화'],['shopping','쇼핑','쇼핑'],['culture','공연·전시','공연·전시'],['cafe','외식·카페','외식·카페'],['hobby','취미 활동','취미·레저']].map(([key,name,category])=>({key,name,category,kind:'variable',estimated:false})));
export function tasteCategory(item){if(expenseKind(item)!=='variable')return item.category;const name=normalizeName(item.name);if(!['취미','콘텐츠','식비','쇼핑·생활','기타 취향비','주거','공과금','교통'].includes(item.category))return item.category;if(/도서|책|서점/.test(name))return '도서 구입';if(/영화|시네마/.test(name))return '영화';return ({'취미':'취미·레저','콘텐츠':'공연·전시','식비':'외식·카페','쇼핑·생활':'쇼핑'}[item.category])||'기타 취향비';}
for(const row of tasteIdeas)row[1]=/서점/.test(row[0])?'도서 구입':/관람/.test(row[0])?'공연·전시':'취미·레저';

// Shared category icons are intentional within a category; different categories use distinct symbols.
categoryIcons['기타 고정비']='expense-fixed-other';categoryIcons['기타 취향비']='expense-taste-other';
for(let i=fixedPresets.length-1;i>=0;i--)if(['gym','hobby-lesson'].includes(fixedPresets[i].key))fixedPresets.splice(i,1);
variablePresets.push({key:'gym',name:'헬스장',category:'취미·레저',kind:'variable',estimated:false},{key:'hobby-lesson',name:'취미 레슨',category:'취미·레저',kind:'variable',estimated:false});
export function moveLeisureToTaste(item,state={}){
 if(expenseKind(item)!=='fixed')return item;
 const custom=state.categories?.find(rule=>rule.source==='취미'&&rule.name===item.category),name=normalizeName(item.name);
 if(!custom&&!['취미','취미·레저'].includes(item.category)&&!['헬스','헬스장','헬스장회비','헬스장이용료','헬스장멤버십','취미','취미비','취미비용','취미레슨'].includes(name))return item;
 const actuals={...(item.actuals||{})},key=item.date?.slice(0,7);
 if(key&&item.price>0&&!item.actualPending&&!item.estimated&&!Object.hasOwn(actuals,key))actuals[key]=item.price;
 return {...item,kind:'variable',category:custom?item.category:'취미·레저',price:0,actuals,remind:item.remind??true,movedFromFixed:item.movedFromFixed||{price:item.price,cycle:item.cycle,date:item.date}};
}

const purposeByService={chatgpt:'assistant',claude:'assistant',gemini:'assistant',grok:'assistant',copilot:'assistant',perplexity:'assistant',cursor:'coding','github-copilot':'coding',lovable:'appbuilder',midjourney:'image',krea:'image',suno:'music_creation',youtube:'video_platform',microsoft365:'office','google-workspace':'office',icloud:'storage','google-one':'storage',onedrive:'storage',dropbox:'storage',notion:'notes',evernote:'notes',adobe:'creative_suite',canva:'template_design',figma:'ui_design',zoom:'meetings',slack:'team_chat','naver-plus':'shopping_membership',coupang:'shopping_membership','amazon-prime':'shopping_membership','kakao-page':'comics','kakao-webtoon':'comics','kakao-emoticon':'emoticons','kakao-drawer':'chat_backup',yodok:'telecom_bundle',duolingo:'language_learning'};
const knownPurposes=new Set([...Object.values(purposeByService),'vpn','music','video']);
export function discoveryPurpose(service){
 if(!service)return null;if(purposeByService[service.key])return purposeByService[service.key];
 const purpose=typeof service.purpose==='string'?service.purpose.toLowerCase().trim():'';
 if(knownPurposes.has(purpose))return purpose;
 if(['llm','chatbot','general_llm','conversational_ai','ai_assistant'].includes(purpose))return 'assistant';
 const categoryPurpose={VPN:'vpn','음악':'music',OTT:'video'}[service.category];if(categoryPurpose)return categoryPurpose;
 if(service.category==='AI'&&/\bLLM\b|챗봇|대화형\s*AI/i.test(service.description||''))return 'assistant';
 return null;
}
export function discoveryPurposes(service){
 const values=new Set([discoveryPurpose(service)]);
 for(const raw of Array.isArray(service?.purposes)?service.purposes:[]){
  const value=typeof raw==='string'?raw.toLowerCase().trim():'';
  if(knownPurposes.has(value))values.add(value);
  if(['llm','chatbot','general_llm','conversational_ai','ai_assistant'].includes(value))values.add('assistant');
 }
 return [...values].filter(Boolean);
}
export function discoverableServices(items){
 const records=items.filter(item=>expenseKind(item)==='subscription'),resolve=item=>services.find(service=>service.key===item.serviceKey)||findService(item.name);
 const owned=new Set(records.map(resolve).filter(Boolean).map(service=>service.key)),covered=new Set(records.filter(item=>!item.paused).map(resolve).filter(Boolean).flatMap(discoveryPurposes));
 return services.filter(service=>!owned.has(service.key)&&!discoveryPurposes(service).some(purpose=>covered.has(purpose)));
}

export function invalidateServiceIndex(){indexedCount=-1;}
