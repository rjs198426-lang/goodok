package kr.goodok.note;
import android.content.*;import android.net.Uri;import android.provider.DocumentsContract;import org.json.*;import java.io.*;import java.nio.charset.StandardCharsets;
public final class BackupStore {
 static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences("dalfit-backup",0);}
 public static synchronized void snapshot(Context c,String data){try{if(data==null||data.getBytes(StandardCharsets.UTF_8).length>2000000||!"goodok-note".equals(new JSONObject(data).optString("app")))return;File temp=new File(c.getFilesDir(),"backup-new.json"),file=new File(c.getFilesDir(),"backup-local.json");try(FileOutputStream stream=new FileOutputStream(temp)){stream.write(data.getBytes(StandardCharsets.UTF_8));stream.getFD().sync();}if(!temp.renameTo(file))throw new IOException();prefs(c).edit().putLong("localAt",System.currentTimeMillis()).apply();if(prefs(c).getBoolean("auto",false))external(c);}catch(Exception e){prefs(c).edit().putString("error","백업 저장을 다시 확인해 주세요.").apply();}}
 public static synchronized boolean external(Context c){
  Uri created=null;
  try{
   String raw=prefs(c).getString("tree",null);if(raw==null)return false;Uri tree=Uri.parse(raw),parent=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
   byte[] bytes;try(FileInputStream in=new FileInputStream(new File(c.getFilesDir(),"backup-local.json"));ByteArrayOutputStream buffer=new ByteArrayOutputStream()){byte[] block=new byte[8192];int n;while((n=in.read(block))!=-1){if(buffer.size()+n>2000000)throw new IOException();buffer.write(block,0,n);}bytes=buffer.toByteArray();}
   created=DocumentsContract.createDocument(c.getContentResolver(),parent,"application/json","dalfit-auto-"+System.currentTimeMillis()+".json");if(created==null)throw new IOException();
   try(OutputStream out=c.getContentResolver().openOutputStream(created,"wt")){if(out==null)throw new IOException();out.write(bytes);out.flush();}
   JSONArray old=new JSONArray(prefs(c).getString("createdFiles","[]")),next=new JSONArray();next.put(created.toString());if(old.length()>0)next.put(old.getString(0));
   prefs(c).edit().putString("createdFiles",next.toString()).putLong("externalAt",System.currentTimeMillis()).remove("error").commit();
   for(int n=1;n<old.length();n++)try{DocumentsContract.deleteDocument(c.getContentResolver(),Uri.parse(old.getString(n)));}catch(Exception ignored){}
   return true;
  }catch(Exception e){if(created!=null)try{DocumentsContract.deleteDocument(c.getContentResolver(),created);}catch(Exception ignored){}prefs(c).edit().putString("error","독립 백업 실패 · 이전 성공 사본은 유지합니다.").apply();return false;}
 }
 public static synchronized void clear(Context c){prefs(c).edit().putBoolean("auto",false).remove("localAt").remove("error").apply();schedule(c);new File(c.getFilesDir(),"backup-local.json").delete();new File(c.getFilesDir(),"backup-new.json").delete();}
 public static String status(Context c){JSONObject o=new JSONObject();try{o.put("localAt",prefs(c).getLong("localAt",0));o.put("externalAt",prefs(c).getLong("externalAt",0));o.put("auto",prefs(c).getBoolean("auto",false));o.put("folder",prefs(c).contains("tree"));o.put("error",prefs(c).getString("error",""));}catch(Exception ignored){}return o.toString();}
 public static void schedule(Context c){android.app.job.JobScheduler scheduler=c.getSystemService(android.app.job.JobScheduler.class);if(prefs(c).getBoolean("auto",false))scheduler.schedule(new android.app.job.JobInfo.Builder(5045,new ComponentName(c,BackupJob.class)).setPersisted(true).setPeriodic(24*60*60*1000L).build());else scheduler.cancel(5045);}
}
