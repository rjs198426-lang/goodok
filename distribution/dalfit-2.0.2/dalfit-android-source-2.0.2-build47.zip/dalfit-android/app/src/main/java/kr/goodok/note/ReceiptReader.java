package kr.goodok.note;
import android.content.Context;
import android.net.Uri;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;
import java.util.function.BiConsumer;
/** Bundled Korean OCR; only explicitly selected images are read on device. */
public final class ReceiptReader {
 private static InputImage image(Context c,Uri uri)throws Exception{
  android.graphics.BitmapFactory.Options bounds=new android.graphics.BitmapFactory.Options();bounds.inJustDecodeBounds=true;try(java.io.InputStream stream=c.getContentResolver().openInputStream(uri)){android.graphics.BitmapFactory.decodeStream(stream,null,bounds);}if(bounds.outWidth<=0||bounds.outHeight<=0)throw new IllegalArgumentException();
  int sample=1;long limit=c.getSystemService(android.app.ActivityManager.class).isLowRamDevice()?2000000:8000000;while((long)(bounds.outWidth/sample)*(bounds.outHeight/sample)>limit||bounds.outWidth/sample>8192||bounds.outHeight/sample>8192)sample*=2;
  android.graphics.BitmapFactory.Options options=new android.graphics.BitmapFactory.Options();options.inSampleSize=sample;android.graphics.Bitmap bitmap;try(java.io.InputStream stream=c.getContentResolver().openInputStream(uri)){bitmap=android.graphics.BitmapFactory.decodeStream(stream,null,options);}if(bitmap==null)throw new IllegalArgumentException();int rotation=0;
  try(java.io.InputStream stream=c.getContentResolver().openInputStream(uri)){int orientation=new androidx.exifinterface.media.ExifInterface(stream).getAttributeInt(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,1);rotation=orientation==6?90:orientation==3?180:orientation==8?270:0;}catch(Exception ignored){}
  return InputImage.fromBitmap(bitmap,rotation);
 }
 public static void read(Context context,Uri uri,BiConsumer<String,String> result){
  try{
   if(uri==null||!"content".equals(uri.getScheme()))throw new IllegalArgumentException();
   com.google.mlkit.vision.text.TextRecognizer reader=TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build());
   reader.process(image(context,uri)).addOnSuccessListener(text->{result.accept(text.getText(),null);reader.close();}).addOnFailureListener(e->{result.accept(null,"이미지를 읽지 못했어요. 직접 입력할 수 있어요.");reader.close();});
  }catch(Exception e){result.accept(null,"지원되는 이미지를 선택해 주세요.");}
 }
}
