package kr.goodok.note;
import android.content.*;
public final class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent){String action=intent==null?null:intent.getAction();if(action!=null&&java.util.Arrays.asList(Intent.ACTION_BOOT_COMPLETED,Intent.ACTION_TIME_CHANGED,Intent.ACTION_TIMEZONE_CHANGED,Intent.ACTION_MY_PACKAGE_REPLACED,"kr.goodok.note.REMIND").contains(action))ReminderScheduler.refresh(context);}
}
