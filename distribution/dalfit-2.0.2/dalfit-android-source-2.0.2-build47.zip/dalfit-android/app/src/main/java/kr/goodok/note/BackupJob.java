package kr.goodok.note;
public final class BackupJob extends android.app.job.JobService {
 @Override public boolean onStartJob(android.app.job.JobParameters p){new Thread(()->{boolean ok=!BackupStore.prefs(this).getBoolean("auto",false)||BackupStore.external(this);jobFinished(p,!ok);}).start();return true;}
 @Override public boolean onStopJob(android.app.job.JobParameters p){return true;}
}
