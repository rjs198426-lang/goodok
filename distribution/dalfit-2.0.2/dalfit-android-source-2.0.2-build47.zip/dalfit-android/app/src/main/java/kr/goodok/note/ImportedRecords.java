package kr.goodok.note;
import android.content.Context;
import org.json.JSONArray;
/** Reads only this app's historical review queue; never accesses other apps. */
public final class ImportedRecords {
 static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences("dalfit-imports",0);}
 public static String pending(Context c){return prefs(c).getString("pending","[]");}
 public static synchronized void acknowledge(Context c,String id){try{JSONArray old=new JSONArray(pending(c)),next=new JSONArray();for(int i=0;i<old.length();i++)if(!id.equals(old.getJSONObject(i).optString("id")))next.put(old.getJSONObject(i));prefs(c).edit().putString("pending",next.toString()).apply();}catch(Exception ignored){}}
}
