package kr.goodok.note;

import android.app.Activity;
import android.webkit.JavascriptInterface;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.widget.Toast;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/** Packaged UI; the native layer downloads public JSON only. */
public final class MainActivity extends Activity {
    private static final String ORIGIN = "https://app.goodok.local";
    private WebView webView;
    private final ExecutorService offerExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService receiptExecutor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean researching = new AtomicBoolean(false);
    private volatile boolean destroyed;
    private String backupToWrite;
    private boolean pageReady;
    private final AtomicBoolean readingReceipt=new AtomicBoolean(false);
    private void readReceipt(Uri uri){if(destroyed)return;if(!readingReceipt.compareAndSet(false,true)){advancedEvent(null,"이미지를 읽는 중이에요. 잠시 기다려 주세요.");return;}receiptExecutor.execute(()->ReceiptReader.read(this,uri,(text,error)->{readingReceipt.set(false);advancedEvent(text,error);}));}
    private void advancedEvent(String raw,String error){runOnUiThread(()->{if(webView!=null&&!destroyed)webView.evaluateJavascript("window.dalfitIncoming && window.dalfitIncoming("+JSONObject.quote(raw==null?"":raw).replace("<","\\u003c")+","+JSONObject.quote(error==null?"":error)+")",null);});}
    private void incomingIntent(){
        if(!pageReady)return;
        Intent intent=getIntent();String action=intent.getStringExtra("dalfit_action");if(action!=null){intent.removeExtra("dalfit_action");if(webView!=null)webView.evaluateJavascript("window.dalfitAction && window.dalfitAction("+JSONObject.quote(action)+")",null);}
        if(Intent.ACTION_SEND.equals(intent.getAction())){intent.setAction(Intent.ACTION_MAIN);if(intent.getType()!=null&&intent.getType().startsWith("image/")){Uri uri=intent.getParcelableExtra(Intent.EXTRA_STREAM);readReceipt(uri);}else{CharSequence text=intent.getCharSequenceExtra(Intent.EXTRA_TEXT);if(text!=null)advancedEvent(text.toString().substring(0,Math.min(text.length(),12000)),null);}}
    }
    private void backupResult(String action,boolean ok,String data){
        runOnUiThread(()->{if(webView==null||destroyed)return;JSONObject result=new JSONObject();try{result.put("action",action);result.put("ok",ok);if(data!=null)result.put("data",data);}catch(Exception ignored){}webView.evaluateJavascript("window.goodokBackupFile && window.goodokBackupFile("+result.toString().replace("<","\\u003c").replace("\u2028","\\u2028").replace("\u2029","\\u2029")+")",null);});
    }

    private void emitOfferEvent(JSONObject event) {
        runOnUiThread(() -> {
            if (destroyed || webView == null) return;
            String payload = event.toString().replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029");
            webView.evaluateJavascript("window.goodokOfferResearch && window.goodokOfferResearch(" + payload + ")", null);
        });
    }
    private JSONObject offerEvent(String id, String type) {
        JSONObject event = new JSONObject();
        try { event.put("requestId", id); event.put("type", type); } catch (org.json.JSONException ignored) { }
        return event;
    }
    private void reminderStatus(){if(webView!=null)webView.evaluateJavascript("window.goodokNotificationStatus && window.goodokNotificationStatus("+ReminderScheduler.status(this)+")",null);}
    private void openReminder(){String id=getIntent().getStringExtra("reminder_id");if(id!=null&&webView!=null){webView.evaluateJavascript("window.goodokOpenReminder && window.goodokOpenReminder("+JSONObject.quote(id)+")",null);getIntent().removeExtra("reminder_id");}}
    private final class OfferBridge {
        @JavascriptInterface public void voiceInput(){runOnUiThread(()->{try{startActivityForResult(new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE,"ko-KR").putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE,true),305);}catch(Exception e){advancedEvent(null,"기기에 음성 입력 제공자가 없어요. 키보드로 입력해 주세요.");}});}
        @JavascriptInterface public void exportCsv(String text){runOnUiThread(()->{try{if(text==null||text.getBytes(java.nio.charset.StandardCharsets.UTF_8).length>2000000)throw new IOException();backupToWrite="\ufeff"+text;startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/csv").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"dalfit-payments.csv"),306);}catch(Exception e){backupResult("csv",false,null);}});}
        @JavascriptInterface public void pickReceipt(){runOnUiThread(()->{try{startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE),303);}catch(Exception e){advancedEvent(null,"이미지 선택기를 열지 못했어요.");}});}
        @JavascriptInterface public void syncBackup(String data){offerExecutor.execute(()->BackupStore.snapshot(MainActivity.this,data));}
        @JavascriptInterface public String backupStatus(){return BackupStore.status(MainActivity.this);}
        @JavascriptInterface public void autoBackup(boolean enabled){runOnUiThread(()->{if(!enabled){BackupStore.prefs(MainActivity.this).edit().putBoolean("auto",false).apply();BackupStore.schedule(MainActivity.this);return;}try{startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION),304);}catch(Exception e){backupResult("auto",false,null);}});}
        @JavascriptInterface public void syncWidget(String text,String month){if(text==null||text.length()>100||month==null||!month.matches("20[0-9]{2}-[0-9]{2}"))return;getSharedPreferences("dalfit-quick",0).edit().putString("remaining",text).putString("month",month).apply();runOnUiThread(()->CostWidget.update(MainActivity.this));}
        @JavascriptInterface public void pinWidget(){runOnUiThread(()->{android.appwidget.AppWidgetManager m=android.appwidget.AppWidgetManager.getInstance(MainActivity.this);if(m.isRequestPinAppWidgetSupported())m.requestPinAppWidget(new android.content.ComponentName(MainActivity.this,CostWidget.class),null,null);else Toast.makeText(MainActivity.this,"홈 화면의 위젯 목록에서 달핏을 선택하세요.",Toast.LENGTH_LONG).show();});}
        @JavascriptInterface public void resetFinancial(){synchronized(ImportedRecords.class){ImportedRecords.prefs(MainActivity.this).edit().putString("pending","[]").putStringSet("allowed",java.util.Collections.emptySet()).commit();}}
        @JavascriptInterface public void clearLocalRecords(){resetFinancial();offerExecutor.execute(()->BackupStore.clear(MainActivity.this));getSharedPreferences("dalfit-budget-alerts",0).edit().clear().apply();getSharedPreferences("goodok-reminders",0).edit().remove("sent").apply();}
        @JavascriptInterface public String financialInbox(){return ImportedRecords.pending(MainActivity.this);}
        @JavascriptInterface public void acknowledgeFinancial(String id){ImportedRecords.acknowledge(MainActivity.this,id);}
        @JavascriptInterface public void budgetAlert(String key,String text){if(key==null||key.length()>100||text==null||text.length()>200||!ReminderScheduler.enabled(MainActivity.this)||!ReminderScheduler.allowed(MainActivity.this))return;android.content.SharedPreferences p=getSharedPreferences("dalfit-budget-alerts",0);if(p.getBoolean(key,false))return;try{getSystemService(android.app.NotificationManager.class).notify("budget:"+key,0,new android.app.Notification.Builder(MainActivity.this,"subscription-reminders-v1").setSmallIcon(R.drawable.ic_notification).setContentTitle("취향비 예산 확인").setContentText(text).setVisibility(android.app.Notification.VISIBILITY_PRIVATE).setAutoCancel(true).build());p.edit().putBoolean(key,true).apply();}catch(SecurityException ignored){}}
        @JavascriptInterface public void exportBackup(String data){runOnUiThread(()->{try{if(data==null||data.getBytes(java.nio.charset.StandardCharsets.UTF_8).length>2000000||!"goodok-note".equals(new JSONObject(data).optString("app")))throw new IOException();backupToWrite=data;startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"dalfit-backup-"+java.time.LocalDate.now()+".json"),301);}catch(Exception e){backupToWrite=null;backupResult("export",false,null);}});}
        @JavascriptInterface public void importBackup(){runOnUiThread(()->{try{startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/plain","application/octet-stream"}).addCategory(Intent.CATEGORY_OPENABLE),302);}catch(Exception e){backupResult("import",false,null);}});}
        @JavascriptInterface public void testNotification(){runOnUiThread(()->{boolean ok=ReminderScheduler.test(MainActivity.this);webView.evaluateJavascript("window.goodokNotificationTest && window.goodokNotificationTest("+ok+")",null);});}
        @JavascriptInterface public void syncReminders(String data){runOnUiThread(()->{if(!destroyed){ReminderScheduler.sync(MainActivity.this,data);reminderStatus();}});}
        @JavascriptInterface public String notificationStatus(){return ReminderScheduler.status(MainActivity.this);}
        @JavascriptInterface public void notifications(boolean enabled){runOnUiThread(()->{
            ReminderScheduler.enabled(MainActivity.this,enabled);
            if(enabled){ReminderScheduler.asked(MainActivity.this,true);if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},220);}
            reminderStatus();
        });}
        @JavascriptInterface public void notificationSettings(){runOnUiThread(()->startActivity(new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,getPackageName())));}

        @JavascriptInterface public String appInfo() {
            return "{\"version\":\"" + BuildConfig.VERSION_NAME + "\",\"build\":" + BuildConfig.VERSION_CODE + "}";
        }
        @JavascriptInterface public void loadBenefits(String id,String url) {
            if(destroyed||id==null||!id.matches("[a-zA-Z0-9]{1,64}")||url==null||url.length()>500||!researching.compareAndSet(false,true))return;
            offerExecutor.execute(()->{
                JSONObject event=offerEvent(id,"feed");
                try { event.put("feed",new JSONObject(new BenefitFeedFetcher().fetch(url)));event.put("ok",true); }
                catch(Exception exception){try{event.put("ok",false);}catch(org.json.JSONException ignored){}}
                finally{researching.set(false);}
                emitOfferEvent(event);
            });
        }
    }


    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ImportedRecords.prefs(this).edit().remove("allowed").apply();
        ReminderScheduler.channel(this);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(247, 247, 249));
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return WindowInsets.CONSUMED;
            } else {
                view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(247, 247, 249));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view,String url){if((ORIGIN+"/index.html").equals(url)){pageReady=true;openReminder();incomingIntent();}}
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme()) || !"app.goodok.local".equals(uri.getHost())
                        || uri.getPort() != -1 || !"GET".equals(request.getMethod())) {
                    return error(403, "Forbidden");
                }
                String path = uri.getPath();
                if ("/".equals(path)) path = "/index.html";
                String mime;
                switch (path == null ? "" : path) {
                    case "/index.html": mime = "text/html"; break;
                    case "/brands/fixed-0.svg":
                    case "/brands/fixed-1.svg":
                    case "/brands/fixed-2.svg":
                    case "/brands/fixed-3.svg":
                    case "/brands/fixed-4.svg":
                    case "/brands/fixed-5.svg":
                    case "/brands/fixed-6.svg":
                    case "/brands/fixed-7.svg":
                    case "/brands/expense-fixed-other.svg":
                    case "/brands/expense-taste-other.svg":
                    case "/brands/expense-home.svg":
case "/brands/expense-utility.svg":
case "/brands/expense-phone.svg":
case "/brands/expense-shield.svg":
case "/brands/expense-wallet.svg":
case "/brands/expense-car.svg":
case "/brands/expense-learn.svg":
case "/brands/expense-people.svg":
case "/brands/expense-book.svg":
case "/brands/expense-film.svg":
case "/brands/expense-bag.svg":
case "/brands/expense-ticket.svg":
case "/brands/expense-cafe.svg":
case "/brands/expense-leisure.svg":
                    case "/brands/hobby.svg":
                    case "/brands/dalfit.svg":
                    case "/brands/adobe.svg":
                    case "/brands/amazon-prime.svg":
                    case "/brands/apple-music.svg":
                    case "/brands/apple-tv.svg":
                    case "/brands/canva.svg":
                    case "/brands/category-0.svg":
                    case "/brands/category-1.svg":
                    case "/brands/category-10.svg":
                    case "/brands/category-11.svg":
                    case "/brands/category-2.svg":
                    case "/brands/category-3.svg":
                    case "/brands/category-4.svg":
                    case "/brands/category-5.svg":
                    case "/brands/category-6.svg":
                    case "/brands/category-7.svg":
                    case "/brands/category-8.svg":
                    case "/brands/category-9.svg":
                    case "/brands/chatgpt.svg":
                    case "/brands/claude.svg":
                    case "/brands/copilot.svg":
                    case "/brands/coupang-play.svg":
                    case "/brands/coupang.svg":
                    case "/brands/cursor.svg":
                    case "/brands/deezer.svg":
                    case "/brands/disney-plus.svg":
                    case "/brands/dropbox.svg":
                    case "/brands/duolingo.svg":
                    case "/brands/evernote.svg":
                    case "/brands/expressvpn.svg":
                    case "/brands/figma.svg":
                    case "/brands/gemini.svg":
                    case "/brands/github-copilot.svg":
                    case "/brands/google-drive.svg":
                    case "/brands/google-one.svg":
                    case "/brands/icloud.svg":
                    case "/brands/kakao-talk.svg":
                    case "/brands/kakao.svg":
                    case "/brands/microsoft365.svg":
                    case "/brands/midjourney.svg":
                    case "/brands/naver.svg":
                    case "/brands/grok.svg":
                    case "/brands/lovable.svg":
                    case "/brands/krea.svg":
                    case "/brands/netflix.svg":
                    case "/brands/nordvpn.svg":
                    case "/brands/notion.svg":
                    case "/brands/onedrive.svg":
                    case "/brands/perplexity.svg":
                    case "/brands/prime-video.svg":
                    case "/brands/protonvpn.svg":
                    case "/brands/slack.svg":
                    case "/brands/spotify.svg":
                    case "/brands/suno.svg":
                    case "/brands/surfshark.svg":
                    case "/brands/tidal.svg":
                    case "/brands/tving.svg":
                    case "/brands/watcha.svg":
                    case "/brands/wavve.svg":
                    case "/brands/yodok.svg":
                    case "/brands/youtube-music.svg":
                    case "/brands/youtube.svg":
                    case "/brands/zoom.svg":
                        mime = "image/svg+xml"; break;
                    case "/fonts/PretendardVariable.woff2": mime = "font/woff2"; break;
                    case "/style.css": mime = "text/css"; break;
                    case "/app.js": case "/model.js": case "/catalog.js": case "/category_updates.js": case "/payments.js": case "/finance.js": case "/advanced.js": case "/offers.js": case "/comparisons.js": mime = "text/javascript"; break;
                    default: return error(404, "Not Found");
                }
                try {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'none'; object-src 'none'; base-uri 'self'; frame-src 'none'");
                    headers.put("X-Content-Type-Options", "nosniff");
                    return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers,
                        getAssets().open(path.substring(1)));
                } catch (IOException exception) { return error(404, "Not Found"); }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String url = uri.toString();
                boolean officialSource = "https".equals(uri.getScheme()) && uri.getUserInfo() == null && uri.getPort() == -1
                    && !"app.goodok.local".equals(uri.getHost());
                if (request.isForMainFrame() && request.hasGesture() && officialSource) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)); }
                    catch (ActivityNotFoundException exception) {
                        Toast.makeText(MainActivity.this, "공식 페이지를 열 브라우저가 없어요.", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return !"https".equals(uri.getScheme()) || !"app.goodok.local".equals(uri.getHost()) || uri.getPort() != -1;
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        root.requestApplyInsets();
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::handleBack);
        }
        webView.addJavascriptInterface(new OfferBridge(), "GoodokResearch");
        webView.loadUrl(ORIGIN + "/index.html");
    }

    private static WebResourceResponse error(int code, String reason) {
        return new WebResourceResponse("text/plain", "UTF-8", code, reason, new HashMap<>(),
            new ByteArrayInputStream(new byte[0]));
    }

    private void handleBack() {
        webView.evaluateJavascript("window.goodokBack ? window.goodokBack() : false", result -> {
            if (!"true".equals(result)) finish();
        });
    }
    @SuppressWarnings("deprecation") @Override public void onBackPressed() { handleBack(); }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);openReminder();incomingIntent();}
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==305){if(result==RESULT_OK&&data!=null){java.util.ArrayList<String> results=data.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS);if(results!=null&&!results.isEmpty())advancedEvent(results.get(0),null);}return;}
        if(request==303){if(result==RESULT_OK&&data!=null)readReceipt(data.getData());else advancedEvent(null,"이미지 선택을 취소했어요.");return;}
        if(request==304){if(result==RESULT_OK&&data!=null&&data.getData()!=null){try{if((data.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION)==0||(data.getFlags()&Intent.FLAG_GRANT_WRITE_URI_PERMISSION)==0)throw new IOException();getContentResolver().takePersistableUriPermission(data.getData(),Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);BackupStore.prefs(this).edit().putString("tree",data.getData().toString()).putBoolean("auto",true).apply();BackupStore.schedule(this);offerExecutor.execute(()->backupResult("auto",BackupStore.external(this),null));}catch(Exception e){backupResult("auto",false,null);}}else backupResult("auto",false,null);return;}
        if(request!=301&&request!=302&&request!=306)return;
        if(result!=RESULT_OK||data==null||data.getData()==null){backupToWrite=null;backupResult("cancel",true,null);return;}
        Uri uri=data.getData();String export=backupToWrite;backupToWrite=null;
        offerExecutor.execute(()->{try{
            if(request==301||request==306){if(export==null)throw new IOException();try(java.io.OutputStream stream=getContentResolver().openOutputStream(uri,"wt")){if(stream==null)throw new IOException();stream.write(export.getBytes(java.nio.charset.StandardCharsets.UTF_8));}if(request==301)BackupStore.prefs(this).edit().putLong("externalAt",System.currentTimeMillis()).apply();backupResult(request==301?"export":"csv",true,null);}
            else{try(java.io.InputStream stream=getContentResolver().openInputStream(uri);java.io.ByteArrayOutputStream buffer=new java.io.ByteArrayOutputStream()){if(stream==null)throw new IOException();byte[] bytes=new byte[8192];int size;while((size=stream.read(bytes))!=-1){if(buffer.size()+size>2000000)throw new IOException();buffer.write(bytes,0,size);}backupResult("import",true,buffer.toString("UTF-8"));}}
        }catch(Exception e){backupResult(request==301?"export":"import",false,null);}});
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants){super.onRequestPermissionsResult(request,permissions,grants);if(request==220){ReminderScheduler.refresh(this);reminderStatus();}}
    @Override protected void onPause() { webView.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if (webView != null) { webView.onResume(); ReminderScheduler.refresh(this);reminderStatus(); webView.evaluateJavascript("window.goodokResume && window.goodokResume()", null); } }
    @Override protected void onDestroy() {
        destroyed = true;
        offerExecutor.shutdownNow();
        receiptExecutor.shutdownNow();
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }
}
