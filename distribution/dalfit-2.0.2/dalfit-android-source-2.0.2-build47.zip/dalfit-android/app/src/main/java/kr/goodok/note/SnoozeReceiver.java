package kr.goodok.note;
import android.content.*;import android.app.*;
public final class SnoozeReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent intent){String id=intent.getStringExtra("item"),title=intent.getStringExtra("title"),text=intent.getStringExtra("text");if(id==null||title==null||text==null||!ReminderScheduler.enabled(c)||!ReminderScheduler.allowed(c))return;
  if(!"deliver".equals(intent.getAction())){Intent later=new Intent(c,SnoozeReceiver.class).setAction("deliver").setData(android.net.Uri.parse("dalfit://snooze/"+android.net.Uri.encode(id))).putExtra("item",id).putExtra("title",title).putExtra("text",text);PendingIntent p=PendingIntent.getBroadcast(c,4505,later,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);c.getSystemService(AlarmManager.class).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,System.currentTimeMillis()+3600000,p);c.getSystemService(NotificationManager.class).cancel(intent.getStringExtra("tag"),0);return;}
  try{org.json.JSONArray rows=new org.json.JSONArray(c.getSharedPreferences("goodok-reminders",0).getString("records","[]"));boolean active=false;for(int n=0;n<rows.length();n++)if(id.equals(rows.getJSONObject(n).optString("id"))&&!rows.getJSONObject(n).optBoolean("paused"))active=true;if(!active)return;
   PendingIntent open=PendingIntent.getActivity(c,id.hashCode(),new Intent(c,MainActivity.class).setAction("kr.goodok.note.PAY").putExtra("dalfit_action","pay:"+id),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);c.getSystemService(NotificationManager.class).notify("snooze:"+id,0,new Notification.Builder(c,"subscription-reminders-v1").setSmallIcon(R.drawable.ic_notification).setContentTitle(title).setContentText(text).setContentIntent(open).setAutoCancel(true).build());
  }catch(Exception ignored){}
 }
}
