package kr.goodok.note;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import org.json.*;
import java.time.*;
import java.util.*;

/** Persists a local snapshot so alarms survive a closed WebView and reboot. */
public final class ReminderScheduler {
    private static final String PREFS="goodok-reminders",CHANNEL="subscription-reminders-v1";
    private static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    public static void channel(Context c) {
        NotificationChannel channel=new NotificationChannel(CHANNEL,"납부·갱신·종료일 알림",NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("고정비 납부·구독 갱신·무료체험 종료·약정 종료 3일 전과 1일 전 알림");
        c.getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }
    public static boolean allowed(Context c) {
        channel(c);
        if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return false;
        NotificationManager manager=c.getSystemService(NotificationManager.class);
        return manager.areNotificationsEnabled()&&manager.getNotificationChannel(CHANNEL).getImportance()!=NotificationManager.IMPORTANCE_NONE;
    }
    public static boolean enabled(Context c){return prefs(c).getBoolean("enabled",true);}
    public static boolean asked(Context c){return prefs(c).getBoolean("asked",false);}
    public static void asked(Context c,boolean value){prefs(c).edit().putBoolean("asked",value).apply();}
    public static synchronized void enabled(Context c,boolean value){prefs(c).edit().putBoolean("enabled",value).apply();if(!value)c.getSystemService(NotificationManager.class).cancelAll();refresh(c);}
    public static synchronized boolean sync(Context c,String text) {
        try {
            if(text==null||text.length()>2000000)return false;
            JSONArray array=new JSONArray(text);if(array.length()>10000)return false;
            records(array); // Reject invalid snapshots before replacing the last valid one.
            if(!text.equals(prefs(c).getString("records","[]"))) {
                prefs(c).edit().putString("records",text).commit();
                c.getSystemService(NotificationManager.class).cancelAll();
            }
            refresh(c);return true;
        }catch(Exception ignored){return false;}
    }
    private static LocalDate optional(JSONObject o,String key)throws JSONException {
        String value=o.optString(key,"");return value.isEmpty()?null:LocalDate.parse(value);
    }
    private static List<ReminderEngine.Record> records(JSONArray array)throws JSONException {
        List<ReminderEngine.Record> result=new ArrayList<>();Set<String> ids=new HashSet<>();
        for(int i=0;i<array.length();i++) {
            JSONObject o=array.getJSONObject(i);String id=o.getString("id"),name=o.getString("name"),cycle=o.getString("cycle");
            if(id.length()>200||name.length()>60||!ids.add(id)||!(cycle.equals("monthly")||cycle.equals("yearly")))throw new JSONException("Invalid record");
            result.add(new ReminderEngine.Record(id,name,cycle,LocalDate.parse(o.getString("date")),optional(o,"trialEnd"),optional(o,"contractEnd"),o.optBoolean("paused",false),!"subscription".equals(o.optString("kind","subscription"))));
        }
        return result;
    }
    private static PendingIntent alarm(Context c) {
        return PendingIntent.getBroadcast(c,9701,new Intent(c,ReminderReceiver.class).setAction("kr.goodok.note.REMIND"),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    public static synchronized void refresh(Context c) {
        prefs(c).edit().remove("scheduledAt").apply();
        channel(c);AlarmManager manager=c.getSystemService(AlarmManager.class);manager.cancel(alarm(c));
        if(!enabled(c)||!allowed(c))return;
        List<ReminderEngine.Record> records;
        try{records=records(new JSONArray(prefs(c).getString("records","[]")));}catch(Exception ignored){return;}
        if(records.stream().noneMatch(record->!record.paused))return;
        ZonedDateTime now=ZonedDateTime.now();
        if(now.getHour()>=9)deliver(c,records,now.toLocalDate());
        ZonedDateTime next=now.toLocalDate().atTime(9,0).atZone(now.getZone());if(!next.isAfter(now))next=next.plusDays(1);
        manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next.toInstant().toEpochMilli(),alarm(c));
        prefs(c).edit().putLong("scheduledAt",next.toInstant().toEpochMilli()).apply();
    }
    private static void deliver(Context c,List<ReminderEngine.Record> records,LocalDate today) {
        Set<String> sent=new HashSet<>(prefs(c).getStringSet("sent",Collections.emptySet()));
        sent.removeIf(key->{try{return LocalDate.parse(key.split("\\|",-1)[2]).isBefore(today.minusDays(7));}catch(Exception e){return true;}});
        for(ReminderEngine.Event event:ReminderEngine.due(records,today)) {
            if(sent.contains(event.key()))continue;
            Intent open=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).setData(android.net.Uri.parse("goodok://reminder/"+android.net.Uri.encode(event.key()))).putExtra("reminder_id",event.record.id);
            PendingIntent content=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            PendingIntent paid=PendingIntent.getActivity(c,event.key().hashCode(),new Intent(c,MainActivity.class).setAction("kr.goodok.note.PAY").putExtra("dalfit_action","pay:"+event.record.id),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            PendingIntent snooze=PendingIntent.getBroadcast(c,event.key().hashCode(),new Intent(c,SnoozeReceiver.class).setAction("snooze").setData(android.net.Uri.parse("dalfit://snooze/"+android.net.Uri.encode(event.key()))).putExtra("item",event.record.id).putExtra("title",event.title()).putExtra("text",event.text()).putExtra("tag",event.key()),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Notification notification=new Notification.Builder(c,CHANNEL).setSmallIcon(kr.goodok.note.R.drawable.ic_notification).setContentTitle(event.title()).setContentText(event.text()).setStyle(new Notification.BigTextStyle().bigText(event.text())).setContentIntent(content).addAction(new Notification.Action.Builder(null,"결제 확인",paid).build()).addAction(new Notification.Action.Builder(null,"1시간 뒤",snooze).build()).setAutoCancel(true).setVisibility(Notification.VISIBILITY_PRIVATE).setCategory(Notification.CATEGORY_REMINDER).build();
            try{c.getSystemService(NotificationManager.class).notify(event.key(),0,notification);sent.add(event.key());}catch(SecurityException ignored){}
        }
        prefs(c).edit().putStringSet("sent",sent).commit();
    }
    public static String status(Context c) {
        JSONObject result=new JSONObject();try{result.put("enabled",enabled(c));result.put("allowed",allowed(c));result.put("asked",asked(c));result.put("scheduledAt",prefs(c).getLong("scheduledAt",0));result.put("timezone",ZoneId.systemDefault().toString());result.put("batteryExempt",c.getSystemService(android.os.PowerManager.class).isIgnoringBatteryOptimizations(c.getPackageName()));}catch(JSONException ignored){}return result.toString();
    }
    public static boolean test(Context c){if(!allowed(c)||!enabled(c))return false;try{c.getSystemService(NotificationManager.class).notify("diagnostic",100,new Notification.Builder(c,CHANNEL).setSmallIcon(kr.goodok.note.R.drawable.ic_notification).setContentTitle("달핏 알림 테스트").setContentText("테스트 알림입니다. 3일 전·1일 전 알림의 권한과 채널을 확인했어요.").setAutoCancel(true).build());return true;}catch(SecurityException e){return false;}}
}
