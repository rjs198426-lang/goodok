package kr.goodok.note;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Calendar-only reminder rules; independent of Android and the WebView. */
public final class ReminderEngine {
    public static final class Record {
        final String id, name, cycle;
        final LocalDate billing, trialEnd, contractEnd;
        final boolean paused, fixed;
        public Record(String id,String name,String cycle,LocalDate billing,LocalDate trialEnd,LocalDate contractEnd,boolean paused) {
            this(id,name,cycle,billing,trialEnd,contractEnd,paused,false);
        }
        public Record(String id,String name,String cycle,LocalDate billing,LocalDate trialEnd,LocalDate contractEnd,boolean paused,boolean fixed) {
            this.id=id;this.name=name;this.cycle=cycle;this.billing=billing;this.trialEnd=trialEnd;this.contractEnd=contractEnd;this.paused=paused;this.fixed=fixed;
        }
    }
    public static final class Event {
        final Record record; final String kind; final LocalDate date; final int lead;
        Event(Record record,String kind,LocalDate date,int lead){this.record=record;this.kind=kind;this.date=date;this.lead=lead;}
        public String key(){return record.id+"|"+kind+"|"+date+"|"+lead;}
        public String title(){return record.name+" · "+kind+" "+lead+"일 전";}
        public String text(){return date+" "+kind+" 예정이에요. 결제·해지 조건을 미리 확인하세요.";}
    }
    static LocalDate occurrence(Record record,LocalDate target) {
        if(target.isBefore(record.billing))return null;
        if("yearly".equals(record.cycle)&&target.getMonthValue()!=record.billing.getMonthValue())return null;
        return target.withDayOfMonth(Math.min(record.billing.getDayOfMonth(),target.lengthOfMonth()));
    }
    public static List<Event> due(List<Record> records,LocalDate today) {
        List<Event> result=new ArrayList<>();
        for(Record record:records) {
            if(record.paused)continue;
            for(int lead:new int[]{3,1}) {
                LocalDate target=today.plusDays(lead);
                if(target.equals(occurrence(record,target)))result.add(new Event(record,record.fixed?"비용 납부":"구독 갱신",target,lead));
                if(target.equals(record.trialEnd))result.add(new Event(record,"무료체험 종료",target,lead));
                if(target.equals(record.contractEnd))result.add(new Event(record,"약정 종료",target,lead));
            }
        }
        return result;
    }
}
