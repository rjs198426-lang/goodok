package kr.goodok.note;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import javax.net.ssl.HttpsURLConnection;
/** The app downloads prepared public JSON only; website collection runs in GitHub Actions. */
final class BenefitFeedFetcher {
 interface Transport { HttpsURLConnection connect(URL url)throws IOException; }
 private final Transport transport;
 BenefitFeedFetcher(){this(url->(HttpsURLConnection)url.openConnection());}
 BenefitFeedFetcher(Transport transport){this.transport=transport;}
 static boolean allowed(URL url) {
  return "https".equals(url.getProtocol())&&url.getPort()==-1&&url.getUserInfo()==null&&url.getQuery()==null&&url.getRef()==null
   &&(("raw.githubusercontent.com".equals(url.getHost())&&url.getPath().matches("/[\\w.-]+/[\\w.-]+/[\\w./-]+\\.json"))
   ||(url.getHost().matches("[\\w-]+\\.github\\.io")&&url.getPath().endsWith(".json")));
 }
 String fetch(String address)throws IOException {
  URL url=new URL(address);if(!allowed(url))throw new IOException("Unsupported feed");
  HttpsURLConnection connection=transport.connect(url);
  try{
   connection.setConnectTimeout(7000);connection.setReadTimeout(12000);connection.setInstanceFollowRedirects(false);
   connection.setRequestProperty("Accept","application/json");connection.setRequestProperty("Cache-Control","no-cache, no-store");connection.setUseCaches(false);
   if(connection.getResponseCode()!=200)throw new IOException("Feed unavailable");
   try(InputStream in=connection.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
    byte[] buffer=new byte[8192];int size;long deadline=System.nanoTime()+15000000000L;
    while((size=in.read(buffer))!=-1){if(out.size()+size>2*1024*1024||System.nanoTime()>deadline||Thread.currentThread().isInterrupted())throw new IOException("Feed size or time limit");out.write(buffer,0,size);}
    return new String(out.toByteArray(),StandardCharsets.UTF_8);
   }
  }finally{connection.disconnect();}
 }
}
